const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const SUPER_ADMIN_UID = "super_admin_001";
const SUPER_ADMIN_EMAIL = "sahadat.khan3445@gmail.com";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function nowTs() {
  return new Date();
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated caller: cannot read devices, users, admins, or activity_logs", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("devices").get());
  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("admins").get());
  await assertFails(unauthDb.collection("activity_logs").get());
});

test("Email spoofing test: matching super admin email with email_verified=false is rejected for admin creation", async () => {
  const spoofedDb = testEnv.authenticatedContext(ALICE_UID, {
    email: SUPER_ADMIN_EMAIL,
    email_verified: false,
  }).firestore();
  const ts = nowTs();
  await assertFails(
    spoofedDb.collection("admins").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: SUPER_ADMIN_EMAIL,
      displayName: "Spoofer",
      role: "SUPER_ADMIN",
      status: "ACTIVE",
      department: "Security",
      createdBy: ALICE_UID,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Self-privilege escalation test: regular user cannot create admin doc or set role=ADMIN on own user doc", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const ts = nowTs();

  await assertFails(
    aliceDb.collection("admins").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      role: "ADMIN",
      status: "ACTIVE",
      department: "IT",
      createdBy: ALICE_UID,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      ownerUid: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice",
      department: "IT",
      role: "ADMIN",
      status: "ACTIVE",
      enrolledDeviceCount: 0,
      assignedPolicyId: "",
      allowedFeatures: ["TELEMETRY"],
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Bootstrapped Super Admin (verified email): can bootstrap admin account and manage users", async () => {
  const superDb = testEnv.authenticatedContext(SUPER_ADMIN_UID, {
    email: SUPER_ADMIN_EMAIL,
    email_verified: true,
  }).firestore();
  const ts = nowTs();

  await assertSucceeds(
    superDb.collection("admins").doc(SUPER_ADMIN_UID).set({
      uid: SUPER_ADMIN_UID,
      email: SUPER_ADMIN_EMAIL,
      displayName: "Super Admin",
      role: "SUPER_ADMIN",
      status: "ACTIVE",
      department: "Enterprise Security",
      createdBy: SUPER_ADMIN_UID,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    superDb.collection("admins").doc(ALICE_UID).set({
      uid: ALICE_UID,
      email: "alice@example.com",
      displayName: "Alice Admin",
      role: "ADMIN",
      status: "ACTIVE",
      department: "Ops",
      createdBy: SUPER_ADMIN_UID,
      createdAt: ts,
      updatedAt: ts,
    })
  );
});

test("Shadow update test: adding ghost field isVerified=true to device fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const ts = nowTs();

  await assertFails(
    aliceDb.collection("devices").doc("dev_01").set({
      ownerUid: ALICE_UID,
      assignedUserId: ALICE_UID,
      deviceName: "Pixel 9 Pro",
      manufacturer: "Google",
      model: "Pixel 9 Pro",
      androidVersion: "16",
      sdkInt: 36,
      enrollmentMode: "STANDARD_BYOD",
      enrollmentStatus: "ENROLLED",
      complianceState: "COMPLIANT",
      securityPatch: "2026-11-05",
      isDeviceEncrypted: true,
      isRootSuspected: false,
      batteryLevel: 88,
      storageUsedMb: 12000,
      storageTotalMb: 128000,
      ramUsedMb: 4096,
      ramTotalMb: 12288,
      networkType: "WIFI",
      assignedPolicyId: "default_policy",
      policySyncVersion: 1,
      enrollmentTokenHash: "sha256_token_abc12345",
      lastHeartbeatAt: ts,
      createdAt: ts,
      updatedAt: ts,
      isVerified: true,
    })
  );
});

test("Cross-user isolation & query trust test: Bob cannot read Alice's device or query unfiltered devices", async () => {
  const ts = nowTs();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("devices").doc("alice_dev_1").set({
      ownerUid: ALICE_UID,
      assignedUserId: ALICE_UID,
      deviceName: "Alice Device",
      manufacturer: "Google",
      model: "Pixel 8",
      androidVersion: "15",
      sdkInt: 35,
      enrollmentMode: "STANDARD_BYOD",
      enrollmentStatus: "ENROLLED",
      complianceState: "COMPLIANT",
      securityPatch: "2026-10-01",
      isDeviceEncrypted: true,
      isRootSuspected: false,
      batteryLevel: 75,
      storageUsedMb: 10000,
      storageTotalMb: 64000,
      ramUsedMb: 3000,
      ramTotalMb: 8192,
      networkType: "WIFI",
      assignedPolicyId: "",
      policySyncVersion: 1,
      enrollmentTokenHash: "hash_alice_12345678",
      lastHeartbeatAt: ts,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID, { email: "bob@example.com", email_verified: true }).firestore();

  await assertSucceeds(aliceDb.collection("devices").where("ownerUid", "==", ALICE_UID).get());
  await assertFails(bobDb.collection("devices").doc("alice_dev_1").get());
  await assertFails(bobDb.collection("devices").get());
});

test("Remote command terminal state locking & activity_logs append-only enforcement", async () => {
  const ts = nowTs();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("devices").doc("alice_dev_2").set({
      ownerUid: ALICE_UID,
      assignedUserId: ALICE_UID,
      deviceName: "Alice Device",
      manufacturer: "Google",
      model: "Pixel 8",
      androidVersion: "15",
      sdkInt: 35,
      enrollmentMode: "STANDARD_BYOD",
      enrollmentStatus: "ENROLLED",
      complianceState: "COMPLIANT",
      securityPatch: "2026-10-01",
      isDeviceEncrypted: true,
      isRootSuspected: false,
      batteryLevel: 75,
      storageUsedMb: 10000,
      storageTotalMb: 64000,
      ramUsedMb: 3000,
      ramTotalMb: 8192,
      networkType: "WIFI",
      assignedPolicyId: "",
      policySyncVersion: 1,
      enrollmentTokenHash: "hash_alice_12345678",
      lastHeartbeatAt: ts,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();

  await assertSucceeds(
    aliceDb.collection("remote_commands").doc("cmd_1").set({
      ownerUid: ALICE_UID,
      targetDeviceId: "alice_dev_2",
      issuedByUid: ALICE_UID,
      issuedByEmail: "alice@example.com",
      commandType: "SYNC_POLICY",
      payloadSummary: "Sync baseline policy",
      nonce: "nonce_abcdef123456",
      signatureDigest: "sig_0123456789abcdef0123456789abcdef",
      status: "QUEUED",
      ackMessage: "",
      expiresAtEpochMs: Date.now() + 3600000,
      acknowledgedAtEpochMs: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Transition to terminal EXECUTED
  await assertSucceeds(
    aliceDb.collection("remote_commands").doc("cmd_1").update({
      status: "EXECUTED",
      ackMessage: "Policy v1 applied",
      acknowledgedAtEpochMs: Date.now(),
      updatedAt: nowTs(),
    })
  );

  // Regular user cannot reopen terminal EXECUTED command
  await assertFails(
    aliceDb.collection("remote_commands").doc("cmd_1").update({
      status: "QUEUED",
      updatedAt: nowTs(),
    })
  );

  // Append-only activity log cannot be updated or deleted
  await assertSucceeds(
    aliceDb.collection("activity_logs").doc("log_1").set({
      ownerUid: ALICE_UID,
      actorUid: ALICE_UID,
      actorEmail: "alice@example.com",
      actorRole: "MEMBER",
      action: "ENROLL_DEVICE",
      targetType: "DEVICE",
      targetId: "alice_dev_2",
      details: "Device enrolled via Titan MDM",
      severity: "INFO",
      createdAt: ts,
    })
  );

  await assertFails(aliceDb.collection("activity_logs").doc("log_1").update({ details: "tampered" }));
  await assertFails(aliceDb.collection("activity_logs").doc("log_1").delete());
});
