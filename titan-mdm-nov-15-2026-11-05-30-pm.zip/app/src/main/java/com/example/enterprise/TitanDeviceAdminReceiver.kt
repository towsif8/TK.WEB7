package com.example.enterprise

import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.PreferencesStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TitanDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.i(TAG, "Titan MDM Device Admin enabled")
        recordEvent(context, "Device Admin enabled on controller")
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.w(TAG, "Titan MDM Device Admin disabled")
        recordEvent(context, "Device Admin deactivated")
    }

    override fun onPasswordFailed(context: Context, intent: Intent, user: android.os.UserHandle) {
        super.onPasswordFailed(context, intent, user)
        Log.w(TAG, "Failed unlock attempt detected")
        recordEvent(context, "Failed lockscreen authentication attempt recorded")
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent, user: android.os.UserHandle) {
        super.onPasswordSucceeded(context, intent, user)
        recordEvent(context, "Device unlock succeeded")
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        Log.i(TAG, "Managed profile provisioning completed")
        recordEvent(context, "Managed enterprise profile provisioning complete")
    }

    private fun recordEvent(context: Context, message: String) {
        val prefs = PreferencesStore(context.applicationContext)
        CoroutineScope(Dispatchers.IO).launch {
            prefs.setLastAdminEvent(message)
        }
    }

    companion object {
        private const val TAG = "TitanDeviceAdmin"

        fun componentName(context: Context): ComponentName =
            ComponentName(context.applicationContext, TitanDeviceAdminReceiver::class.java)
    }
}
