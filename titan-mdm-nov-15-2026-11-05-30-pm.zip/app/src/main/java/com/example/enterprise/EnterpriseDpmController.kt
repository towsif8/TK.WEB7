package com.example.enterprise

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentMode
import com.example.model.EnterpriseCapabilitiesStatus

data class DpmActionResult(
    val success: Boolean,
    val message: String,
    val requiresDeviceAdmin: Boolean = false,
    val requiresDeviceOwner: Boolean = false,
)

class EnterpriseDpmController(private val context: Context) {

    private val dpm: DevicePolicyManager? =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
    private val adminComponent = TitanDeviceAdminReceiver.componentName(context)

    fun inspectCapabilities(): EnterpriseCapabilitiesStatus {
        val manager = dpm
        val isAdminActive = manager?.isAdminActive(adminComponent) == true
        val isDeviceOwner = manager?.isDeviceOwnerApp(context.packageName) == true
        val isProfileOwner = manager?.isProfileOwnerApp(context.packageName) == true

        val mode = when {
            isDeviceOwner -> EnrollmentMode.DEVICE_OWNER
            isProfileOwner -> EnrollmentMode.WORK_PROFILE
            isAdminActive -> EnrollmentMode.DEVICE_ADMIN
            else -> EnrollmentMode.STANDARD_BYOD
        }

        val encStatus = when (manager?.storageEncryptionStatus) {
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE,
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER -> "Active (Encrypted)"
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY -> "Active (Default Key)"
            DevicePolicyManager.ENCRYPTION_STATUS_ACTIVATING -> "Activating"
            DevicePolicyManager.ENCRYPTION_STATUS_INACTIVE -> "Inactive"
            else -> "Unsupported / Unknown"
        }

        val cameraDisabled = try {
            if (isAdminActive) manager?.getCameraDisabled(adminComponent) == true else false
        } catch (_: SecurityException) {
            false
        }

        val passwordSufficient = try {
            if (isAdminActive) manager?.isActivePasswordSufficient == true else false
        } catch (_: SecurityException) {
            false
        }

        val minPassLen = try {
            if (isAdminActive) manager?.getPasswordMinimumLength(adminComponent) ?: 0 else 0
        } catch (_: SecurityException) {
            0
        }

        val maxFailedWipe = try {
            if (isAdminActive) manager?.getMaximumFailedPasswordsForWipe(adminComponent) ?: 0 else 0
        } catch (_: SecurityException) {
            0
        }

        val maxTimeToLockSec = try {
            if (isAdminActive) (manager?.getMaximumTimeToLock(adminComponent) ?: 0L) / 1000L else 0L
        } catch (_: SecurityException) {
            0L
        }

        val keyguardDisabled = try {
            if (isAdminActive) manager?.getKeyguardDisabledFeatures(adminComponent) ?: 0 else 0
        } catch (_: SecurityException) {
            0
        }

        return EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = isAdminActive,
            isDeviceOwner = isDeviceOwner,
            isProfileOwner = isProfileOwner,
            enrollmentMode = mode,
            storageEncryptionStatus = encStatus,
            isCameraDisabledByPolicy = cameraDisabled,
            isPasswordSufficient = passwordSufficient,
            minPasswordLength = minPassLen,
            maxFailedPasswordsForWipe = maxFailedWipe,
            maxTimeToLockSeconds = maxTimeToLockSec,
            keyguardDisabledFeatures = keyguardDisabled,
            supportsUsbRestriction = isDeviceOwner,
            supportsAppSuspension = isDeviceOwner || isProfileOwner
        )
    }

    fun buildActivateDeviceAdminIntent(): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Authorize Titan MDM to enforce screen lock, password complexity, timeout, and camera enterprise policies."
            )
        }

    fun lockDeviceNow(): DpmActionResult {
        val manager = dpm ?: return DpmActionResult(false, "DevicePolicyManager unavailable on this device.")
        if (!manager.isAdminActive(adminComponent)) {
            return DpmActionResult(
                success = false,
                message = "Device Admin permission is required to lock the screen remotely.",
                requiresDeviceAdmin = true
            )
        }
        return try {
            manager.lockNow()
            DpmActionResult(true, "Screen locked via DevicePolicyManager.lockNow().")
        } catch (e: SecurityException) {
            DpmActionResult(false, "SecurityException locking device: ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    fun applyPolicyRecord(policy: DevicePolicyRecord): DpmActionResult {
        val manager = dpm ?: return DpmActionResult(false, "DevicePolicyManager unavailable.")
        if (!manager.isAdminActive(adminComponent)) {
            return DpmActionResult(
                success = false,
                message = "Policy '${policy.name}' saved in cloud, but local enforcement requires activating Titan MDM Device Admin.",
                requiresDeviceAdmin = true
            )
        }

        val applied = mutableListOf<String>()
        val skipped = mutableListOf<String>()
        val isOwnerOrProfile = manager.isDeviceOwnerApp(context.packageName) ||
            manager.isProfileOwnerApp(context.packageName)

        try {
            manager.setMaximumTimeToLock(adminComponent, policy.screenTimeoutSeconds * 1000L)
            applied.add("screenTimeout=${policy.screenTimeoutSeconds}s")
        } catch (e: Exception) {
            skipped.add("screenTimeout(${e.javaClass.simpleName})")
        }

        try {
            manager.setCameraDisabled(adminComponent, policy.disableCamera)
            applied.add("disableCamera=${policy.disableCamera}")
        } catch (e: Exception) {
            skipped.add("camera(${e.javaClass.simpleName})")
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            try {
                if (policy.minPasswordLength > 0) {
                    manager.setPasswordMinimumLength(adminComponent, policy.minPasswordLength.toInt())
                    applied.add("minPwd=${policy.minPasswordLength}")
                }
            } catch (_: Exception) {
                skipped.add("minPwd")
            }
        } else if (isOwnerOrProfile) {
            try {
                val complexity = if (policy.minPasswordLength >= 8) {
                    DevicePolicyManager.PASSWORD_COMPLEXITY_HIGH
                } else if (policy.minPasswordLength >= 6) {
                    DevicePolicyManager.PASSWORD_COMPLEXITY_MEDIUM
                } else {
                    DevicePolicyManager.PASSWORD_COMPLEXITY_LOW
                }
                manager.requiredPasswordComplexity = complexity
                applied.add("passwordComplexity")
            } catch (_: Exception) {
                skipped.add("passwordComplexity")
            }
        } else {
            skipped.add("passwordComplexity(requires Device/Profile Owner on Android 12+)")
        }

        try {
            manager.setMaximumFailedPasswordsForWipe(
                adminComponent,
                policy.maxFailedPasswordsForWipe.toInt()
            )
            applied.add("maxFailedWipe=${policy.maxFailedPasswordsForWipe}")
        } catch (_: Exception) {
            skipped.add("maxFailedWipe")
        }

        if (manager.isDeviceOwnerApp(context.packageName)) {
            try {
                if (policy.disableUsbFileTransfer) {
                    manager.addUserRestriction(adminComponent, UserManager.DISALLOW_USB_FILE_TRANSFER)
                } else {
                    manager.clearUserRestriction(adminComponent, UserManager.DISALLOW_USB_FILE_TRANSFER)
                }
                applied.add("usbRestriction=${policy.disableUsbFileTransfer}")
            } catch (_: Exception) {
                skipped.add("usbRestriction")
            }

            try {
                if (policy.blockUnknownSources) {
                    manager.addUserRestriction(adminComponent, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
                } else {
                    manager.clearUserRestriction(adminComponent, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
                }
                applied.add("blockUnknownSources=${policy.blockUnknownSources}")
            } catch (_: Exception) {
                skipped.add("blockUnknownSources")
            }
        } else {
            if (policy.disableUsbFileTransfer || policy.blockUnknownSources) {
                skipped.add("USB/UnknownSources restrictions (require Device Owner provisioning)")
            }
        }

        val summary = buildString {
            append("Applied: ${applied.joinToString(", ").ifEmpty { "none" }}")
            if (skipped.isNotEmpty()) {
                append(" | Requires Owner/Skipped: ${skipped.joinToString(", ")}")
            }
        }
        return DpmActionResult(
            success = applied.isNotEmpty(),
            message = summary,
            requiresDeviceOwner = !isOwnerOrProfile
        )
    }

    fun setPackageSuspendedByOwner(packageName: String, suspended: Boolean): DpmActionResult {
        val manager = dpm ?: return DpmActionResult(false, "DevicePolicyManager unavailable.")
        if (!manager.isDeviceOwnerApp(context.packageName) && !manager.isProfileOwnerApp(context.packageName)) {
            return DpmActionResult(
                success = false,
                message = "Suspending third-party apps natively requires Device Owner or Work Profile Owner provisioning.",
                requiresDeviceOwner = true
            )
        }
        return try {
            val failed = manager.setPackagesSuspended(adminComponent, arrayOf(packageName), suspended)
            if (failed.isEmpty()) {
                DpmActionResult(true, "${if (suspended) "Suspended" else "Unsuspended"} $packageName via DPM.")
            } else {
                DpmActionResult(false, "Android OS protected package cannot be suspended: ${failed.joinToString()}")
            }
        } catch (e: Exception) {
            DpmActionResult(false, "Failed to update app suspension: ${e.message}")
        }
    }

    fun clearAllDeviceAdminRestrictions(): DpmActionResult {
        val manager = dpm ?: return DpmActionResult(false, "DevicePolicyManager unavailable.")
        if (!manager.isAdminActive(adminComponent)) {
            return DpmActionResult(false, "Device Admin is not active.", requiresDeviceAdmin = true)
        }
        return try {
            manager.setCameraDisabled(adminComponent, false)
            manager.setMaximumFailedPasswordsForWipe(adminComponent, 0)
            if (manager.isDeviceOwnerApp(context.packageName)) {
                manager.clearUserRestriction(adminComponent, UserManager.DISALLOW_USB_FILE_TRANSFER)
                manager.clearUserRestriction(adminComponent, UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
            }
            DpmActionResult(true, "Enterprise restrictions cleared.")
        } catch (e: Exception) {
            DpmActionResult(false, "Failed clearing restrictions: ${e.message}")
        }
    }
}
