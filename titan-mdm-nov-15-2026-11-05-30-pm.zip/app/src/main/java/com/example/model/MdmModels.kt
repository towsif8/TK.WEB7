package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class MdmRole(val level: Int, val label: String) {
    SUPER_ADMIN(4, "Super Admin"),
    ADMIN(3, "Admin"),
    MODERATOR(2, "Moderator"),
    MEMBER(1, "Member");

    companion object {
        fun fromString(value: String): MdmRole =
            entries.firstOrNull { it.name == value } ?: MEMBER
    }
}

enum class AccountStatus(val label: String) {
    ACTIVE("Active"),
    SUSPENDED("Suspended"),
    REVOKED("Revoked");

    companion object {
        fun fromString(value: String): AccountStatus =
            entries.firstOrNull { it.name == value } ?: ACTIVE
    }
}

enum class EnrollmentMode(val label: String) {
    STANDARD_BYOD("Standard App (BYOD)"),
    DEVICE_ADMIN("Device Admin (Legacy DPM)"),
    DEVICE_OWNER("Device Owner (Fully Managed)"),
    WORK_PROFILE("Work Profile (Managed Profile)");

    companion object {
        fun fromString(value: String): EnrollmentMode =
            entries.firstOrNull { it.name == value } ?: STANDARD_BYOD
    }
}

enum class EnrollmentStatus(val label: String) {
    PENDING("Pending"),
    ENROLLED("Enrolled"),
    SUSPENDED("Suspended"),
    REVOKED("Revoked")
}

enum class ComplianceState(val label: String) {
    COMPLIANT("Compliant"),
    AT_RISK("At Risk"),
    NON_COMPLIANT("Non-Compliant")
}

enum class RemoteCommandType(val label: String, val requiresAdminPrivilege: Boolean) {
    SYNC_POLICY("Sync Policy", false),
    LOCK_NOW("Lock Screen Now", true),
    AUDIT_SECURITY("Run Security Audit", false),
    REFRESH_TELEMETRY("Refresh Telemetry", false),
    ENFORCE_ALLOWLIST("Enforce App Allowlist", true),
    REVOKE_ENROLLMENT("Revoke Enrollment", false),
    CLEAR_RESTRICTIONS("Clear Restrictions", true)
}

@IgnoreExtraProperties
data class AdminAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = MdmRole.MEMBER.name,
    val status: String = AccountStatus.ACTIVE.name,
    val department: String = "Operations",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "uid" to uid,
        "email" to email,
        "displayName" to displayName,
        "role" to role,
        "status" to status,
        "department" to department,
        "createdBy" to createdBy,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class ManagedUser(
    @DocumentId val id: String = "",
    val uid: String = "",
    val ownerUid: String = "",
    val email: String = "",
    val displayName: String = "",
    val department: String = "General",
    val role: String = MdmRole.MEMBER.name,
    val status: String = AccountStatus.ACTIVE.name,
    val enrolledDeviceCount: Long = 0L,
    val assignedPolicyId: String = "",
    val allowedFeatures: List<String> = listOf("TELEMETRY", "SECURITY_SCAN", "APP_AUDIT"),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "uid" to uid,
        "ownerUid" to ownerUid,
        "email" to email,
        "displayName" to displayName,
        "department" to department,
        "role" to role,
        "status" to status,
        "enrolledDeviceCount" to enrolledDeviceCount,
        "assignedPolicyId" to assignedPolicyId,
        "allowedFeatures" to allowedFeatures,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class ManagedDevice(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val assignedUserId: String = "",
    val deviceName: String = "",
    val manufacturer: String = "",
    val model: String = "",
    val androidVersion: String = "",
    val sdkInt: Long = 24L,
    val enrollmentMode: String = EnrollmentMode.STANDARD_BYOD.name,
    val enrollmentStatus: String = EnrollmentStatus.ENROLLED.name,
    val complianceState: String = ComplianceState.COMPLIANT.name,
    val securityPatch: String = "Unknown",
    val isDeviceEncrypted: Boolean = false,
    val isRootSuspected: Boolean = false,
    val batteryLevel: Long = 0L,
    val storageUsedMb: Long = 0L,
    val storageTotalMb: Long = 0L,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val networkType: String = "Unknown",
    val assignedPolicyId: String = "",
    val policySyncVersion: Long = 1L,
    val enrollmentTokenHash: String = "",
    @ServerTimestamp val lastHeartbeatAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "assignedUserId" to assignedUserId,
        "deviceName" to deviceName,
        "manufacturer" to manufacturer,
        "model" to model,
        "androidVersion" to androidVersion,
        "sdkInt" to sdkInt,
        "enrollmentMode" to enrollmentMode,
        "enrollmentStatus" to enrollmentStatus,
        "complianceState" to complianceState,
        "securityPatch" to securityPatch,
        "isDeviceEncrypted" to isDeviceEncrypted,
        "isRootSuspected" to isRootSuspected,
        "batteryLevel" to batteryLevel,
        "storageUsedMb" to storageUsedMb,
        "storageTotalMb" to storageTotalMb,
        "ramUsedMb" to ramUsedMb,
        "ramTotalMb" to ramTotalMb,
        "networkType" to networkType,
        "assignedPolicyId" to assignedPolicyId,
        "policySyncVersion" to policySyncVersion,
        "enrollmentTokenHash" to enrollmentTokenHash,
        "lastHeartbeatAt" to FieldValue.serverTimestamp(),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class DevicePolicyRecord(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val name: String = "",
    val description: String = "",
    val isDefaultPolicy: Boolean = false,
    val requireScreenLock: Boolean = true,
    val minPasswordLength: Long = 6L,
    val requireEncryption: Boolean = true,
    val disableCamera: Boolean = false,
    val disableUsbFileTransfer: Boolean = false,
    val blockUnknownSources: Boolean = true,
    val maxFailedPasswordsForWipe: Long = 0L,
    val screenTimeoutSeconds: Long = 120L,
    val appAllowlist: List<String> = emptyList(),
    val appBlocklist: List<String> = emptyList(),
    val version: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "name" to name,
        "description" to description,
        "isDefaultPolicy" to isDefaultPolicy,
        "requireScreenLock" to requireScreenLock,
        "minPasswordLength" to minPasswordLength,
        "requireEncryption" to requireEncryption,
        "disableCamera" to disableCamera,
        "disableUsbFileTransfer" to disableUsbFileTransfer,
        "blockUnknownSources" to blockUnknownSources,
        "maxFailedPasswordsForWipe" to maxFailedPasswordsForWipe,
        "screenTimeoutSeconds" to screenTimeoutSeconds,
        "appAllowlist" to appAllowlist,
        "appBlocklist" to appBlocklist,
        "version" to version,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class RemoteCommand(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val targetDeviceId: String = "",
    val issuedByUid: String = "",
    val issuedByEmail: String = "",
    val commandType: String = RemoteCommandType.SYNC_POLICY.name,
    val payloadSummary: String = "",
    val nonce: String = "",
    val signatureDigest: String = "",
    val status: String = "QUEUED",
    val ackMessage: String = "",
    val expiresAtEpochMs: Long = 0L,
    val acknowledgedAtEpochMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "targetDeviceId" to targetDeviceId,
        "issuedByUid" to issuedByUid,
        "issuedByEmail" to issuedByEmail,
        "commandType" to commandType,
        "payloadSummary" to payloadSummary,
        "nonce" to nonce,
        "signatureDigest" to signatureDigest,
        "status" to status,
        "ackMessage" to ackMessage,
        "expiresAtEpochMs" to expiresAtEpochMs,
        "acknowledgedAtEpochMs" to acknowledgedAtEpochMs,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class SecurityReport(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val deviceId: String = "",
    val overallRiskScore: Long = 0L,
    val confirmedFindingsCount: Long = 0L,
    val potentialRisksCount: Long = 0L,
    val installedAppsScanned: Long = 0L,
    val deviceIntegrityPassed: Boolean = true,
    val networkSecurityGrade: String = "A",
    val summary: String = "",
    val findings: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "deviceId" to deviceId,
        "overallRiskScore" to overallRiskScore,
        "confirmedFindingsCount" to confirmedFindingsCount,
        "potentialRisksCount" to potentialRisksCount,
        "installedAppsScanned" to installedAppsScanned,
        "deviceIntegrityPassed" to deviceIntegrityPassed,
        "networkSecurityGrade" to networkSecurityGrade,
        "summary" to summary,
        "findings" to findings,
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class ActivityLog(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val actorUid: String = "",
    val actorEmail: String = "",
    val actorRole: String = "",
    val action: String = "",
    val targetType: String = "",
    val targetId: String = "",
    val details: String = "",
    val severity: String = "INFO",
    @ServerTimestamp val createdAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "actorUid" to actorUid,
        "actorEmail" to actorEmail,
        "actorRole" to actorRole,
        "action" to action,
        "targetType" to targetType,
        "targetId" to targetId,
        "details" to details,
        "severity" to severity,
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@IgnoreExtraProperties
data class AdminSession(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val role: String = MdmRole.MEMBER.name,
    val deviceModel: String = "",
    val status: String = "ACTIVE",
    val startedAtEpochMs: Long = 0L,
    val lastActiveAtEpochMs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "ownerUid" to ownerUid,
        "adminUid" to adminUid,
        "adminEmail" to adminEmail,
        "role" to role,
        "deviceModel" to deviceModel,
        "status" to status,
        "startedAtEpochMs" to startedAtEpochMs,
        "lastActiveAtEpochMs" to lastActiveAtEpochMs,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

// --- Native Device & Security Engine Models ---

data class DeviceHardwareSnapshot(
    val deviceId: String,
    val deviceName: String,
    val manufacturer: String,
    val brand: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val securityPatch: String,
    val hardware: String,
    val board: String,
    val cpuAbis: String,
    val cpuCores: Int,
    val cpuModel: String,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val isLowMemory: Boolean,
    val storageUsedMb: Long,
    val storageTotalMb: Long,
    val batteryPercent: Int,
    val batteryStatus: String,
    val batteryHealth: String,
    val batteryTempC: Float,
    val chargingSource: String,
    val networkType: String,
    val isNetworkValidated: Boolean,
    val isMetered: Boolean,
    val isVpnActive: Boolean,
    val dnsServers: String,
    val isDeviceEncrypted: Boolean,
    val isRootSuspected: Boolean,
    val isAdbEnabled: Boolean,
    val isTestKeysBuild: Boolean,
    val isScreenLockConfigured: Boolean,
    val capturedAtEpochMs: Long
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val targetSdkVersion: Int,
    val minSdkVersion: Int,
    val installerPackage: String,
    val requestedPermissions: List<String>,
    val grantedDangerousPermissions: List<String>,
    val isDebuggable: Boolean,
    val usesCleartextTraffic: Boolean,
    val signingCertSha256: String,
    val firstInstallTimeMs: Long,
    val lastUpdateTimeMs: Long,
    val riskScore: Int,
    val riskLabel: String
)

enum class FindingCertainty { CONFIRMED_FINDING, POTENTIAL_RISK }
enum class FindingSeverity { CRITICAL, HIGH, MEDIUM, LOW }

data class SecurityScanFinding(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val certainty: FindingCertainty,
    val severity: FindingSeverity,
    val remediation: String
)

data class LocalSecurityAuditResult(
    val riskScore: Int,
    val confirmedFindingsCount: Int,
    val potentialRisksCount: Int,
    val installedAppsScanned: Int,
    val deviceIntegrityPassed: Boolean,
    val networkSecurityGrade: String,
    val findings: List<SecurityScanFinding>,
    val summary: String,
    val scannedAtEpochMs: Long
)

data class EnterpriseCapabilitiesStatus(
    val isDeviceAdminActive: Boolean,
    val isDeviceOwner: Boolean,
    val isProfileOwner: Boolean,
    val enrollmentMode: EnrollmentMode,
    val storageEncryptionStatus: String,
    val isCameraDisabledByPolicy: Boolean,
    val isPasswordSufficient: Boolean,
    val minPasswordLength: Int,
    val maxFailedPasswordsForWipe: Int,
    val maxTimeToLockSeconds: Long,
    val keyguardDisabledFeatures: Int,
    val supportsUsbRestriction: Boolean,
    val supportsAppSuspension: Boolean
)

data class PermissionAuditItem(
    val permission: String,
    val title: String,
    val category: String,
    val isGranted: Boolean,
    val isRuntimePermission: Boolean,
    val rationale: String
)
