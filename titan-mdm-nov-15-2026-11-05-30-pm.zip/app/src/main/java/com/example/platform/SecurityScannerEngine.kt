package com.example.platform

import android.content.Context
import android.os.Debug
import com.example.model.DeviceHardwareSnapshot
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.FindingCertainty
import com.example.model.FindingSeverity
import com.example.model.InstalledAppInfo
import com.example.model.LocalSecurityAuditResult
import com.example.model.SecurityScanFinding

class SecurityScannerEngine(private val context: Context) {

    fun runComprehensiveAudit(
        hardware: DeviceHardwareSnapshot,
        apps: List<InstalledAppInfo>,
        enterprise: EnterpriseCapabilitiesStatus,
    ): LocalSecurityAuditResult {
        val findings = mutableListOf<SecurityScanFinding>()

        // 1. Confirmed Device Integrity & Configuration Checks
        if (!hardware.isDeviceEncrypted) {
            findings += SecurityScanFinding(
                id = "enc_inactive",
                title = "Storage Encryption Not Active",
                description = "DevicePolicyManager reports storage encryption status as '${enterprise.storageEncryptionStatus}'.",
                category = "Device Integrity",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.CRITICAL,
                remediation = "Enable file-based or full-disk encryption in System Security settings."
            )
        }

        if (!hardware.isScreenLockConfigured) {
            findings += SecurityScanFinding(
                id = "lock_missing",
                title = "No Secure Screen Lock Configured",
                description = "KeyguardManager confirms no PIN, pattern, password, or biometric lock is active.",
                category = "Access Control",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.HIGH,
                remediation = "Configure a secure PIN or biometric screen lock immediately."
            )
        }

        if (hardware.isRootSuspected) {
            findings += SecurityScanFinding(
                id = "root_su_detected",
                title = "Root / Privileged Binary Indicator Found",
                description = "Privileged su binary paths were detected in system directories.",
                category = "Device Integrity",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.CRITICAL,
                remediation = "Revoke enterprise access or restore stock verified OS image."
            )
        }

        if (hardware.isTestKeysBuild) {
            findings += SecurityScanFinding(
                id = "test_keys_build",
                title = "Non-Release OS Signature (test-keys)",
                description = "Android Build.TAGS reports 'test-keys' rather than production release keys.",
                category = "OS Integrity",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.MEDIUM,
                remediation = "Verify device image is an authorized OEM or test build."
            )
        }

        if (hardware.isAdbEnabled) {
            findings += SecurityScanFinding(
                id = "adb_enabled",
                title = "USB Debugging (ADB) Enabled",
                description = "Developer USB debugging is active, increasing physical attack surface.",
                category = "Configuration Audit",
                certainty = FindingCertainty.POTENTIAL_RISK,
                severity = FindingSeverity.MEDIUM,
                remediation = "Disable USB Debugging in Developer Options for production devices."
            )
        }

        if (Debug.isDebuggerConnected()) {
            findings += SecurityScanFinding(
                id = "debugger_attached",
                title = "Runtime Debugger Attached",
                description = "An active debugger session is attached to the MDM process.",
                category = "Runtime Integrity",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.HIGH,
                remediation = "Disconnect debugger before authorizing sensitive enterprise operations."
            )
        }

        // 2. Network Security Diagnostics
        var networkScorePenalty = 0
        if (hardware.networkType == "Offline") {
            networkScorePenalty += 10
        } else {
            if (!hardware.isNetworkValidated) {
                networkScorePenalty += 25
                findings += SecurityScanFinding(
                    id = "net_unvalidated",
                    title = "Unvalidated Network / Captive Portal",
                    description = "Active ${hardware.networkType} connection failed system internet validation.",
                    category = "Network Security",
                    certainty = FindingCertainty.POTENTIAL_RISK,
                    severity = FindingSeverity.MEDIUM,
                    remediation = "Switch to a trusted corporate Wi-Fi or verified VPN tunnel."
                )
            }
            if (!hardware.isVpnActive && hardware.networkType == "Wi-Fi") {
                networkScorePenalty += 10
                findings += SecurityScanFinding(
                    id = "net_no_vpn",
                    title = "Wi-Fi Session Without Enterprise VPN",
                    description = "Device is connected over Wi-Fi without an active VPN transport.",
                    category = "Network Security",
                    certainty = FindingCertainty.POTENTIAL_RISK,
                    severity = FindingSeverity.LOW,
                    remediation = "Enable corporate VPN when operating on untrusted Wi-Fi networks."
                )
            }
        }

        val networkGrade = when {
            networkScorePenalty == 0 -> "A+"
            networkScorePenalty <= 15 -> "A"
            networkScorePenalty <= 30 -> "B"
            else -> "C"
        }

        // 3. APK Metadata & Permission Analysis
        val debuggableThirdParty = apps.filter { it.isDebuggable && !it.isSystemApp && it.packageName != context.packageName }
        debuggableThirdParty.take(3).forEach { app ->
            findings += SecurityScanFinding(
                id = "apk_debug_${app.packageName}",
                title = "Debuggable App Installed: ${app.appName}",
                description = "${app.packageName} has FLAG_DEBUGGABLE enabled in its manifest.",
                category = "APK Metadata",
                certainty = FindingCertainty.CONFIRMED_FINDING,
                severity = FindingSeverity.HIGH,
                remediation = "Uninstall debug builds or replace with signed Play Store release."
            )
        }

        val sideloadedRiskApps = apps.filter {
            !it.isSystemApp && it.installerPackage == "Unknown / Sideloaded" && it.grantedDangerousPermissions.size >= 2
        }
        sideloadedRiskApps.take(4).forEach { app ->
            findings += SecurityScanFinding(
                id = "apk_sideload_${app.packageName}",
                title = "Sideloaded App with Sensitive Permissions: ${app.appName}",
                description = "Unknown installer; holds ${app.grantedDangerousPermissions.joinToString(", ")}.",
                category = "Application Audit",
                certainty = FindingCertainty.POTENTIAL_RISK,
                severity = FindingSeverity.MEDIUM,
                remediation = "Verify APK signing certificate (${app.signingCertSha256}) or restrict via allowlist."
            )
        }

        val cleartextApps = apps.filter { !it.isSystemApp && it.usesCleartextTraffic }
        if (cleartextApps.isNotEmpty()) {
            findings += SecurityScanFinding(
                id = "apk_cleartext",
                title = "${cleartextApps.size} App(s) Allow Cleartext HTTP Traffic",
                description = "Sample: ${cleartextApps.take(3).joinToString { it.appName }}",
                category = "Transport Security",
                certainty = FindingCertainty.POTENTIAL_RISK,
                severity = FindingSeverity.LOW,
                remediation = "Audit apps handling sensitive enterprise data over non-TLS channels."
            )
        }

        val confirmedCount = findings.count { it.certainty == FindingCertainty.CONFIRMED_FINDING }
        val potentialCount = findings.count { it.certainty == FindingCertainty.POTENTIAL_RISK }

        val rawScore = findings.sumOf { finding ->
            when (finding.severity) {
                FindingSeverity.CRITICAL -> 30
                FindingSeverity.HIGH -> 18
                FindingSeverity.MEDIUM -> 10
                FindingSeverity.LOW -> 4
            }.toInt()
        }.coerceIn(0, 100)

        val integrityPassed = !hardware.isRootSuspected && hardware.isDeviceEncrypted && confirmedCount == 0

        val summary = if (findings.isEmpty()) {
            "All ${apps.size} scanned apps and native integrity checks passed with zero confirmed issues."
        } else {
            "$confirmedCount confirmed finding(s) and $potentialCount potential risk(s) across ${apps.size} scanned apps."
        }

        return LocalSecurityAuditResult(
            riskScore = rawScore,
            confirmedFindingsCount = confirmedCount,
            potentialRisksCount = potentialCount,
            installedAppsScanned = apps.size,
            deviceIntegrityPassed = integrityPassed,
            networkSecurityGrade = networkGrade,
            findings = findings,
            summary = summary,
            scannedAtEpochMs = System.currentTimeMillis()
        )
    }
}
