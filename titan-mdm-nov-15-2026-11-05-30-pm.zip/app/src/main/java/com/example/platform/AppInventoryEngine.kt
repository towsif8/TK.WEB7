package com.example.platform

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class AppInventoryEngine(private val context: Context) {

    private val highRiskPermissions = setOf(
        "android.permission.CAMERA",
        "android.permission.RECORD_AUDIO",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.READ_CONTACTS",
        "android.permission.READ_SMS",
        "android.permission.SEND_SMS",
        "android.permission.READ_CALL_LOG",
        "android.permission.SYSTEM_ALERT_WINDOW",
        "android.permission.REQUEST_INSTALL_PACKAGES",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE"
    )

    suspend fun scanInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val discoveredPackages = linkedSetOf<String>()

        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveFlags = PackageManager.MATCH_ALL
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(resolveFlags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, resolveFlags)
        }
        resolved.forEach { info ->
            info.activityInfo?.packageName?.let { discoveredPackages.add(it) }
        }
        discoveredPackages.add(context.packageName)

        // Also attempt getInstalledPackages for any additional visible packages
        try {
            val pkgs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
            pkgs.forEach { discoveredPackages.add(it.packageName) }
        } catch (_: Exception) {
            // Expected on restricted profiles; launcher query already covers user apps
        }

        val results = mutableListOf<InstalledAppInfo>()
        for (pkgName in discoveredPackages) {
            val pkgInfo = getPackageInfoCompat(pm, pkgName) ?: continue
            val appInfo = pkgInfo.applicationInfo ?: continue
            val appName = pm.getApplicationLabel(appInfo).toString().ifBlank { pkgName }
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isDebuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            val usesCleartext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                (appInfo.flags and ApplicationInfo.FLAG_USES_CLEARTEXT_TRAFFIC) != 0
            } else {
                false
            }

            val requested = pkgInfo.requestedPermissions?.toList().orEmpty()
            val flags = pkgInfo.requestedPermissionsFlags
            val grantedDangerous = mutableListOf<String>()
            requested.forEachIndexed { idx, perm ->
                val isGranted = flags != null && idx < flags.size &&
                    (flags[idx] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                if (isGranted && perm in highRiskPermissions) {
                    grantedDangerous.add(perm.removePrefix("android.permission."))
                }
            }

            val installer = resolveInstallerPackage(pm, pkgName)
            val certHash = resolveSigningCertSha256(pkgInfo)
            val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.versionCode.toLong()
            }

            var riskScore = 0
            if (isDebuggable && !isSystem) riskScore += 45
            if (usesCleartext && !isSystem) riskScore += 20
            if (!isSystem && installer == "Unknown / Sideloaded") riskScore += 15
            if (appInfo.targetSdkVersion < 30 && !isSystem) riskScore += 15
            riskScore += (grantedDangerous.size * 7).coerceAtMost(35)
            riskScore = riskScore.coerceIn(0, 100)

            val riskLabel = when {
                riskScore >= 60 -> "High Risk"
                riskScore >= 30 -> "Elevated"
                else -> "Low"
            }

            results.add(
                InstalledAppInfo(
                    packageName = pkgName,
                    appName = appName,
                    versionName = pkgInfo.versionName ?: "1.0",
                    versionCode = versionCode,
                    isSystemApp = isSystem,
                    targetSdkVersion = appInfo.targetSdkVersion,
                    minSdkVersion = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 21,
                    installerPackage = installer,
                    requestedPermissions = requested.map { it.removePrefix("android.permission.") },
                    grantedDangerousPermissions = grantedDangerous,
                    isDebuggable = isDebuggable,
                    usesCleartextTraffic = usesCleartext,
                    signingCertSha256 = certHash,
                    firstInstallTimeMs = pkgInfo.firstInstallTime,
                    lastUpdateTimeMs = pkgInfo.lastUpdateTime,
                    riskScore = riskScore,
                    riskLabel = riskLabel
                )
            )
        }

        results.sortedWith(compareByDescending<InstalledAppInfo> { it.riskScore }.thenBy { it.appName.lowercase() })
    }

    fun launchApp(packageName: String): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launchIntent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openAppSystemDetails(packageName: String): Boolean {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun getPackageInfoCompat(pm: PackageManager, packageName: String): PackageInfo? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val flags = (PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES).toLong()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(packageName, flags.toInt())
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNATURES)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveInstallerPackage(pm: PackageManager, packageName: String): String {
        return try {
            val raw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(packageName)
            }
            when (raw) {
                "com.android.vending" -> "Google Play Store"
                null, "" -> "Unknown / Sideloaded"
                else -> raw
            }
        } catch (_: Exception) {
            "Unknown / Sideloaded"
        }
    }

    private fun resolveSigningCertSha256(pkgInfo: PackageInfo): String {
        return try {
            val certBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                pkgInfo.signatures?.firstOrNull()?.toByteArray()
            } ?: return "Unavailable"
            val digest = MessageDigest.getInstance("SHA-256").digest(certBytes)
            digest.joinToString(":") { "%02X".format(it) }.take(35) + "..."
        } catch (_: Exception) {
            "Unavailable"
        }
    }
}
