package com.example.platform

import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import com.example.model.DeviceHardwareSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

class NativeDeviceIntelligence(private val context: Context) {

    suspend fun captureSnapshot(): DeviceHardwareSnapshot = withContext(Dispatchers.IO) {
        val deviceId = computeDeterministicDeviceId()
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)
        val ramTotalMb = memInfo.totalMem / (1024L * 1024L)
        val ramAvailMb = memInfo.availMem / (1024L * 1024L)
        val ramUsedMb = (ramTotalMb - ramAvailMb).coerceAtLeast(0L)

        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotalMb = stat.totalBytes / (1024L * 1024L)
        val storageAvailMb = stat.availableBytes / (1024L * 1024L)
        val storageUsedMb = (storageTotalMb - storageAvailMb).coerceAtLeast(0L)

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else 0
        val statusCode = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val batteryStatus = when (statusCode) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
            else -> "Unknown"
        }
        val healthCode = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val batteryHealth = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Normal"
        }
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = tempTenths / 10f
        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val chargingSource = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Battery"
        }

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = if (activeNetwork != null) cm.getNetworkCapabilities(activeNetwork) else null
        val linkProps = if (activeNetwork != null) cm.getLinkProperties(activeNetwork) else null

        val networkType = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Connected"
        }
        val isValidated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val isMetered = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        val isVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val dnsServers = linkProps?.dnsServers?.joinToString(", ") { it.hostAddress ?: "" }
            ?.ifBlank { "System Default" } ?: "Unavailable"

        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val encStatus = dpm?.storageEncryptionStatus ?: DevicePolicyManager.ENCRYPTION_STATUS_UNSUPPORTED
        val isEncrypted = encStatus == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE ||
            encStatus == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_PER_USER ||
            encStatus == DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE_DEFAULT_KEY

        val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isScreenLockConfigured = keyguard?.isDeviceSecure == true

        val isTestKeys = Build.TAGS?.contains("test-keys") == true
        val isRootSuspected = checkRootIndicators()
        val isAdbEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        val cpuModel = readCpuHardwareName()
        val deviceName = try {
            Settings.Global.getString(context.contentResolver, Settings.Global.DEVICE_NAME)
                ?.takeIf { it.isNotBlank() } ?: "${Build.MANUFACTURER} ${Build.MODEL}"
        } catch (_: Exception) {
            "${Build.MANUFACTURER} ${Build.MODEL}"
        }

        DeviceHardwareSnapshot(
            deviceId = deviceId,
            deviceName = deviceName,
            manufacturer = Build.MANUFACTURER.ifBlank { "Unknown" },
            brand = Build.BRAND.ifBlank { "Unknown" },
            model = Build.MODEL.ifBlank { "Android Device" },
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Build.VERSION.SECURITY_PATCH ?: "Unknown"
            } else {
                "Pre-M"
            },
            hardware = Build.HARDWARE ?: "Unknown",
            board = Build.BOARD ?: "Unknown",
            cpuAbis = Build.SUPPORTED_ABIS.joinToString(", ").ifBlank { "Unknown" },
            cpuCores = Runtime.getRuntime().availableProcessors(),
            cpuModel = cpuModel,
            ramUsedMb = ramUsedMb,
            ramTotalMb = ramTotalMb,
            isLowMemory = memInfo.lowMemory,
            storageUsedMb = storageUsedMb,
            storageTotalMb = storageTotalMb,
            batteryPercent = batteryPct,
            batteryStatus = batteryStatus,
            batteryHealth = batteryHealth,
            batteryTempC = tempC,
            chargingSource = chargingSource,
            networkType = networkType,
            isNetworkValidated = isValidated,
            isMetered = isMetered,
            isVpnActive = isVpn,
            dnsServers = dnsServers,
            isDeviceEncrypted = isEncrypted,
            isRootSuspected = isRootSuspected,
            isAdbEnabled = isAdbEnabled,
            isTestKeysBuild = isTestKeys,
            isScreenLockConfigured = isScreenLockConfigured,
            capturedAtEpochMs = System.currentTimeMillis()
        )
    }

    @SuppressLint("HardwareIds")
    fun computeDeterministicDeviceId(): String {
        val rawAndroidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }
        val seed = "${rawAndroidId ?: "unknown"}|${Build.MANUFACTURER}|${Build.MODEL}|${Build.BOARD}"
        val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "dev_${hex.take(16)}"
    }

    private fun checkRootIndicators(): Boolean {
        val suPaths = listOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/app/Superuser.apk",
            "/system/xbin/daemonsu"
        )
        return suPaths.any { path ->
            try {
                File(path).exists()
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun readCpuHardwareName(): String {
        return try {
            val file = File("/proc/cpuinfo")
            if (file.exists() && file.canRead()) {
                file.readLines().firstOrNull { line ->
                    line.startsWith("Hardware", ignoreCase = true) ||
                        line.startsWith("model name", ignoreCase = true)
                }?.substringAfter(":")?.trim()?.takeIf { it.isNotBlank() }
                    ?: Build.HARDWARE
            } else {
                Build.HARDWARE
            }
        } catch (_: Exception) {
            Build.HARDWARE
        }
    }
}
