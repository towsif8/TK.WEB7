package com.example.platform

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.model.PermissionAuditItem

class PermissionAuditEngine(private val context: Context) {

    fun auditPermissions(): List<PermissionAuditItem> {
        val items = mutableListOf<PermissionAuditItem>()

        // 1. Notifications (Runtime on Android 13+)
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
        items += PermissionAuditItem(
            permission = Manifest.permission.POST_NOTIFICATIONS,
            title = "Enterprise Threat & Command Alerts",
            category = "Notifications",
            isGranted = notifGranted,
            isRuntimePermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU,
            rationale = "Delivers critical security scan findings and remote command acknowledgments."
        )

        // 2. Coarse Location (Optional Runtime for Wi-Fi SSID diagnostics)
        val coarseGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        items += PermissionAuditItem(
            permission = Manifest.permission.ACCESS_COARSE_LOCATION,
            title = "Network & Wi-Fi Diagnostics",
            category = "Connectivity",
            isGranted = coarseGranted,
            isRuntimePermission = true,
            rationale = "Optional permission enabling Wi-Fi diagnostics without requesting fine GPS tracking."
        )

        // 3. Normal Install-Time Network Permissions (Never requested at runtime)
        val netGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_NETWORK_STATE
        ) == PackageManager.PERMISSION_GRANTED
        items += PermissionAuditItem(
            permission = Manifest.permission.ACCESS_NETWORK_STATE,
            title = "Network Transport State",
            category = "Install-Time Normal",
            isGranted = netGranted,
            isRuntimePermission = false,
            rationale = "Inspects Wi-Fi, Cellular, VPN, and validated link capabilities for compliance checks."
        )

        val internetGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.INTERNET
        ) == PackageManager.PERMISSION_GRANTED
        items += PermissionAuditItem(
            permission = Manifest.permission.INTERNET,
            title = "Cloud MDM Synchronization",
            category = "Install-Time Normal",
            isGranted = internetGranted,
            isRuntimePermission = false,
            rationale = "Synchronizes device inventory, security policies, and signed remote commands."
        )

        return items
    }
}
