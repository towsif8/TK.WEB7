package com.example.platform

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

data class NativeSettingItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val action: String,
    val requiresPackageUri: Boolean = false,
)

class NativeSettingsNavigator(private val context: Context) {

    val supportedSettings: List<NativeSettingItem> = listOf(
        NativeSettingItem("display", "Display & Brightness", "Screen timeout, brightness, dark mode", Settings.ACTION_DISPLAY_SETTINGS),
        NativeSettingItem("sound", "Sound & Volume", "Media, ring, alarm & vibration controls", Settings.ACTION_SOUND_SETTINGS),
        NativeSettingItem("wifi", "Wi-Fi & Network", "SSIDs, private DNS, saved networks", Settings.ACTION_WIFI_SETTINGS),
        NativeSettingItem("bluetooth", "Bluetooth", "Paired peripherals & scan controls", Settings.ACTION_BLUETOOTH_SETTINGS),
        NativeSettingItem("battery", "Battery & Power", "Usage, adaptive battery, saver", Settings.ACTION_BATTERY_SAVER_SETTINGS),
        NativeSettingItem("notifications", "Notifications", "Channel & app alert policies", Settings.ACTION_APP_NOTIFICATION_SETTINGS),
        NativeSettingItem("accessibility", "Accessibility", "Screen readers & interaction services", Settings.ACTION_ACCESSIBILITY_SETTINGS),
        NativeSettingItem("security", "Security & Lock", "Screen lock, biometrics, encryption", Settings.ACTION_SECURITY_SETTINGS),
        NativeSettingItem("permissions", "App Permissions", "Titan MDM runtime permission manager", Settings.ACTION_APPLICATION_DETAILS_SETTINGS, requiresPackageUri = true),
        NativeSettingItem("storage", "Storage", "Internal disk usage & cache management", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
    )

    fun openSetting(item: NativeSettingItem): Boolean {
        val intent = when (item.id) {
            "notifications" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    }
                } else {
                    Intent(Settings.ACTION_SETTINGS)
                }
            }
            else -> Intent(item.action).apply {
                if (item.requiresPackageUri) {
                    data = Uri.fromParts("package", context.packageName, null)
                }
            }
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    fun openDeviceAdminSettings(): Boolean {
        val intent = Intent().apply {
            action = Settings.ACTION_SECURITY_SETTINGS
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
