package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.example.model.AccountStatus
import com.example.model.ActivityLog
import com.example.model.AdminAccount
import com.example.model.AdminSession
import com.example.model.ComplianceState
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentStatus
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.LocalSecurityAuditResult
import com.example.model.ManagedDevice
import com.example.model.ManagedUser
import com.example.model.MdmRole
import com.example.model.RemoteCommand
import com.example.model.RemoteCommandType
import com.example.model.SecurityReport
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

class TitanMdmRepository(
    private val db: FirebaseFirestore,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth get() = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    private fun isBootstrappedSuperAdmin(email: String?): Boolean =
        email.equals(BOOTSTRAPPED_SUPER_ADMIN_EMAIL, ignoreCase = true)

    private fun sha256Hex(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun sanitizeId(raw: String): String =
        raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(120).ifBlank { "id_${UUID.randomUUID().toString().take(8)}" }

    // --- REALTIME OBSERVATION FLOWS ---

    fun observeAdmins(uid: String, email: String?): Flow<List<AdminAccount>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_ADMINS)
        } else {
            db.collection(COL_ADMINS).whereEqualTo("uid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(AdminAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_ADMINS, uid); throw error }
    }

    fun observeUsers(uid: String, email: String?): Flow<List<ManagedUser>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_USERS)
        } else {
            db.collection(COL_USERS).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(ManagedUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_USERS, uid); throw error }
    }

    fun observeDevices(uid: String, email: String?): Flow<List<ManagedDevice>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_DEVICES)
        } else {
            db.collection(COL_DEVICES).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(ManagedDevice::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_DEVICES, uid); throw error }
    }

    fun observePolicies(uid: String, email: String?): Flow<List<DevicePolicyRecord>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_POLICIES)
        } else {
            db.collection(COL_POLICIES).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(DevicePolicyRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_POLICIES, uid); throw error }
    }

    fun observeRemoteCommands(uid: String, email: String?): Flow<List<RemoteCommand>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_COMMANDS)
        } else {
            db.collection(COL_COMMANDS).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(RemoteCommand::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_COMMANDS, uid); throw error }
    }

    fun observeSecurityReports(uid: String, email: String?): Flow<List<SecurityReport>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_REPORTS)
        } else {
            db.collection(COL_REPORTS).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(SecurityReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_REPORTS, uid); throw error }
    }

    fun observeActivityLogs(uid: String, email: String?): Flow<List<ActivityLog>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_LOGS)
        } else {
            db.collection(COL_LOGS).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(ActivityLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_LOGS, uid); throw error }
    }

    fun observeAdminSessions(uid: String, email: String?): Flow<List<AdminSession>> {
        val query = if (isBootstrappedSuperAdmin(email)) {
            db.collection(COL_SESSIONS)
        } else {
            db.collection(COL_SESSIONS).whereEqualTo("ownerUid", uid)
        }
        return query.snapshots()
            .map { snap -> snap.toObjects(AdminSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error -> logFlowError(error, COL_SESSIONS, uid); throw error }
    }

    private fun logFlowError(error: Throwable, path: String, uid: String) {
        if (error is CancellationException && error.cause == null) return
        if (auth.currentUser?.uid == uid) {
            handleFirestoreError(error, OperationType.LIST, path)
        }
    }

    // --- BOOTSTRAP & SESSION MANAGEMENT ---

    suspend fun bootstrapSessionAndAccount(
        uid: String,
        email: String,
        displayName: String,
        deviceModel: String,
    ): Result<String> = runCatching {
        val isSuper = isBootstrappedSuperAdmin(email)
        val initialRole = if (isSuper) MdmRole.SUPER_ADMIN.name else MdmRole.MEMBER.name
        val safeName = displayName.ifBlank { email.substringBefore("@").ifBlank { "Operator" } }.take(100)

        // 1. Ensure /users/{uid} exists
        val userRef = db.collection(COL_USERS).document(uid)
        val userSnap = try {
            userRef.get().await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, userRef.path)
            throw e
        }
        if (!userSnap.exists()) {
            val userPayload = ManagedUser(
                uid = uid,
                ownerUid = uid,
                email = email,
                displayName = safeName,
                department = if (isSuper) "Command Security" else "Enterprise Mobility",
                role = initialRole,
                status = AccountStatus.ACTIVE.name,
                enrolledDeviceCount = 0L,
                assignedPolicyId = "policy_baseline_$uid",
                allowedFeatures = listOf("TELEMETRY", "SECURITY_SCAN", "APP_AUDIT", "POLICY_SYNC")
            ).toCreateMap()
            try {
                userRef.set(userPayload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, userRef.path)
                throw e
            }
        }

        // 2. If bootstrapped Super Admin, ensure /admins/{uid} exists
        var resolvedRole = initialRole
        val adminRef = db.collection(COL_ADMINS).document(uid)
        val adminSnap = try {
            adminRef.get().await()
        } catch (_: Exception) {
            null
        }
        if (adminSnap != null && adminSnap.exists()) {
            resolvedRole = adminSnap.getString("role") ?: initialRole
        } else if (isSuper) {
            val adminPayload = AdminAccount(
                uid = uid,
                email = email,
                displayName = safeName,
                role = MdmRole.SUPER_ADMIN.name,
                status = AccountStatus.ACTIVE.name,
                department = "Enterprise Command",
                createdBy = uid
            ).toCreateMap()
            try {
                adminRef.set(adminPayload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, adminRef.path)
                throw e
            }
        }

        // 3. Ensure baseline policy exists for user/org
        val baselinePolicyId = sanitizeId("policy_baseline_$uid")
        val policyRef = db.collection(COL_POLICIES).document(baselinePolicyId)
        val policySnap = try { policyRef.get().await() } catch (_: Exception) { null }
        if (policySnap != null && !policySnap.exists()) {
            val policyPayload = DevicePolicyRecord(
                ownerUid = uid,
                name = "Titan Baseline Security Policy",
                description = "Requires screen lock, encrypted storage, and audits unknown app sources.",
                isDefaultPolicy = isSuper,
                requireScreenLock = true,
                minPasswordLength = 6L,
                requireEncryption = true,
                disableCamera = false,
                disableUsbFileTransfer = false,
                blockUnknownSources = true,
                maxFailedPasswordsForWipe = 0L,
                screenTimeoutSeconds = 120L,
                appAllowlist = emptyList(),
                appBlocklist = emptyList(),
                version = 1L
            ).toCreateMap()
            try {
                policyRef.set(policyPayload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, policyRef.path)
            }
        }

        // 4. Create active AdminSession
        val sessionId = sanitizeId("sess_${uid.take(8)}_${System.currentTimeMillis()}")
        val nowMs = System.currentTimeMillis()
        val sessionRef = db.collection(COL_SESSIONS).document(sessionId)
        val sessionPayload = AdminSession(
            ownerUid = uid,
            adminUid = uid,
            adminEmail = email,
            role = resolvedRole,
            deviceModel = deviceModel.take(120),
            status = "ACTIVE",
            startedAtEpochMs = nowMs,
            lastActiveAtEpochMs = nowMs
        ).toCreateMap()
        try {
            sessionRef.set(sessionPayload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, sessionRef.path)
        }

        appendActivityLog(
            ownerUid = uid,
            actorUid = uid,
            actorEmail = email,
            actorRole = resolvedRole,
            action = "AUTH_SESSION_STARTED",
            targetType = "SESSION",
            targetId = sessionId,
            details = "Authenticated session initialized on $deviceModel",
            severity = "INFO"
        )

        sessionId
    }

    suspend fun revokeSession(session: AdminSession, actorEmail: String, actorRole: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COL_SESSIONS).document(session.id)
        try {
            docRef.update(
                mapOf(
                    "status" to "REVOKED",
                    "lastActiveAtEpochMs" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = session.ownerUid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "REVOKE_ADMIN_SESSION",
            targetType = "SESSION",
            targetId = session.id,
            details = "Revoked session for ${session.adminEmail} on ${session.deviceModel}",
            severity = "WARNING"
        )
    }

    // --- ADMIN & USER RBAC OPERATIONS ---

    suspend fun upsertAdminAccount(
        targetUid: String,
        email: String,
        displayName: String,
        role: MdmRole,
        status: AccountStatus,
        department: String,
        actorEmail: String,
        actorRole: String,
    ): Result<Unit> = runCatching {
        val actorUid = requireUserId()
        val docId = sanitizeId(targetUid)
        val docRef = db.collection(COL_ADMINS).document(docId)
        val existing = docRef.get().await()
        if (existing.exists()) {
            try {
                docRef.update(
                    mapOf(
                        "email" to email.trim(),
                        "displayName" to displayName.trim().take(100),
                        "role" to role.name,
                        "status" to status.name,
                        "department" to department.trim().take(100),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                throw e
            }
        } else {
            val payload = AdminAccount(
                uid = docId,
                email = email.trim(),
                displayName = displayName.trim().take(100),
                role = role.name,
                status = status.name,
                department = department.trim().ifBlank { "Security" }.take(100),
                createdBy = actorUid
            ).toCreateMap()
            try {
                docRef.set(payload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                throw e
            }
        }

        appendActivityLog(
            ownerUid = actorUid,
            actorUid = actorUid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "UPSERT_ADMIN_RBAC",
            targetType = "ADMIN",
            targetId = docId,
            details = "Set $email role=${role.name}, status=${status.name}",
            severity = if (status != AccountStatus.ACTIVE) "WARNING" else "INFO"
        )
    }

    suspend fun createManagedUser(
        email: String,
        displayName: String,
        department: String,
        role: MdmRole,
        actorEmail: String,
        actorRole: String,
    ): Result<String> = runCatching {
        val actorUid = requireUserId()
        val userId = sanitizeId("usr_${UUID.randomUUID().toString().replace("-", "").take(12)}")
        val docRef = db.collection(COL_USERS).document(userId)
        val payload = ManagedUser(
            uid = userId,
            ownerUid = actorUid,
            email = email.trim(),
            displayName = displayName.trim().take(100),
            department = department.trim().ifBlank { "General" }.take(100),
            role = role.name,
            status = AccountStatus.ACTIVE.name,
            enrolledDeviceCount = 0L,
            assignedPolicyId = "",
            allowedFeatures = listOf("TELEMETRY", "SECURITY_SCAN", "APP_AUDIT")
        ).toCreateMap()
        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = actorUid,
            actorUid = actorUid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "CREATE_MANAGED_USER",
            targetType = "USER",
            targetId = userId,
            details = "Provisioned user $email (${role.name}) in $department",
            severity = "INFO"
        )
        userId
    }

    suspend fun updateManagedUserStatusAndRole(
        user: ManagedUser,
        newRole: MdmRole,
        newStatus: AccountStatus,
        assignedPolicyId: String,
        allowedFeatures: List<String>,
        actorEmail: String,
        actorRole: String,
    ): Result<Unit> = runCatching {
        val actorUid = requireUserId()
        val docRef = db.collection(COL_USERS).document(user.id)
        try {
            docRef.update(
                mapOf(
                    "role" to newRole.name,
                    "status" to newStatus.name,
                    "assignedPolicyId" to assignedPolicyId,
                    "allowedFeatures" to allowedFeatures.take(15),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = user.ownerUid,
            actorUid = actorUid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "UPDATE_USER_ACCESS",
            targetType = "USER",
            targetId = user.id,
            details = "Updated ${user.email}: role=${newRole.name}, status=${newStatus.name}",
            severity = if (newStatus != AccountStatus.ACTIVE) "WARNING" else "INFO"
        )
    }

    // --- DEVICE ENROLLMENT & MANAGEMENT ---

    suspend fun enrollCurrentDevice(
        snapshot: DeviceHardwareSnapshot,
        enterprise: EnterpriseCapabilitiesStatus,
        actorEmail: String,
        actorRole: String,
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val deviceDocId = sanitizeId("${snapshot.deviceId}_${uid.take(6)}")
        val docRef = db.collection(COL_DEVICES).document(deviceDocId)
        val tokenHash = sha256Hex("$uid|${snapshot.deviceId}|${snapshot.model}|TITAN_ENROLL")

        val compliance = when {
            snapshot.isRootSuspected || !snapshot.isDeviceEncrypted -> ComplianceState.NON_COMPLIANT.name
            !snapshot.isScreenLockConfigured || snapshot.isAdbEnabled -> ComplianceState.AT_RISK.name
            else -> ComplianceState.COMPLIANT.name
        }

        val existing = docRef.get().await()
        if (existing.exists()) {
            try {
                docRef.update(
                    mapOf(
                        "deviceName" to snapshot.deviceName.take(120),
                        "androidVersion" to snapshot.androidVersion.take(40),
                        "sdkInt" to snapshot.sdkInt.toLong(),
                        "enrollmentMode" to enterprise.enrollmentMode.name,
                        "enrollmentStatus" to EnrollmentStatus.ENROLLED.name,
                        "complianceState" to compliance,
                        "securityPatch" to snapshot.securityPatch.take(40),
                        "isDeviceEncrypted" to snapshot.isDeviceEncrypted,
                        "isRootSuspected" to snapshot.isRootSuspected,
                        "batteryLevel" to snapshot.batteryPercent.toLong(),
                        "storageUsedMb" to snapshot.storageUsedMb,
                        "storageTotalMb" to snapshot.storageTotalMb,
                        "ramUsedMb" to snapshot.ramUsedMb,
                        "ramTotalMb" to snapshot.ramTotalMb,
                        "networkType" to snapshot.networkType.take(64),
                        "lastHeartbeatAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                throw e
            }
        } else {
            val payload = ManagedDevice(
                ownerUid = uid,
                assignedUserId = uid,
                deviceName = snapshot.deviceName.take(120),
                manufacturer = snapshot.manufacturer.take(80),
                model = snapshot.model.take(100),
                androidVersion = snapshot.androidVersion.take(40),
                sdkInt = snapshot.sdkInt.toLong(),
                enrollmentMode = enterprise.enrollmentMode.name,
                enrollmentStatus = EnrollmentStatus.ENROLLED.name,
                complianceState = compliance,
                securityPatch = snapshot.securityPatch.take(40),
                isDeviceEncrypted = snapshot.isDeviceEncrypted,
                isRootSuspected = snapshot.isRootSuspected,
                batteryLevel = snapshot.batteryPercent.toLong(),
                storageUsedMb = snapshot.storageUsedMb,
                storageTotalMb = snapshot.storageTotalMb,
                ramUsedMb = snapshot.ramUsedMb,
                ramTotalMb = snapshot.ramTotalMb,
                networkType = snapshot.networkType.take(64),
                assignedPolicyId = sanitizeId("policy_baseline_$uid"),
                policySyncVersion = 1L,
                enrollmentTokenHash = tokenHash
            ).toCreateMap()
            try {
                docRef.set(payload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                throw e
            }
        }

        appendActivityLog(
            ownerUid = uid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "DEVICE_ENROLLED",
            targetType = "DEVICE",
            targetId = deviceDocId,
            details = "Enrolled ${snapshot.manufacturer} ${snapshot.model} (${enterprise.enrollmentMode.name})",
            severity = "INFO"
        )
        deviceDocId
    }

    suspend fun pushDeviceTelemetryHeartbeat(
        deviceId: String,
        snapshot: DeviceHardwareSnapshot,
        enterprise: EnterpriseCapabilitiesStatus,
    ): Result<Unit> = runCatching {
        requireUserId()
        val compliance = when {
            snapshot.isRootSuspected || !snapshot.isDeviceEncrypted -> ComplianceState.NON_COMPLIANT.name
            !snapshot.isScreenLockConfigured || snapshot.isAdbEnabled -> ComplianceState.AT_RISK.name
            else -> ComplianceState.COMPLIANT.name
        }
        val docRef = db.collection(COL_DEVICES).document(deviceId)
        try {
            docRef.update(
                mapOf(
                    "enrollmentMode" to enterprise.enrollmentMode.name,
                    "complianceState" to compliance,
                    "isDeviceEncrypted" to snapshot.isDeviceEncrypted,
                    "isRootSuspected" to snapshot.isRootSuspected,
                    "batteryLevel" to snapshot.batteryPercent.toLong(),
                    "storageUsedMb" to snapshot.storageUsedMb,
                    "storageTotalMb" to snapshot.storageTotalMb,
                    "ramUsedMb" to snapshot.ramUsedMb,
                    "ramTotalMb" to snapshot.ramTotalMb,
                    "networkType" to snapshot.networkType.take(64),
                    "lastHeartbeatAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updateDeviceEnrollmentStatus(
        device: ManagedDevice,
        newStatus: EnrollmentStatus,
        actorEmail: String,
        actorRole: String,
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COL_DEVICES).document(device.id)
        try {
            docRef.update(
                mapOf(
                    "enrollmentStatus" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = device.ownerUid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "DEVICE_STATUS_CHANGED",
            targetType = "DEVICE",
            targetId = device.id,
            details = "${device.deviceName} status -> ${newStatus.name}",
            severity = if (newStatus == EnrollmentStatus.REVOKED) "CRITICAL" else "WARNING"
        )
    }

    suspend fun assignPolicyToDevice(
        device: ManagedDevice,
        policy: DevicePolicyRecord,
        actorEmail: String,
        actorRole: String,
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection(COL_DEVICES).document(device.id)
        try {
            docRef.update(
                mapOf(
                    "assignedPolicyId" to policy.id,
                    "policySyncVersion" to policy.version,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = device.ownerUid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "DEVICE_POLICY_SYNCED",
            targetType = "DEVICE",
            targetId = device.id,
            details = "Applied policy '${policy.name}' v${policy.version} to ${device.deviceName}",
            severity = "INFO"
        )
    }

    // --- POLICIES ---

    suspend fun savePolicyRecord(
        policy: DevicePolicyRecord,
        actorEmail: String,
        actorRole: String,
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val policyId = if (policy.id.isNotBlank()) sanitizeId(policy.id) else sanitizeId("pol_${UUID.randomUUID().toString().take(10)}")
        val docRef = db.collection(COL_POLICIES).document(policyId)
        val snap = docRef.get().await()
        if (snap.exists()) {
            try {
                docRef.update(
                    mapOf(
                        "name" to policy.name.take(100),
                        "description" to policy.description.take(500),
                        "requireScreenLock" to policy.requireScreenLock,
                        "minPasswordLength" to policy.minPasswordLength.coerceIn(0L, 32L),
                        "requireEncryption" to policy.requireEncryption,
                        "disableCamera" to policy.disableCamera,
                        "disableUsbFileTransfer" to policy.disableUsbFileTransfer,
                        "blockUnknownSources" to policy.blockUnknownSources,
                        "maxFailedPasswordsForWipe" to policy.maxFailedPasswordsForWipe.coerceIn(0L, 50L),
                        "screenTimeoutSeconds" to policy.screenTimeoutSeconds.coerceIn(15L, 3600L),
                        "appAllowlist" to policy.appAllowlist.take(100),
                        "appBlocklist" to policy.appBlocklist.take(100),
                        "version" to (policy.version + 1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                throw e
            }
        } else {
            val payload = policy.copy(ownerUid = uid, version = 1L).toCreateMap()
            try {
                docRef.set(payload).await()
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                throw e
            }
        }
        appendActivityLog(
            ownerUid = uid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "POLICY_SAVED",
            targetType = "POLICY",
            targetId = policyId,
            details = "Saved policy '${policy.name}'",
            severity = "INFO"
        )
        policyId
    }

    // --- SECURE REMOTE COMMAND QUEUE ---

    suspend fun queueRemoteCommand(
        targetDevice: ManagedDevice,
        commandType: RemoteCommandType,
        payloadSummary: String,
        actorEmail: String,
        actorRole: String,
        ttlMinutes: Long = 30L,
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val cmdId = sanitizeId("cmd_${UUID.randomUUID().toString().replace("-", "").take(12)}")
        val nonce = UUID.randomUUID().toString().replace("-", "")
        val nowMs = System.currentTimeMillis()
        val expiresAt = nowMs + (ttlMinutes.coerceIn(5L, 1440L) * 60_000L)
        val signatureDigest = sha256Hex("$cmdId|${targetDevice.id}|${commandType.name}|$nonce|$uid|$expiresAt")

        val docRef = db.collection(COL_COMMANDS).document(cmdId)
        val payload = RemoteCommand(
            ownerUid = targetDevice.ownerUid,
            targetDeviceId = targetDevice.id,
            issuedByUid = uid,
            issuedByEmail = actorEmail,
            commandType = commandType.name,
            payloadSummary = payloadSummary.take(500),
            nonce = nonce,
            signatureDigest = signatureDigest,
            status = "QUEUED",
            ackMessage = "",
            expiresAtEpochMs = expiresAt,
            acknowledgedAtEpochMs = 0L
        ).toCreateMap()

        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }

        appendActivityLog(
            ownerUid = targetDevice.ownerUid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "REMOTE_COMMAND_QUEUED",
            targetType = "DEVICE",
            targetId = targetDevice.id,
            details = "Queued ${commandType.name} (nonce=${nonce.take(8)}) for ${targetDevice.deviceName}",
            severity = if (commandType == RemoteCommandType.REVOKE_ENROLLMENT || commandType == RemoteCommandType.LOCK_NOW) "WARNING" else "INFO"
        )
        cmdId
    }

    suspend fun acknowledgeRemoteCommand(
        command: RemoteCommand,
        newStatus: String,
        ackMessage: String,
        actorEmail: String,
        actorRole: String,
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nowMs = System.currentTimeMillis()
        val finalStatus = if (nowMs > command.expiresAtEpochMs && newStatus == "EXECUTED") {
            "EXPIRED"
        } else {
            newStatus
        }
        val docRef = db.collection(COL_COMMANDS).document(command.id)
        try {
            docRef.update(
                mapOf(
                    "status" to finalStatus,
                    "ackMessage" to ackMessage.take(500),
                    "acknowledgedAtEpochMs" to nowMs,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = command.ownerUid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "REMOTE_COMMAND_${finalStatus}",
            targetType = "COMMAND",
            targetId = command.id,
            details = "${command.commandType}: $ackMessage",
            severity = if (finalStatus == "FAILED" || finalStatus == "EXPIRED") "WARNING" else "INFO"
        )
    }

    // --- SECURITY REPORTS & AUDIT LOGS ---

    suspend fun publishSecurityReport(
        deviceId: String,
        audit: LocalSecurityAuditResult,
        actorEmail: String,
        actorRole: String,
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val reportId = sanitizeId("rep_${UUID.randomUUID().toString().replace("-", "").take(12)}")
        val docRef = db.collection(COL_REPORTS).document(reportId)
        val findingStrings = audit.findings.take(40).map {
            "[${it.certainty.name}/${it.severity.name}] ${it.title}: ${it.description}"
        }
        val payload = SecurityReport(
            ownerUid = uid,
            deviceId = sanitizeId(deviceId),
            overallRiskScore = audit.riskScore.toLong(),
            confirmedFindingsCount = audit.confirmedFindingsCount.toLong(),
            potentialRisksCount = audit.potentialRisksCount.toLong(),
            installedAppsScanned = audit.installedAppsScanned.toLong(),
            deviceIntegrityPassed = audit.deviceIntegrityPassed,
            networkSecurityGrade = audit.networkSecurityGrade,
            summary = audit.summary.take(600),
            findings = findingStrings
        ).toCreateMap()
        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
        appendActivityLog(
            ownerUid = uid,
            actorUid = uid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = "SECURITY_AUDIT_PUBLISHED",
            targetType = "SECURITY_REPORT",
            targetId = reportId,
            details = "Risk=${audit.riskScore}/100, Confirmed=${audit.confirmedFindingsCount}, Potential=${audit.potentialRisksCount}",
            severity = if (audit.confirmedFindingsCount > 0) "CRITICAL" else "INFO"
        )
        reportId
    }

    suspend fun appendActivityLog(
        ownerUid: String,
        actorUid: String,
        actorEmail: String,
        actorRole: String,
        action: String,
        targetType: String,
        targetId: String,
        details: String,
        severity: String,
    ) {
        val logId = sanitizeId("log_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}")
        val docRef = db.collection(COL_LOGS).document(logId)
        val payload = ActivityLog(
            ownerUid = ownerUid,
            actorUid = actorUid,
            actorEmail = actorEmail,
            actorRole = actorRole,
            action = action.take(120),
            targetType = targetType.take(64),
            targetId = targetId.take(128),
            details = details.take(600),
            severity = severity
        ).toCreateMap()
        try {
            docRef.set(payload).await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
        }
    }

    companion object {
        const val BOOTSTRAPPED_SUPER_ADMIN_EMAIL = "sahadat.khan3445@gmail.com"
        const val COL_ADMINS = "admins"
        const val COL_USERS = "users"
        const val COL_DEVICES = "devices"
        const val COL_POLICIES = "policy_records"
        const val COL_COMMANDS = "remote_commands"
        const val COL_REPORTS = "security_reports"
        const val COL_LOGS = "activity_logs"
        const val COL_SESSIONS = "admin_sessions"
    }
}
