package com.example.data.local

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.DeviceHardwareSnapshot
import com.example.model.LocalSecurityAuditResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class FileIntegrityCheckResult(
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val sha256Hash: String,
    val riskAssessment: String,
    val isSuspiciousExtension: Boolean,
)

class LocalCacheRepository(
    private val context: Context,
    private val database: TitanDatabase = TitanDatabase.getInstance(context),
) {
    private val telemetryDao = database.telemetryDao()
    private val scanDao = database.localScanDao()
    private val quarantineDao = database.quarantineDao()

    val recentTelemetry: Flow<List<TelemetrySnapshotEntity>> = telemetryDao.observeRecentTelemetry()
    val scanHistory: Flow<List<LocalScanHistoryEntity>> = scanDao.observeScanHistory()
    val quarantinedFiles: Flow<List<QuarantinedFileEntity>> = quarantineDao.observeQuarantinedFiles()

    suspend fun recordTelemetry(snapshot: DeviceHardwareSnapshot) = withContext(Dispatchers.IO) {
        telemetryDao.insertSnapshot(
            TelemetrySnapshotEntity(
                deviceId = snapshot.deviceId,
                batteryPercent = snapshot.batteryPercent,
                ramUsedMb = snapshot.ramUsedMb,
                ramTotalMb = snapshot.ramTotalMb,
                storageUsedMb = snapshot.storageUsedMb,
                storageTotalMb = snapshot.storageTotalMb,
                networkType = snapshot.networkType,
                isDeviceEncrypted = snapshot.isDeviceEncrypted,
                isRootSuspected = snapshot.isRootSuspected,
                capturedAtEpochMs = snapshot.capturedAtEpochMs
            )
        )
        telemetryDao.pruneOldSnapshots()
    }

    suspend fun recordSecurityScan(result: LocalSecurityAuditResult) = withContext(Dispatchers.IO) {
        val array = JSONArray()
        result.findings.forEach { finding ->
            array.put(
                JSONObject().apply {
                    put("id", finding.id)
                    put("title", finding.title)
                    put("certainty", finding.certainty.name)
                    put("severity", finding.severity.name)
                    put("category", finding.category)
                }
            )
        }
        scanDao.insertScan(
            LocalScanHistoryEntity(
                riskScore = result.riskScore,
                confirmedFindingsCount = result.confirmedFindingsCount,
                potentialRisksCount = result.potentialRisksCount,
                installedAppsScanned = result.installedAppsScanned,
                deviceIntegrityPassed = result.deviceIntegrityPassed,
                networkSecurityGrade = result.networkSecurityGrade,
                summary = result.summary,
                findingsJson = array.toString(),
                scannedAtEpochMs = result.scannedAtEpochMs
            )
        )
    }

    suspend fun inspectUserSelectedFile(uri: Uri): Result<FileIntegrityCheckResult> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            var displayName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                ?: "selected_file"
            var sizeBytes = 0L
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                        if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            } catch (_: Exception) {
                // Fallback to lastPathSegment when provider does not support OpenableColumns query
            }
            val mimeType = resolver.getType(uri) ?: "application/octet-stream"
            val digest = MessageDigest.getInstance("SHA-256")
            var countedBytes = 0L
            val headerBytes = ByteArray(4)
            var headerRead = 0
            resolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    if (headerRead < 4) {
                        val copyLen = minOf(4 - headerRead, read)
                        System.arraycopy(buffer, 0, headerBytes, headerRead, copyLen)
                        headerRead += copyLen
                    }
                    digest.update(buffer, 0, read)
                    countedBytes += read
                }
            } ?: error("Unable to open selected file stream")

            val actualSize = if (sizeBytes > 0L) sizeBytes else countedBytes
            val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
            val lowerName = displayName.lowercase()
            val isApkOrExec = lowerName.endsWith(".apk") || lowerName.endsWith(".dex") ||
                lowerName.endsWith(".sh") || lowerName.endsWith(".jar") ||
                (headerRead >= 2 && headerBytes[0] == 'P'.code.toByte() && headerBytes[1] == 'K'.code.toByte() && lowerName.endsWith(".apk"))
            val assessment = when {
                isApkOrExec -> "Executable/APK archive detected ($mimeType). Review origin before installation."
                actualSize == 0L -> "Zero-byte file detected. Possible corrupt or truncated artifact."
                else -> "SHA-256 digest verified ($mimeType). Safe for standard document handling."
            }
            FileIntegrityCheckResult(
                displayName = displayName,
                mimeType = mimeType,
                sizeBytes = actualSize,
                sha256Hash = sha256,
                riskAssessment = assessment,
                isSuspiciousExtension = isApkOrExec
            )
        }
    }

    suspend fun quarantineUserSelectedFile(
        uri: Uri,
        reason: String,
    ): Result<QuarantinedFileEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val check = inspectUserSelectedFile(uri).getOrThrow()
            val vaultDir = File(context.filesDir, "quarantine").apply { mkdirs() }
            val qId = "quar_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val vaultFile = File(vaultDir, "$qId.vault")

            context.contentResolver.openInputStream(uri)?.use { input ->
                vaultFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: error("Unable to copy selected file into quarantine vault")

            val entity = QuarantinedFileEntity(
                quarantineId = qId,
                originalDisplayName = check.displayName,
                mimeType = check.mimeType,
                fileSizeBytes = check.sizeBytes,
                sha256Hash = check.sha256Hash,
                vaultPath = vaultFile.absolutePath,
                riskReason = reason.ifBlank { check.riskAssessment },
                status = "ISOLATED",
                quarantinedAtEpochMs = System.currentTimeMillis()
            )
            quarantineDao.insertQuarantinedFile(entity)
            entity
        }
    }

    suspend fun purgeQuarantinedFile(entity: QuarantinedFileEntity) = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(entity.vaultPath)
            if (file.exists()) {
                file.delete()
            }
            quarantineDao.deleteById(entity.quarantineId)
        }
    }
}
