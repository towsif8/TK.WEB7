package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.titanPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "titan_mdm_prefs")

enum class WorkspaceMode(val label: String) {
    ADMIN_CONSOLE("Admin Console"),
    MEMBER_AGENT("Member Agent");

    companion object {
        fun fromString(value: String?): WorkspaceMode =
            entries.firstOrNull { it.name == value } ?: ADMIN_CONSOLE
    }
}

data class TitanLocalSettings(
    val autoTelemetrySyncEnabled: Boolean = true,
    val syncIntervalMinutes: Int = 30,
    val threatAlertsEnabled: Boolean = true,
    val strictAuditMode: Boolean = false,
    val enrolledDeviceId: String = "",
    val lastAdminEventMessage: String = "",
    val preferredWorkspaceMode: WorkspaceMode = WorkspaceMode.ADMIN_CONSOLE,
)

class PreferencesStore(private val context: Context) {

    private object Keys {
        val AUTO_SYNC = booleanPreferencesKey("auto_telemetry_sync")
        val SYNC_INTERVAL_MIN = intPreferencesKey("sync_interval_minutes")
        val THREAT_ALERTS = booleanPreferencesKey("threat_alerts_enabled")
        val STRICT_AUDIT = booleanPreferencesKey("strict_audit_mode")
        val ENROLLED_DEVICE_ID = stringPreferencesKey("enrolled_device_id")
        val LAST_ADMIN_EVENT = stringPreferencesKey("last_admin_event")
        val WORKSPACE_MODE = stringPreferencesKey("preferred_workspace_mode")
    }

    val settingsFlow: Flow<TitanLocalSettings> = context.titanPrefsDataStore.data.map { prefs ->
        TitanLocalSettings(
            autoTelemetrySyncEnabled = prefs[Keys.AUTO_SYNC] ?: true,
            syncIntervalMinutes = prefs[Keys.SYNC_INTERVAL_MIN] ?: 30,
            threatAlertsEnabled = prefs[Keys.THREAT_ALERTS] ?: true,
            strictAuditMode = prefs[Keys.STRICT_AUDIT] ?: false,
            enrolledDeviceId = prefs[Keys.ENROLLED_DEVICE_ID] ?: "",
            lastAdminEventMessage = prefs[Keys.LAST_ADMIN_EVENT] ?: "",
            preferredWorkspaceMode = WorkspaceMode.fromString(prefs[Keys.WORKSPACE_MODE])
        )
    }

    suspend fun setAutoTelemetrySync(enabled: Boolean) {
        context.titanPrefsDataStore.edit { it[Keys.AUTO_SYNC] = enabled }
    }

    suspend fun setSyncIntervalMinutes(minutes: Int) {
        context.titanPrefsDataStore.edit { it[Keys.SYNC_INTERVAL_MIN] = minutes.coerceIn(15, 360) }
    }

    suspend fun setThreatAlertsEnabled(enabled: Boolean) {
        context.titanPrefsDataStore.edit { it[Keys.THREAT_ALERTS] = enabled }
    }

    suspend fun setStrictAuditMode(enabled: Boolean) {
        context.titanPrefsDataStore.edit { it[Keys.STRICT_AUDIT] = enabled }
    }

    suspend fun setEnrolledDeviceId(deviceId: String) {
        context.titanPrefsDataStore.edit { it[Keys.ENROLLED_DEVICE_ID] = deviceId }
    }

    suspend fun setLastAdminEvent(message: String) {
        context.titanPrefsDataStore.edit { it[Keys.LAST_ADMIN_EVENT] = message }
    }

    suspend fun setPreferredWorkspaceMode(mode: WorkspaceMode) {
        context.titanPrefsDataStore.edit { it[Keys.WORKSPACE_MODE] = mode.name }
    }
}
