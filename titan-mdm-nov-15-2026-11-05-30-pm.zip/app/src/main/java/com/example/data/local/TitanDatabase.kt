package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "telemetry_snapshots")
data class TelemetrySnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val deviceId: String,
    val batteryPercent: Int,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val storageUsedMb: Long,
    val storageTotalMb: Long,
    val networkType: String,
    val isDeviceEncrypted: Boolean,
    val isRootSuspected: Boolean,
    val capturedAtEpochMs: Long,
)

@Entity(tableName = "local_security_scans")
data class LocalScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val riskScore: Int,
    val confirmedFindingsCount: Int,
    val potentialRisksCount: Int,
    val installedAppsScanned: Int,
    val deviceIntegrityPassed: Boolean,
    val networkSecurityGrade: String,
    val summary: String,
    val findingsJson: String,
    val scannedAtEpochMs: Long,
)

@Entity(tableName = "quarantined_files")
data class QuarantinedFileEntity(
    @PrimaryKey val quarantineId: String,
    val originalDisplayName: String,
    val mimeType: String,
    val fileSizeBytes: Long,
    val sha256Hash: String,
    val vaultPath: String,
    val riskReason: String,
    val status: String,
    val quarantinedAtEpochMs: Long,
)

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM telemetry_snapshots ORDER BY capturedAtEpochMs DESC LIMIT 30")
    fun observeRecentTelemetry(): Flow<List<TelemetrySnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: TelemetrySnapshotEntity)

    @Query("DELETE FROM telemetry_snapshots WHERE id NOT IN (SELECT id FROM telemetry_snapshots ORDER BY capturedAtEpochMs DESC LIMIT 50)")
    suspend fun pruneOldSnapshots()
}

@Dao
interface LocalScanDao {
    @Query("SELECT * FROM local_security_scans ORDER BY scannedAtEpochMs DESC LIMIT 25")
    fun observeScanHistory(): Flow<List<LocalScanHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: LocalScanHistoryEntity)
}

@Dao
interface QuarantineDao {
    @Query("SELECT * FROM quarantined_files ORDER BY quarantinedAtEpochMs DESC")
    fun observeQuarantinedFiles(): Flow<List<QuarantinedFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuarantinedFile(entity: QuarantinedFileEntity)

    @Query("DELETE FROM quarantined_files WHERE quarantineId = :quarantineId")
    suspend fun deleteById(quarantineId: String)
}

@Database(
    entities = [
        TelemetrySnapshotEntity::class,
        LocalScanHistoryEntity::class,
        QuarantinedFileEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class TitanDatabase : RoomDatabase() {
    abstract fun telemetryDao(): TelemetryDao
    abstract fun localScanDao(): LocalScanDao
    abstract fun quarantineDao(): QuarantineDao

    companion object {
        @Volatile
        private var INSTANCE: TitanDatabase? = null

        fun getInstance(context: Context): TitanDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TitanDatabase::class.java,
                    "titan_mdm_local.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = false)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
