package com.example.worker

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.LocalCacheRepository
import com.example.data.local.PreferencesStore
import com.example.data.repository.TitanMdmRepository
import com.example.enterprise.EnterpriseDpmController
import com.example.platform.NativeDeviceIntelligence
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

class TelemetrySyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val deviceIntel = NativeDeviceIntelligence(applicationContext)
            val dpm = EnterpriseDpmController(applicationContext)
            val localCache = LocalCacheRepository(applicationContext)
            val prefs = PreferencesStore(applicationContext)

            val snapshot = deviceIntel.captureSnapshot()
            localCache.recordTelemetry(snapshot)

            val settings = prefs.settingsFlow.first()
            val currentUser = Firebase.auth.currentUser
            if (currentUser != null && settings.enrolledDeviceId.isNotBlank()) {
                val repo = TitanMdmRepository(applicationContext)
                repo.pushDeviceTelemetryHeartbeat(
                    deviceId = settings.enrolledDeviceId,
                    snapshot = snapshot,
                    enterprise = dpm.inspectCapabilities()
                )
            }
            Log.i(TAG, "Background telemetry & heartbeat sync succeeded")
            Result.success()
        } catch (e: Exception) {
            Log.w(TAG, "Telemetry sync encountered error: ${e.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "TitanTelemetryWorker"
        private const val WORK_NAME = "titan_periodic_telemetry_sync"

        fun schedule(context: Context, intervalMinutes: Int) {
            val safeMinutes = intervalMinutes.coerceIn(15, 360).toLong()
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()

            val request = PeriodicWorkRequestBuilder<TelemetrySyncWorker>(
                safeMinutes,
                TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(WORK_NAME)
        }
    }
}
