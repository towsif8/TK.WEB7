package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AdminSession
import com.example.model.ComplianceState
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.LocalSecurityAuditResult
import com.example.model.ManagedDevice
import com.example.model.MdmRole
import com.example.model.RemoteCommand
import com.example.ui.components.BadgeTone
import com.example.ui.components.ComplianceRingGauge
import com.example.ui.components.MetricTile
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldOk
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState

@Composable
fun CommandDashboardScreen(
    operatorEmail: String,
    role: MdmRole,
    hardware: DeviceHardwareSnapshot?,
    enterprise: EnterpriseCapabilitiesStatus,
    auditResult: LocalSecurityAuditResult?,
    devicesState: CloudUiState<List<ManagedDevice>>,
    policiesState: CloudUiState<List<DevicePolicyRecord>>,
    commandsState: CloudUiState<List<RemoteCommand>>,
    sessionsState: CloudUiState<List<AdminSession>>,
    installedAppsCount: Int,
    onRefreshTelemetry: () -> Unit,
    onEnrollDevice: () -> Unit,
    onRunAudit: () -> Unit,
    onExecuteCommand: (RemoteCommand) -> Unit,
    onNavigateRoute: (String) -> Unit,
) {
    val devices = (devicesState as? CloudUiState.Success)?.data.orEmpty()
    val policies = (policiesState as? CloudUiState.Success)?.data.orEmpty()
    val commands = (commandsState as? CloudUiState.Success)?.data.orEmpty()
    val sessions = (sessionsState as? CloudUiState.Success)?.data.orEmpty()

    val pendingCommands = commands.filter { it.status == "QUEUED" || it.status == "DELIVERED" }
    val activeSessionsCount = sessions.count { it.status == "ACTIVE" }
    val compliantDevices = devices.count { it.complianceState == ComplianceState.COMPLIANT.name }
    val complianceScore = when {
        devices.isNotEmpty() -> (compliantDevices * 100) / devices.size
        auditResult != null -> (100 - auditResult.riskScore).coerceIn(0, 100)
        else -> 85
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("dashboard_lazy_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Hero Command Banner
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = DarkNavySurface,
                border = BorderStroke(1.dp, CrimsonPrimary.copy(alpha = 0.5f))
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_command_hero_1794758817688),
                        contentDescription = "Titan MDM Command Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .matchParentSize()
                            .alpha(0.32f)
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        ObsidianBlack.copy(alpha = 0.85f),
                                        DarkNavySurface.copy(alpha = 0.65f)
                                    )
                                )
                            )
                    )

                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                StatusBadge(
                                    text = role.label,
                                    tone = if (role == MdmRole.SUPER_ADMIN || role == MdmRole.ADMIN) {
                                        BadgeTone.CRIMSON
                                    } else {
                                        BadgeTone.COBALT
                                    }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "COMMAND CENTER",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = operatorEmail,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            ComplianceRingGauge(
                                scorePercent = complianceScore,
                                label = "COMPLY"
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onEnrollDevice,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("enroll_this_device_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CrimsonPrimary,
                                    contentColor = TextPrimary
                                )
                            ) {
                                Text("Enroll Device", maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            OutlinedButton(
                                onClick = onRunAudit,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("dashboard_audit_button"),
                                border = BorderStroke(1.dp, CobaltSecondary)
                            ) {
                                Text("Security Audit", color = TextPrimary, maxLines = 1)
                            }
                            IconButton(
                                onClick = onRefreshTelemetry,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(MaterialTheme.shapes.small)
                                    .background(ElevatedNavy)
                                    .testTag("refresh_telemetry_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Refresh Native Telemetry",
                                    tint = CyberCyan
                                )
                            }
                        }
                    }
                }
            }
        }

        // KPI Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Enrolled Fleet",
                        value = "${devices.size}",
                        icon = Icons.Filled.Devices,
                        accentColor = CobaltSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Queued Commands",
                        value = "${pendingCommands.size}",
                        icon = Icons.Filled.Terminal,
                        accentColor = if (pendingCommands.isNotEmpty()) AmberWarn else EmeraldOk,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Risk Score",
                        value = "${auditResult?.riskScore ?: 0}/100",
                        icon = Icons.Filled.Security,
                        accentColor = if ((auditResult?.confirmedFindingsCount ?: 0) > 0) CrimsonAlert else EmeraldOk,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Active Policies",
                        value = "${policies.size}",
                        icon = Icons.Filled.Policy,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Audited Apps",
                        value = "$installedAppsCount",
                        icon = Icons.Filled.Apps,
                        accentColor = CobaltSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Live Sessions",
                        value = "$activeSessionsCount",
                        icon = Icons.Filled.AdminPanelSettings,
                        accentColor = CrimsonPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Current Controller Hardware Snapshot Strip
        item {
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = hardware?.deviceName ?: "Inspecting Controller Hardware...",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Android ${hardware?.androidVersion ?: "-"} (SDK ${hardware?.sdkInt ?: "-"}) • ${hardware?.networkType ?: "-"} • ${hardware?.batteryPercent ?: 0}% Bat",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    StatusBadge(
                        text = enterprise.enrollmentMode.label.substringBefore(" "),
                        tone = if (enterprise.isDeviceOwner) BadgeTone.EMERALD
                        else if (enterprise.isDeviceAdminActive) BadgeTone.COBALT
                        else BadgeTone.AMBER
                    )
                }
            }
        }

        // Pending Remote Command Queue
        if (pendingCommands.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Incoming Remote Commands",
                    subtitle = "Replay-protected queue awaiting device execution"
                )
            }
            items(pendingCommands.take(4), key = { it.id }) { cmd ->
                TitanCard(accentBorder = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = cmd.commandType,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = cmd.payloadSummary.ifBlank { "Target: ${cmd.targetDeviceId}" },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "Nonce: ${cmd.nonce.take(12)}... • Sig: ${cmd.signatureDigest.take(12)}...",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onExecuteCommand(cmd) },
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Execute Command")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Execute")
                        }
                    }
                }
            }
        }

        // Full-Screen Module Directory (All 11 requested modules)
        item {
            SectionHeader(
                title = "Enterprise Management Modules",
                subtitle = "Direct access to all native & cloud administration suites"
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleQuickRow(
                    icon = Icons.Filled.Devices,
                    title = "Device Fleet & Enrollment",
                    subtitle = "Enroll devices, inspect compliance, queue signed remote commands",
                    badge = "${devices.size} Devices",
                    onClick = { onNavigateRoute("fleet") },
                    testTag = "module_fleet"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.Memory,
                    title = "Device Intelligence & Health",
                    subtitle = "CPU, RAM, Storage, Battery diagnostics, Network & Room snapshots",
                    badge = "${hardware?.ramUsedMb ?: 0}/${hardware?.ramTotalMb ?: 0} MB",
                    onClick = { onNavigateRoute("device_intel") },
                    testTag = "module_device_intel"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.AdminPanelSettings,
                    title = "Super Admin RBAC & User Inventory",
                    subtitle = "Roles (Super Admin/Admin/Moderator/Member), suspension, sessions",
                    badge = role.label,
                    onClick = { onNavigateRoute("users_admin") },
                    testTag = "module_users_admin"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.Apps,
                    title = "Application Management Engine",
                    subtitle = "Installed apps, permission audit, signing cert SHA-256, allowlists",
                    badge = "$installedAppsCount Apps",
                    onClick = { onNavigateRoute("apps") },
                    testTag = "module_apps"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.GppGood,
                    title = "Security Center & Quarantine Vault",
                    subtitle = "APK metadata scan, integrity checks, SAF file SHA-256 quarantine",
                    badge = "Grade ${auditResult?.networkSecurityGrade ?: "A"}",
                    onClick = { onNavigateRoute("security") },
                    testTag = "module_security"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.Policy,
                    title = "Enterprise Policies & Device Admin DPC",
                    subtitle = "DevicePolicyManager enforcement, lock now, Owner capabilities",
                    badge = if (enterprise.isDeviceAdminActive) "DPM Active" else "Standard",
                    onClick = { onNavigateRoute("policies") },
                    testTag = "module_policies"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.History,
                    title = "Immutable Activity & Audit Logs",
                    subtitle = "Cryptographically attributed append-only enterprise audit trail",
                    badge = "Audit Trail",
                    onClick = { onNavigateRoute("logs") },
                    testTag = "module_logs"
                )
                ModuleQuickRow(
                    icon = Icons.Filled.Settings,
                    title = "Native Settings, Permissions & Sync",
                    subtitle = "Android Settings bridge, runtime permission engine, WorkManager",
                    badge = "Settings",
                    onClick = { onNavigateRoute("settings") },
                    testTag = "module_settings"
                )
            }
        }
    }
}

@Composable
private fun ModuleQuickRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    onClick: () -> Unit,
    testTag: String,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.medium,
        color = DarkNavySurface,
        border = BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = ElevatedNavy,
                border = BorderStroke(1.dp, CobaltSecondary.copy(alpha = 0.35f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = CobaltSecondary,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            StatusBadge(text = badge, tone = BadgeTone.NEUTRAL)
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}
