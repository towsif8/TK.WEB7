package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Black & Dark Blue Command Surfaces
val ObsidianBlack = Color(0xFF05070B)
val MidnightVoid = Color(0xFF0A0F1A)
val DarkNavySurface = Color(0xFF0F172A)
val ElevatedNavy = Color(0xFF16223B)
val SlateBorder = Color(0xFF233252)

// Crimson Accents (Primary Command & Alert)
val CrimsonPrimary = Color(0xFFE11D48)
val CrimsonBright = Color(0xFFFB7185)
val CrimsonDeepContainer = Color(0xFF4C0519)
val CrimsonOnContainer = Color(0xFFFFD9E0)

// Electric Cobalt & Cyber Cyan (Secondary Telemetry)
val CobaltSecondary = Color(0xFF3B82F6)
val CobaltContainer = Color(0xFF172554)
val CobaltOnContainer = Color(0xFFDBEAFE)
val CyberCyan = Color(0xFF06B6D4)

// Semantic Status Colors
val EmeraldOk = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF064E3B)
val AmberWarn = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF451A03)
val CrimsonAlert = Color(0xFFEF4444)

// Typography Neutrals
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
