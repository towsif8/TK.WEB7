package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TitanDarkColorScheme = darkColorScheme(
    primary = CrimsonPrimary,
    onPrimary = TextPrimary,
    primaryContainer = CrimsonDeepContainer,
    onPrimaryContainer = CrimsonOnContainer,
    secondary = CobaltSecondary,
    onSecondary = TextPrimary,
    secondaryContainer = CobaltContainer,
    onSecondaryContainer = CobaltOnContainer,
    tertiary = CyberCyan,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TextPrimary,
    surface = MidnightVoid,
    onSurface = TextPrimary,
    surfaceVariant = DarkNavySurface,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = MidnightVoid,
    surfaceContainer = DarkNavySurface,
    surfaceContainerHigh = ElevatedNavy,
    outline = SlateBorder,
    outlineVariant = SlateBorder,
    error = CrimsonAlert,
    onError = TextPrimary,
    errorContainer = CrimsonDeepContainer,
    onErrorContainer = CrimsonOnContainer
)

private val TitanShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = TitanDarkColorScheme,
        typography = Typography,
        shapes = TitanShapes,
        content = content
    )
}
