package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.FileIntegrityCheckResult
import com.example.data.local.LocalScanHistoryEntity
import com.example.data.local.QuarantinedFileEntity
import com.example.model.FindingCertainty
import com.example.model.FindingSeverity
import com.example.model.LocalSecurityAuditResult
import com.example.model.SecurityReport
import com.example.ui.components.BadgeTone
import com.example.ui.components.ComplianceRingGauge
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldOk
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState

@Composable
fun SecurityCenterScreen(
    auditResult: LocalSecurityAuditResult?,
    fileIntegrityResult: FileIntegrityCheckResult?,
    quarantinedFiles: List<QuarantinedFileEntity>,
    localScanHistory: List<LocalScanHistoryEntity>,
    cloudReportsState: CloudUiState<List<SecurityReport>>,
    onRunSecurityAudit: () -> Unit,
    onInspectSelectedFile: (Uri) -> Unit,
    onQuarantineSelectedFile: (Uri, String) -> Unit,
    onPurgeQuarantinedFile: (QuarantinedFileEntity) -> Unit,
) {
    val context = LocalContext.current

    val inspectPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onInspectSelectedFile(uri)
    }

    val quarantinePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onQuarantineSelectedFile(uri, "User-initiated safe vault isolation")
    }

    val cloudReports = (cloudReportsState as? CloudUiState.Success)?.data.orEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TitanCard(accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        StatusBadge(
                            text = if (auditResult?.deviceIntegrityPassed == true) "INTEGRITY VERIFIED" else "ATTENTION REQUIRED",
                            tone = if (auditResult?.deviceIntegrityPassed == true) BadgeTone.EMERALD else BadgeTone.CRIMSON
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Security Posture Engine", style = MaterialTheme.typography.headlineSmall, color = TextPrimary)
                        Text(
                            text = auditResult?.summary ?: "Tap Run Audit to inspect APKs, permissions, integrity & network security.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    ComplianceRingGauge(
                        scorePercent = (100 - (auditResult?.riskScore ?: 0)).coerceIn(0, 100),
                        label = "TRUST"
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onRunSecurityAudit,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("run_security_audit_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.GppGood, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run Full Audit")
                    }
                    OutlinedButton(
                        onClick = {
                            val reportText = buildString {
                                appendLine("TITAN MDM SECURITY REPORT")
                                appendLine("Risk Score: ${auditResult?.riskScore ?: 0}/100")
                                appendLine("Network Grade: ${auditResult?.networkSecurityGrade ?: "N/A"}")
                                appendLine("Confirmed Findings: ${auditResult?.confirmedFindingsCount ?: 0}")
                                appendLine("Potential Risks: ${auditResult?.potentialRisksCount ?: 0}")
                                appendLine("Summary: ${auditResult?.summary ?: "Pending"}")
                                auditResult?.findings?.forEach {
                                    appendLine("- [${it.certainty.name}/${it.severity.name}] ${it.title}: ${it.description}")
                                }
                            }
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Titan MDM Security Audit Report")
                                putExtra(Intent.EXTRA_TEXT, reportText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Export Security Report"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        border = BorderStroke(1.dp, CobaltSecondary)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, tint = CobaltSecondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export Report", color = TextPrimary)
                    }
                }
            }
        }

        // Findings Breakdown: Confirmed vs Potential
        if (auditResult != null) {
            item {
                SectionHeader(
                    title = "Audit Findings (${auditResult.findings.size})",
                    subtitle = "${auditResult.confirmedFindingsCount} Confirmed • ${auditResult.potentialRisksCount} Potential Risks • Network Grade ${auditResult.networkSecurityGrade}"
                )
            }
            if (auditResult.findings.isEmpty()) {
                item {
                    TitanCard {
                        Text(
                            "Zero confirmed vulnerabilities or policy violations detected across ${auditResult.installedAppsScanned} scanned apps.",
                            color = EmeraldOk,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                items(auditResult.findings, key = { it.id }) { finding ->
                    val tone = when {
                        finding.certainty == FindingCertainty.CONFIRMED_FINDING && finding.severity == FindingSeverity.CRITICAL -> BadgeTone.CRIMSON
                        finding.certainty == FindingCertainty.CONFIRMED_FINDING -> BadgeTone.CRIMSON
                        else -> BadgeTone.AMBER
                    }
                    TitanCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(finding.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary, modifier = Modifier.weight(1f))
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(
                                text = if (finding.certainty == FindingCertainty.CONFIRMED_FINDING) "CONFIRMED" else "POTENTIAL",
                                tone = tone
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(finding.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Remediation: ${finding.remediation}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CobaltSecondary
                        )
                    }
                }
            }
        }

        // Safe File Integrity & Quarantine Vault (SAF zero-permission)
        item {
            SectionHeader(
                title = "File Integrity & Safe Quarantine",
                subtitle = "Zero-permission Storage Access Framework (SAF) SHA-256 verification"
            )
        }
        item {
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { inspectPicker.launch(arrayOf("*/*")) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("verify_file_sha_button")
                    ) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Check SHA-256")
                    }
                    Button(
                        onClick = { quarantinePicker.launch(arrayOf("*/*")) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("quarantine_file_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Quarantine File")
                    }
                }
                if (fileIntegrityResult != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "${fileIntegrityResult.displayName} (${fileIntegrityResult.sizeBytes} bytes)",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "SHA-256: ${fileIntegrityResult.sha256Hash}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CobaltSecondary
                    )
                    Text(
                        text = fileIntegrityResult.riskAssessment,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (fileIntegrityResult.isSuspiciousExtension) AmberWarn else EmeraldOk
                    )
                }
            }
        }

        if (quarantinedFiles.isNotEmpty()) {
            items(quarantinedFiles, key = { it.quarantineId }) { qFile ->
                TitanCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(qFile.originalDisplayName, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text("SHA-256: ${qFile.sha256Hash.take(24)}...", style = MaterialTheme.typography.labelSmall, color = CobaltSecondary)
                            Text(qFile.riskReason, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        IconButton(onClick = { onPurgeQuarantinedFile(qFile) }) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = "Purge Quarantined File", tint = CrimsonAlert)
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Scan History (Cloud ${cloudReports.size} / Local ${localScanHistory.size})",
                subtitle = "Audited security posture snapshots"
            )
        }

        items(cloudReports.take(5), key = { it.id }) { rep ->
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Cloud Report • Risk ${rep.overallRiskScore}/100", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        Text(rep.summary, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    StatusBadge(
                        text = "Grade ${rep.networkSecurityGrade}",
                        tone = if (rep.deviceIntegrityPassed) BadgeTone.EMERALD else BadgeTone.CRIMSON
                    )
                }
            }
        }
    }
}
