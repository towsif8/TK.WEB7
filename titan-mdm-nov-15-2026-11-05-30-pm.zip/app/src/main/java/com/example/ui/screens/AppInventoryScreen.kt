package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Launch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DevicePolicyRecord
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.InstalledAppInfo
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppFilterMode

@Composable
fun AppInventoryScreen(
    apps: List<InstalledAppInfo>,
    isScanning: Boolean,
    searchQuery: String,
    filterMode: AppFilterMode,
    activePolicy: DevicePolicyRecord?,
    enterprise: EnterpriseCapabilitiesStatus,
    onSearchChange: (String) -> Unit,
    onFilterChange: (AppFilterMode) -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenAppDetails: (String) -> Unit,
    onToggleAllowlist: (String, Boolean) -> Unit,
    onToggleSuspendByOwner: (String, Boolean) -> Unit,
) {
    var inspectedApp by remember { mutableStateOf<InstalledAppInfo?>(null) }

    val allowSet = activePolicy?.appAllowlist?.toSet().orEmpty()
    val blockSet = activePolicy?.appBlocklist?.toSet().orEmpty()

    val filtered = remember(apps, searchQuery, filterMode, allowSet, blockSet) {
        apps.filter { app ->
            val matchesQuery = searchQuery.isBlank() ||
                app.appName.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesMode = when (filterMode) {
                AppFilterMode.ALL -> true
                AppFilterMode.USER -> !app.isSystemApp
                AppFilterMode.SYSTEM -> app.isSystemApp
                AppFilterMode.HIGH_RISK -> app.riskScore >= 30
                AppFilterMode.ALLOWLISTED -> app.packageName in allowSet
                AppFilterMode.RESTRICTED -> app.packageName in blockSet
            }
            matchesQuery && matchesMode
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        if (isScanning) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = CrimsonPrimary
            )
        }

        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            SectionHeader(
                title = "Application Management (${filtered.size})",
                subtitle = "APK metadata, permission audits, allowlists & DPM control"
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search app name or package ID...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_search_input")
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppFilterMode.entries.forEach { mode ->
                    FilterChip(
                        selected = filterMode == mode,
                        onClick = { onFilterChange(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                val isAllowlisted = app.packageName in allowSet
                val isBlocked = app.packageName in blockSet
                val riskTone = when {
                    app.riskScore >= 60 -> BadgeTone.CRIMSON
                    app.riskScore >= 30 -> BadgeTone.AMBER
                    else -> BadgeTone.EMERALD
                }
                TitanCard(onClick = { inspectedApp = app }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.appName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = CobaltSecondary)
                            Text(
                                text = "v${app.versionName} • SDK ${app.targetSdkVersion} • ${app.installerPackage}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            StatusBadge(text = "${app.riskLabel} (${app.riskScore})", tone = riskTone)
                            if (isAllowlisted) StatusBadge(text = "ALLOWLIST", tone = BadgeTone.EMERALD)
                            if (isBlocked) StatusBadge(text = "RESTRICTED", tone = BadgeTone.CRIMSON)
                        }
                    }
                    if (app.grantedDangerousPermissions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Granted Sensitive: ${app.grantedDangerousPermissions.joinToString(", ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }

    inspectedApp?.let { app ->
        AppInspectionDialog(
            app = app,
            isAllowlisted = app.packageName in allowSet,
            isRestricted = app.packageName in blockSet,
            supportsDpmSuspend = enterprise.supportsAppSuspension,
            onDismiss = { inspectedApp = null },
            onLaunch = { onLaunchApp(app.packageName) },
            onOpenDetails = { onOpenAppDetails(app.packageName) },
            onToggleAllowlist = { onToggleAllowlist(app.packageName, true) },
            onToggleRestrict = { onToggleAllowlist(app.packageName, false) },
            onSuspendByOwner = { suspend -> onToggleSuspendByOwner(app.packageName, suspend) }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppInspectionDialog(
    app: InstalledAppInfo,
    isAllowlisted: Boolean,
    isRestricted: Boolean,
    supportsDpmSuspend: Boolean,
    onDismiss: () -> Unit,
    onLaunch: () -> Unit,
    onOpenDetails: () -> Unit,
    onToggleAllowlist: () -> Unit,
    onToggleRestrict: () -> Unit,
    onSuspendByOwner: (Boolean) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.appName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = CobaltSecondary)
                Text("Version: ${app.versionName} (${app.versionCode})", style = MaterialTheme.typography.bodySmall)
                Text("Installer: ${app.installerPackage}", style = MaterialTheme.typography.bodySmall)
                Text("Target/Min SDK: ${app.targetSdkVersion} / ${app.minSdkVersion}", style = MaterialTheme.typography.bodySmall)
                Text("Debuggable: ${app.isDebuggable} • Cleartext: ${app.usesCleartextTraffic}", style = MaterialTheme.typography.bodySmall)
                Text("Signer SHA-256: ${app.signingCertSha256}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(
                    "Permissions (${app.requestedPermissions.size} declared, ${app.grantedDangerousPermissions.size} sensitive granted):",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = app.grantedDangerousPermissions.ifEmpty { listOf("None granted") }.joinToString(", "),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onLaunch,
                        colors = ButtonDefaults.buttonColors(containerColor = CobaltSecondary)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Launch, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Launch")
                    }
                    OutlinedButton(onClick = onOpenDetails) {
                        Icon(Icons.Filled.Info, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("OS Info")
                    }
                    OutlinedButton(onClick = onToggleAllowlist) {
                        Text(if (isAllowlisted) "Un-Allowlist" else "Allowlist")
                    }
                    OutlinedButton(onClick = onToggleRestrict) {
                        Text(if (isRestricted) "Unrestrict" else "Restrict")
                    }
                    if (supportsDpmSuspend) {
                        Button(
                            onClick = { onSuspendByOwner(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                        ) {
                            Text("DPM Suspend")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
