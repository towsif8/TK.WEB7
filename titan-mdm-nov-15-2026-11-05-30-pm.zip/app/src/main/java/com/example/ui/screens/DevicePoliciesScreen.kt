package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.DevicePolicyRecord
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldOk
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState

@Composable
fun DevicePoliciesScreen(
    enterprise: EnterpriseCapabilitiesStatus,
    policiesState: CloudUiState<List<DevicePolicyRecord>>,
    buildDeviceAdminIntent: () -> android.content.Intent,
    onRefreshEnterpriseStatus: () -> Unit,
    onLockScreenNow: () -> Unit,
    onApplyPolicyLocally: (DevicePolicyRecord) -> Unit,
    onSavePolicy: (DevicePolicyRecord) -> Unit,
) {
    var showCreatePolicyDialog by remember { mutableStateOf(false) }

    val deviceAdminLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        onRefreshEnterpriseStatus()
    }

    val policies = (policiesState as? CloudUiState.Success)?.data.orEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("policies_lazy_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Tier Separation Card: Standard vs Device Admin vs Device Owner
        item {
            TitanCard(accentBorder = true) {
                SectionHeader(
                    title = "Android Enterprise Controller",
                    subtitle = "DevicePolicyManager provisioning & capability tiers"
                )
                Spacer(modifier = Modifier.height(10.dp))
                CapabilityTierRow("Standard App APIs", "Active", BadgeTone.EMERALD)
                CapabilityTierRow(
                    "Device Admin (DPM)",
                    if (enterprise.isDeviceAdminActive) "ACTIVE" else "NOT ACTIVATED",
                    if (enterprise.isDeviceAdminActive) BadgeTone.EMERALD else BadgeTone.AMBER
                )
                CapabilityTierRow(
                    "Device Owner / Work Profile",
                    if (enterprise.isDeviceOwner) "DEVICE OWNER" else if (enterprise.isProfileOwner) "WORK PROFILE" else "PROVISIONING REQUIRED",
                    if (enterprise.isDeviceOwner || enterprise.isProfileOwner) BadgeTone.EMERALD else BadgeTone.NEUTRAL
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Encryption: ${enterprise.storageEncryptionStatus} • Camera Disabled: ${enterprise.isCameraDisabledByPolicy} • Lock Timeout: ${enterprise.maxTimeToLockSeconds}s",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { deviceAdminLauncher.launch(buildDeviceAdminIntent()) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("activate_device_admin_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CobaltSecondary)
                    ) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (enterprise.isDeviceAdminActive) "DPM Active" else "Enable Admin")
                    }
                    Button(
                        onClick = onLockScreenNow,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("dpm_lock_now_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.Lock, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lock Screen")
                    }
                }
                if (!enterprise.isDeviceOwner) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Fully Managed Provisioning: USB/Unknown-Sources restrictions and app suspension require Device Owner provisioning via QR/Zero-Touch or ADB: dpm set-device-owner com.aistudio.titanmdm.xkqvmz/com.example.enterprise.TitanDeviceAdminReceiver",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "Enterprise Policy Records (${policies.size})",
                subtitle = "Cloud-synchronized security & restriction blueprints",
                trailing = {
                    Button(
                        onClick = { showCreatePolicyDialog = true },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("create_policy_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.Policy, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New Policy")
                    }
                }
            )
        }

        items(policies, key = { it.id }) { policy ->
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(policy.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text(policy.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    StatusBadge(text = "v${policy.version}", tone = BadgeTone.COBALT)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "MinPwd: ${policy.minPasswordLength} • Timeout: ${policy.screenTimeoutSeconds}s • CamOff: ${policy.disableCamera} • USBBlock: ${policy.disableUsbFileTransfer} • Allowlist: ${policy.appAllowlist.size} • Blocklist: ${policy.appBlocklist.size}",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldOk
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onApplyPolicyLocally(policy) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    border = BorderStroke(1.dp, CobaltSecondary)
                ) {
                    Text("Enforce Policy Locally via DPM", color = TextPrimary)
                }
            }
        }
    }

    if (showCreatePolicyDialog) {
        CreatePolicyDialog(
            onDismiss = { showCreatePolicyDialog = false },
            onSave = { policy ->
                onSavePolicy(policy)
                showCreatePolicyDialog = false
            }
        )
    }
}

@Composable
private fun CapabilityTierRow(label: String, status: String, tone: BadgeTone) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        StatusBadge(text = status, tone = tone)
    }
}

@Composable
private fun CreatePolicyDialog(
    onDismiss: () -> Unit,
    onSave: (DevicePolicyRecord) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("Hardened corporate device security profile") }
    var disableCamera by remember { mutableStateOf(false) }
    var disableUsb by remember { mutableStateOf(true) }
    var blockUnknown by remember { mutableStateOf(true) }
    var timeoutSec by remember { mutableStateOf("60") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Enterprise Policy") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Policy Name") })
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
                OutlinedTextField(value = timeoutSec, onValueChange = { timeoutSec = it.filter { ch -> ch.isDigit() } }, label = { Text("Screen Timeout (sec)") })
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Disable Camera (DPM)", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = disableCamera, onCheckedChange = { disableCamera = it })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Disable USB Transfer (Owner)", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = disableUsb, onCheckedChange = { disableUsb = it })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Block Unknown Sources (Owner)", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = blockUnknown, onCheckedChange = { blockUnknown = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val timeout = (timeoutSec.toLongOrNull() ?: 60L).coerceIn(15L, 3600L)
                    onSave(
                        DevicePolicyRecord(
                            name = name.ifBlank { "Titan Strict Policy" },
                            description = desc,
                            requireScreenLock = true,
                            minPasswordLength = 8L,
                            requireEncryption = true,
                            disableCamera = disableCamera,
                            disableUsbFileTransfer = disableUsb,
                            blockUnknownSources = blockUnknown,
                            maxFailedPasswordsForWipe = 0L,
                            screenTimeoutSeconds = timeout
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
            ) {
                Text("Save Policy")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
