package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.TitanLocalSettings
import com.example.data.local.WorkspaceMode
import com.example.model.MdmRole
import com.example.model.PermissionAuditItem
import com.example.platform.NativeSettingItem
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AdminSettingsScreen(
    operatorEmail: String,
    role: MdmRole,
    activeWorkspaceMode: WorkspaceMode = WorkspaceMode.ADMIN_CONSOLE,
    settings: TitanLocalSettings,
    permissions: List<PermissionAuditItem>,
    nativeSettings: List<NativeSettingItem>,
    onSwitchWorkspaceMode: (WorkspaceMode) -> Unit = {},
    onOpenNativeSetting: (NativeSettingItem) -> Unit,
    onPermissionResult: () -> Unit,
    onToggleAutoSync: (Boolean, Int) -> Unit,
    onToggleThreatAlerts: (Boolean) -> Unit,
    onToggleStrictAudit: (Boolean) -> Unit,
    onSignOut: () -> Unit,
) {
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onPermissionResult()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TitanCard(accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Operator Profile", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text(operatorEmail, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    StatusBadge(text = role.label, tone = BadgeTone.CRIMSON)
                }
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onSignOut,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("sign_out_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign Out & Clear Credentials")
                }
            }
        }

        // Workspace Role Mode (Admin Console vs Member Agent)
        item {
            TitanCard {
                Text("Workspace Mode", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                if (role == MdmRole.MEMBER) {
                    Text(
                        text = "This account is provisioned with the Member role and is locked to Member Device Agent mode.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    StatusBadge(text = "MEMBER AGENT ACTIVE", tone = BadgeTone.COBALT)
                } else {
                    Text(
                        text = "Switch between full Admin Command Console and managed Member Device Agent views.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        WorkspaceMode.entries.forEach { mode ->
                            FilterChip(
                                selected = activeWorkspaceMode == mode,
                                onClick = { onSwitchWorkspaceMode(mode) },
                                label = { Text(mode.label) },
                                modifier = Modifier.testTag("settings_mode_${mode.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // WorkManager & Local Preferences
        item {
            SectionHeader(
                title = "Background Engine & Preferences",
                subtitle = "WorkManager telemetry schedule & DataStore configuration"
            )
        }
        item {
            TitanCard {
                SettingSwitchRow(
                    title = "Periodic Background Telemetry (WorkManager)",
                    subtitle = "Sync hardware health every ${settings.syncIntervalMinutes} min when connected",
                    checked = settings.autoTelemetrySyncEnabled,
                    onCheckedChange = { onToggleAutoSync(it, settings.syncIntervalMinutes) }
                )
                SettingSwitchRow(
                    title = "Critical Threat Alerting",
                    subtitle = "Highlight confirmed APK and root integrity alerts",
                    checked = settings.threatAlertsEnabled,
                    onCheckedChange = onToggleThreatAlerts
                )
                SettingSwitchRow(
                    title = "Strict Enterprise Audit Mode",
                    subtitle = "Flag ADB debugging and non-VPN Wi-Fi sessions",
                    checked = settings.strictAuditMode,
                    onCheckedChange = onToggleStrictAudit
                )
            }
        }

        // Native Permission Engine
        item {
            SectionHeader(
                title = "Native Permission Engine",
                subtitle = "Least-privilege runtime status, rationale & user-consented requests"
            )
        }
        items(permissions, key = { it.permission }) { perm ->
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(perm.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        Text(perm.permission, style = MaterialTheme.typography.labelSmall, color = CobaltSecondary)
                        Text(perm.rationale, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(
                        text = if (perm.isGranted) "GRANTED" else "NOT GRANTED",
                        tone = if (perm.isGranted) BadgeTone.EMERALD else BadgeTone.AMBER
                    )
                }
                if (!perm.isGranted && perm.isRuntimePermission) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { permissionLauncher.launch(perm.permission) },
                        modifier = Modifier.height(48.dp),
                        border = BorderStroke(1.dp, CrimsonPrimary)
                    ) {
                        Text("Request Permission", color = TextPrimary)
                    }
                }
            }
        }

        // Native Android Settings Integration
        item {
            SectionHeader(
                title = "Native Android Settings Integration",
                subtitle = "Direct platform controls for Display, Sound, Network, Battery & Security"
            )
        }
        items(nativeSettings, key = { it.id }) { item ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .clickable { onOpenNativeSetting(item) }
                    .testTag("native_setting_${item.id}"),
                shape = MaterialTheme.shapes.medium,
                color = DarkNavySurface,
                border = BorderStroke(1.dp, SlateBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = item.title, tint = CobaltSecondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                        Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Open ${item.title}",
                        tint = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
