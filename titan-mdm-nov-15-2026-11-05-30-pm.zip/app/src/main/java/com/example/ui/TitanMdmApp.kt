package com.example.ui

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.local.LocalCacheRepository
import com.example.data.local.PreferencesStore
import com.example.data.local.TitanLocalSettings
import com.example.data.local.WorkspaceMode
import com.example.data.remote.attemptAutoSignIn
import com.example.data.remote.authStateFlow
import com.example.data.remote.signOutFromTitan
import com.example.data.repository.TitanMdmRepository
import com.example.enterprise.EnterpriseDpmController
import com.example.model.MdmRole
import com.example.platform.AppInventoryEngine
import com.example.platform.NativeDeviceIntelligence
import com.example.platform.NativeSettingsNavigator
import com.example.platform.PermissionAuditEngine
import com.example.platform.SecurityScannerEngine
import com.example.ui.screens.ActivityLogsScreen
import com.example.ui.screens.AdminSettingsScreen
import com.example.ui.screens.AppInventoryScreen
import com.example.ui.screens.AuthGateScreen
import com.example.ui.screens.CommandDashboardScreen
import com.example.ui.screens.DeviceIntelligenceScreen
import com.example.ui.screens.DevicePoliciesScreen
import com.example.ui.screens.FleetManagementScreen
import com.example.ui.screens.MemberAgentDashboardScreen
import com.example.ui.screens.SecurityCenterScreen
import com.example.ui.screens.UserAdminManagementScreen
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.MidnightVoid
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState
import com.example.ui.viewmodel.TitanViewModel
import com.example.worker.TelemetrySyncWorker
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

object TitanRoutes {
    const val COMMAND = "dashboard"
    const val MEMBER_HOME = "member_home"
    const val FLEET = "fleet"
    const val APPS = "apps"
    const val SECURITY = "security"
    const val POLICIES = "policies"
    const val DEVICE_INTEL = "device_intel"
    const val USERS_ADMIN = "users_admin"
    const val LOGS = "logs"
    const val SETTINGS = "settings"
}

private data class TopNavDestination(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val testTag: String,
)

private val adminPrimaryDestinations = listOf(
    TopNavDestination(TitanRoutes.COMMAND, "Command", Icons.Filled.Dashboard, "nav_command"),
    TopNavDestination(TitanRoutes.FLEET, "Fleet", Icons.Filled.Devices, "nav_fleet"),
    TopNavDestination(TitanRoutes.APPS, "Apps", Icons.Filled.Apps, "nav_apps"),
    TopNavDestination(TitanRoutes.SECURITY, "Security", Icons.Filled.Security, "nav_security"),
    TopNavDestination(TitanRoutes.POLICIES, "Policies", Icons.Filled.Policy, "nav_policies"),
)

private val memberPrimaryDestinations = listOf(
    TopNavDestination(TitanRoutes.MEMBER_HOME, "My Device", Icons.Filled.Devices, "nav_member_home"),
    TopNavDestination(TitanRoutes.DEVICE_INTEL, "Health", Icons.Filled.Memory, "nav_member_health"),
    TopNavDestination(TitanRoutes.APPS, "Apps", Icons.Filled.Apps, "nav_member_apps"),
    TopNavDestination(TitanRoutes.SECURITY, "Security", Icons.Filled.Security, "nav_member_security"),
    TopNavDestination(TitanRoutes.SETTINGS, "Settings", Icons.Filled.Settings, "nav_member_settings"),
)

@Composable
fun TitanMdmApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val prefsStore = remember(context) { PreferencesStore(context.applicationContext) }
    val localPrefs by prefsStore.settingsFlow.collectAsStateWithLifecycle(initialValue = TitanLocalSettings())
    val auth = remember { Firebase.auth }
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val user = currentUser
    if (user == null) {
        AuthGateScreen(
            selectedMode = localPrefs.preferredWorkspaceMode,
            onSelectMode = { mode ->
                scope.launch { prefsStore.setPreferredWorkspaceMode(mode) }
            },
            onAuthSuccess = {}
        )
    } else {
        key(user.uid) {
            AuthenticatedTitanWorkspace(
                uid = user.uid,
                email = user.email ?: "operator@titanmdm.local",
                displayName = user.displayName ?: "Enterprise Operator",
                onSignOut = {
                    signOutFromTitan(credentialManager = credentialManager, scope = scope)
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedTitanWorkspace(
    uid: String,
    email: String,
    displayName: String,
    onSignOut: () -> Unit,
) {
    val context = LocalContext.current
    val viewModel: TitanViewModel = viewModel(
        key = uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                TitanViewModel(
                    currentUserId = uid,
                    currentUserEmail = email,
                    currentUserName = displayName,
                    repository = TitanMdmRepository(db),
                    localCache = LocalCacheRepository(app),
                    preferencesStore = PreferencesStore(app),
                    deviceIntel = NativeDeviceIntelligence(app),
                    appInventory = AppInventoryEngine(app),
                    securityScanner = SecurityScannerEngine(app),
                    dpmController = EnterpriseDpmController(app),
                    settingsNavigator = NativeSettingsNavigator(app),
                    permissionAuditEngine = PermissionAuditEngine(app),
                    onScheduleWorker = { enabled, intervalMin ->
                        if (enabled) TelemetrySyncWorker.schedule(app, intervalMin)
                        else TelemetrySyncWorker.cancel(app)
                    }
                )
            }
        }
    )

    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val workspaceMode by viewModel.effectiveWorkspaceMode.collectAsStateWithLifecycle()
    val primaryDestinations = if (workspaceMode == WorkspaceMode.MEMBER_AGENT) {
        memberPrimaryDestinations
    } else {
        adminPrimaryDestinations
    }

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
        ?: if (workspaceMode == WorkspaceMode.MEMBER_AGENT) TitanRoutes.MEMBER_HOME else TitanRoutes.COMMAND
    val isPrimaryRoute = primaryDestinations.any { it.route == currentRoute }

    LaunchedEffect(workspaceMode) {
        val targetHome = if (workspaceMode == WorkspaceMode.MEMBER_AGENT) {
            TitanRoutes.MEMBER_HOME
        } else {
            TitanRoutes.COMMAND
        }
        val wrongHome = if (workspaceMode == WorkspaceMode.MEMBER_AGENT) {
            currentRoute == TitanRoutes.COMMAND ||
                currentRoute == TitanRoutes.FLEET ||
                currentRoute == TitanRoutes.USERS_ADMIN ||
                currentRoute == TitanRoutes.LOGS
        } else {
            currentRoute == TitanRoutes.MEMBER_HOME
        }
        if (wrongHome) {
            navController.navigate(targetHome) {
                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val banner by viewModel.statusBanner.collectAsStateWithLifecycle()

    LaunchedEffect(banner) {
        val msg = banner
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBanner()
        }
    }

    // Collect ViewModel state
    val hardware by viewModel.hardwareSnapshot.collectAsStateWithLifecycle()
    val enterprise by viewModel.enterpriseStatus.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val isScanningApps by viewModel.isScanningApps.collectAsStateWithLifecycle()
    val auditResult by viewModel.securityAuditResult.collectAsStateWithLifecycle()
    val fileIntegrity by viewModel.fileIntegrityResult.collectAsStateWithLifecycle()
    val permissionAudit by viewModel.permissionAudit.collectAsStateWithLifecycle()
    val appSearch by viewModel.appSearchQuery.collectAsStateWithLifecycle()
    val appFilter by viewModel.appFilterMode.collectAsStateWithLifecycle()

    val adminsState by viewModel.adminsState.collectAsStateWithLifecycle()
    val usersState by viewModel.usersState.collectAsStateWithLifecycle()
    val devicesState by viewModel.devicesState.collectAsStateWithLifecycle()
    val policiesState by viewModel.policiesState.collectAsStateWithLifecycle()
    val commandsState by viewModel.commandsState.collectAsStateWithLifecycle()
    val reportsState by viewModel.securityReportsState.collectAsStateWithLifecycle()
    val logsState by viewModel.activityLogsState.collectAsStateWithLifecycle()
    val sessionsState by viewModel.sessionsState.collectAsStateWithLifecycle()

    val localTelemetry by viewModel.localTelemetryHistory.collectAsStateWithLifecycle()
    val localScanHistory by viewModel.localScanHistory.collectAsStateWithLifecycle()
    val quarantinedFiles by viewModel.quarantinedFiles.collectAsStateWithLifecycle()
    val localSettings by viewModel.localSettings.collectAsStateWithLifecycle()

    LaunchedEffect(localSettings.autoTelemetrySyncEnabled, localSettings.syncIntervalMinutes) {
        if (localSettings.autoTelemetrySyncEnabled) {
            TelemetrySyncWorker.schedule(context, localSettings.syncIntervalMinutes)
        }
    }

    val navigateTo: (String) -> Unit = { route ->
        if (route in primaryDestinations.map { it.route }) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        } else {
            navController.navigate(route) {
                launchSingleTop = true
            }
        }
    }

    val screenTitle = when (currentRoute) {
        TitanRoutes.COMMAND -> "TITAN ADMIN"
        TitanRoutes.MEMBER_HOME -> "TITAN MEMBER"
        TitanRoutes.FLEET -> "Fleet & Enrollment"
        TitanRoutes.APPS -> "App Management"
        TitanRoutes.SECURITY -> "Security Center"
        TitanRoutes.POLICIES -> "Policies & DPC"
        TitanRoutes.DEVICE_INTEL -> "Device Health & Intel"
        TitanRoutes.USERS_ADMIN -> "RBAC & User Directory"
        TitanRoutes.LOGS -> "Enterprise Audit Logs"
        TitanRoutes.SETTINGS -> "Settings & Permissions"
        else -> "TITAN MDM"
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 700.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = { Text(screenTitle, style = MaterialTheme.typography.titleLarge) },
                    navigationIcon = {
                        if (!isPrimaryRoute) {
                            IconButton(
                                onClick = { navController.popBackStack() },
                                modifier = Modifier.testTag("top_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Navigate Back"
                                )
                            }
                        }
                    },
                    actions = {
                        if (activeRole != MdmRole.MEMBER) {
                            val nextMode = if (workspaceMode == WorkspaceMode.ADMIN_CONSOLE) {
                                WorkspaceMode.MEMBER_AGENT
                            } else {
                                WorkspaceMode.ADMIN_CONSOLE
                            }
                            FilterChip(
                                selected = workspaceMode == WorkspaceMode.ADMIN_CONSOLE,
                                onClick = { viewModel.setWorkspaceMode(nextMode) },
                                label = {
                                    Text(
                                        if (workspaceMode == WorkspaceMode.ADMIN_CONSOLE) "Admin Mode" else "Member Mode"
                                    )
                                },
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .testTag("topbar_workspace_switch")
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MidnightVoid,
                        titleContentColor = TextPrimary,
                        navigationIconContentColor = TextPrimary
                    )
                )
            },
            bottomBar = {
                if (!useRail && isPrimaryRoute) {
                    NavigationBar(
                        containerColor = DarkNavySurface,
                        contentColor = TextPrimary
                    ) {
                        primaryDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CrimsonPrimary,
                                    selectedTextColor = CrimsonPrimary,
                                    indicatorColor = CrimsonPrimary.copy(alpha = 0.16f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = DarkNavySurface) {
                        primaryDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CrimsonPrimary,
                                    selectedTextColor = CrimsonPrimary,
                                    indicatorColor = CobaltSecondary.copy(alpha = 0.2f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = if (workspaceMode == WorkspaceMode.MEMBER_AGENT) {
                            TitanRoutes.MEMBER_HOME
                        } else {
                            TitanRoutes.COMMAND
                        }
                    ) {
                        composable(TitanRoutes.MEMBER_HOME) {
                            val devices = (devicesState as? CloudUiState.Success)?.data.orEmpty()
                            val myDevice = devices.firstOrNull {
                                it.id == localSettings.enrolledDeviceId || it.ownerUid == uid
                            }
                            val policies = (policiesState as? CloudUiState.Success)?.data.orEmpty()
                            val assignedPolicy = policies.firstOrNull { it.id == myDevice?.assignedPolicyId }
                                ?: policies.firstOrNull()
                            val pendingCommands = (commandsState as? CloudUiState.Success)?.data.orEmpty()
                                .filter {
                                    (it.status == "QUEUED" || it.status == "DELIVERED") &&
                                        (myDevice == null || it.targetDeviceId == myDevice.id)
                                }
                            MemberAgentDashboardScreen(
                                memberEmail = email,
                                role = activeRole,
                                hardware = hardware,
                                enterprise = enterprise,
                                auditResult = auditResult,
                                myDevice = myDevice,
                                assignedPolicy = assignedPolicy,
                                pendingCommands = pendingCommands,
                                installedAppsCount = installedApps.size,
                                onEnrollOrSyncDevice = {
                                    if (myDevice == null) viewModel.enrollThisDevice()
                                    else viewModel.pushHeartbeatForDevice(myDevice)
                                },
                                onRunSecurityAudit = { viewModel.runAndPublishSecurityAudit() },
                                onApplyAssignedPolicy = { viewModel.applyPolicyLocally(it) },
                                onExecuteCommand = { viewModel.executeAndAcknowledgeCommand(it) },
                                onNavigateRoute = navigateTo
                            )
                        }
                        composable(TitanRoutes.COMMAND) {
                            CommandDashboardScreen(
                                operatorEmail = email,
                                role = activeRole,
                                hardware = hardware,
                                enterprise = enterprise,
                                auditResult = auditResult,
                                devicesState = devicesState,
                                policiesState = policiesState,
                                commandsState = commandsState,
                                sessionsState = sessionsState,
                                installedAppsCount = installedApps.size,
                                onRefreshTelemetry = { viewModel.refreshAllNativeTelemetry() },
                                onEnrollDevice = { viewModel.enrollThisDevice() },
                                onRunAudit = { viewModel.runAndPublishSecurityAudit() },
                                onExecuteCommand = { viewModel.executeAndAcknowledgeCommand(it) },
                                onNavigateRoute = navigateTo
                            )
                        }
                        composable(TitanRoutes.FLEET) {
                            FleetManagementScreen(
                                devicesState = devicesState,
                                policiesState = policiesState,
                                commandsState = commandsState,
                                enterprise = enterprise,
                                onEnrollCurrentDevice = { viewModel.enrollThisDevice() },
                                onPushHeartbeat = { viewModel.pushHeartbeatForDevice(it) },
                                onUpdateStatus = { dev, st -> viewModel.updateDeviceStatus(dev, st) },
                                onAssignPolicy = { dev, pol -> viewModel.assignPolicyToDevice(dev, pol) },
                                onQueueCommand = { dev, type, sum -> viewModel.queueRemoteCommand(dev, type, sum) },
                                onExecuteCommand = { viewModel.executeAndAcknowledgeCommand(it) },
                                onOpenDeviceIntel = { navigateTo(TitanRoutes.DEVICE_INTEL) }
                            )
                        }
                        composable(TitanRoutes.APPS) {
                            val activePolicy = (policiesState as? CloudUiState.Success)?.data?.firstOrNull()
                            AppInventoryScreen(
                                apps = installedApps,
                                isScanning = isScanningApps,
                                searchQuery = appSearch,
                                filterMode = appFilter,
                                activePolicy = activePolicy,
                                enterprise = enterprise,
                                onSearchChange = { viewModel.setAppSearchQuery(it) },
                                onFilterChange = { viewModel.setAppFilterMode(it) },
                                onLaunchApp = { viewModel.launchInstalledApp(it) },
                                onOpenAppDetails = { viewModel.openAppDetails(it) },
                                onToggleAllowlist = { pkg, allow -> viewModel.toggleAppAllowlistOrBlocklist(pkg, allow, activePolicy) },
                                onToggleSuspendByOwner = { pkg, suspend -> viewModel.togglePackageSuspension(pkg, suspend) }
                            )
                        }
                        composable(TitanRoutes.SECURITY) {
                            SecurityCenterScreen(
                                auditResult = auditResult,
                                fileIntegrityResult = fileIntegrity,
                                quarantinedFiles = quarantinedFiles,
                                localScanHistory = localScanHistory,
                                cloudReportsState = reportsState,
                                onRunSecurityAudit = { viewModel.runAndPublishSecurityAudit() },
                                onInspectSelectedFile = { viewModel.inspectFileIntegrity(it) },
                                onQuarantineSelectedFile = { uri, reason -> viewModel.quarantineSelectedFile(uri, reason) },
                                onPurgeQuarantinedFile = { viewModel.purgeQuarantinedFile(it) }
                            )
                        }
                        composable(TitanRoutes.POLICIES) {
                            DevicePoliciesScreen(
                                enterprise = enterprise,
                                policiesState = policiesState,
                                buildDeviceAdminIntent = { viewModel.buildDeviceAdminIntent() },
                                onRefreshEnterpriseStatus = { viewModel.refreshPermissionsAndEnterprise() },
                                onLockScreenNow = { viewModel.lockScreenLocally() },
                                onApplyPolicyLocally = { viewModel.applyPolicyLocally(it) },
                                onSavePolicy = { viewModel.savePolicy(it) }
                            )
                        }
                        composable(TitanRoutes.DEVICE_INTEL) {
                            BackHandler { navController.popBackStack() }
                            DeviceIntelligenceScreen(
                                hardware = hardware,
                                telemetryHistory = localTelemetry,
                                onRefresh = { viewModel.refreshAllNativeTelemetry() }
                            )
                        }
                        composable(TitanRoutes.USERS_ADMIN) {
                            BackHandler { navController.popBackStack() }
                            UserAdminManagementScreen(
                                activeRole = activeRole,
                                adminsState = adminsState,
                                usersState = usersState,
                                sessionsState = sessionsState,
                                onUpsertAdmin = { tUid, mail, name, r, st, dept ->
                                    viewModel.upsertAdminAccount(tUid, mail, name, r, st, dept)
                                },
                                onCreateManagedUser = { mail, name, dept, r ->
                                    viewModel.createManagedUser(mail, name, dept, r)
                                },
                                onUpdateUserAccess = { usr, r, st ->
                                    viewModel.updateUserAccess(usr, r, st)
                                },
                                onRevokeSession = { viewModel.revokeAdminSession(it) }
                            )
                        }
                        composable(TitanRoutes.LOGS) {
                            BackHandler { navController.popBackStack() }
                            ActivityLogsScreen(logsState = logsState)
                        }
                        composable(TitanRoutes.SETTINGS) {
                            if (!isPrimaryRoute) {
                                BackHandler { navController.popBackStack() }
                            }
                            AdminSettingsScreen(
                                operatorEmail = email,
                                role = activeRole,
                                activeWorkspaceMode = workspaceMode,
                                settings = localSettings,
                                permissions = permissionAudit,
                                nativeSettings = viewModel.nativeSettingsItems,
                                onSwitchWorkspaceMode = { viewModel.setWorkspaceMode(it) },
                                onOpenNativeSetting = { viewModel.openNativeSetting(it) },
                                onPermissionResult = { viewModel.refreshPermissionsAndEnterprise() },
                                onToggleAutoSync = { enabled, mins -> viewModel.updateAutoSync(enabled, mins) },
                                onToggleThreatAlerts = { viewModel.updateThreatAlerts(it) },
                                onToggleStrictAudit = { viewModel.updateStrictAudit(it) },
                                onSignOut = onSignOut
                            )
                        }
                    }
                }
            }
        }
    }
}
