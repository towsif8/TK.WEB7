package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ActivityLog
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ActivityLogsScreen(
    logsState: CloudUiState<List<ActivityLog>>,
) {
    var query by remember { mutableStateOf("") }
    var selectedSeverity by remember { mutableStateOf("ALL") }

    val logs = (logsState as? CloudUiState.Success)?.data.orEmpty()
        .sortedByDescending { it.createdAt?.seconds ?: 0L }

    val filtered = remember(logs, query, selectedSeverity) {
        logs.filter { log ->
            val matchSev = selectedSeverity == "ALL" || log.severity == selectedSeverity
            val matchQuery = query.isBlank() ||
                log.action.contains(query, ignoreCase = true) ||
                log.details.contains(query, ignoreCase = true) ||
                log.actorEmail.contains(query, ignoreCase = true)
            matchSev && matchQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            SectionHeader(
                title = "Immutable Audit Trail (${filtered.size})",
                subtitle = "Append-only enterprise activity & security event history"
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Filter by action, actor, or details...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search Logs") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("logs_search_input")
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "INFO", "WARNING", "CRITICAL").forEach { sev ->
                    FilterChip(
                        selected = selectedSeverity == sev,
                        onClick = { selectedSeverity = sev },
                        label = { Text(sev) }
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    TitanCard {
                        Text("No matching audit records found.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            } else {
                items(filtered, key = { it.id }) { log ->
                    val tone = when (log.severity) {
                        "CRITICAL" -> BadgeTone.CRIMSON
                        "WARNING" -> BadgeTone.AMBER
                        else -> BadgeTone.COBALT
                    }
                    val dateStr = log.createdAt?.toDate()?.let {
                        SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US).format(it)
                    } ?: "Just now"

                    TitanCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(log.action, style = MaterialTheme.typography.titleSmall, color = TextPrimary, modifier = Modifier.weight(1f))
                            StatusBadge(text = log.severity, tone = tone)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.details, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${log.actorEmail} (${log.actorRole}) • ${log.targetType}:${log.targetId} • $dateStr",
                            style = MaterialTheme.typography.labelSmall,
                            color = CobaltSecondary
                        )
                    }
                }
            }
        }
    }
}
