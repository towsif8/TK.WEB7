package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ComplianceState
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.LocalSecurityAuditResult
import com.example.model.ManagedDevice
import com.example.model.MdmRole
import com.example.model.RemoteCommand
import com.example.ui.components.BadgeTone
import com.example.ui.components.ComplianceRingGauge
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldOk
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MemberAgentDashboardScreen(
    memberEmail: String,
    role: MdmRole,
    hardware: DeviceHardwareSnapshot?,
    enterprise: EnterpriseCapabilitiesStatus,
    auditResult: LocalSecurityAuditResult?,
    myDevice: ManagedDevice?,
    assignedPolicy: DevicePolicyRecord?,
    pendingCommands: List<RemoteCommand>,
    installedAppsCount: Int,
    onEnrollOrSyncDevice: () -> Unit,
    onRunSecurityAudit: () -> Unit,
    onApplyAssignedPolicy: (DevicePolicyRecord) -> Unit,
    onExecuteCommand: (RemoteCommand) -> Unit,
    onNavigateRoute: (String) -> Unit,
) {
    val complianceScore = when {
        myDevice?.complianceState == ComplianceState.COMPLIANT.name && auditResult == null -> 100
        auditResult != null -> (100 - auditResult.riskScore).coerceIn(0, 100)
        else -> 80
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("member_agent_lazy_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            TitanCard(accentBorder = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusBadge(text = "MEMBER AGENT", tone = BadgeTone.COBALT)
                            StatusBadge(
                                text = if (myDevice != null) myDevice.enrollmentStatus else "UNENROLLED",
                                tone = if (myDevice != null) BadgeTone.EMERALD else BadgeTone.AMBER
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = hardware?.deviceName ?: "Managed Android Endpoint",
                            style = MaterialTheme.typography.headlineSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$memberEmail • ${role.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    ComplianceRingGauge(scorePercent = complianceScore, label = "HEALTH")
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onEnrollOrSyncDevice,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("member_enroll_sync_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.Sync, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (myDevice == null) "Enroll Device" else "Sync Health")
                    }
                    OutlinedButton(
                        onClick = onRunSecurityAudit,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("member_security_scan_button"),
                        border = BorderStroke(1.dp, CobaltSecondary)
                    ) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = CobaltSecondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Scan Now", color = TextPrimary)
                    }
                }
            }
        }

        // Assigned Enterprise Policy (Read & Enforce)
        item {
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Assigned Corporate Policy", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        Text(
                            text = assignedPolicy?.name ?: "Standard Compliance Baseline",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CobaltSecondary
                        )
                    }
                    StatusBadge(
                        text = if (enterprise.isDeviceAdminActive) "DPM ACTIVE" else "BYOD",
                        tone = if (enterprise.isDeviceAdminActive) BadgeTone.EMERALD else BadgeTone.AMBER
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = assignedPolicy?.let {
                        "MinPwd: ${it.minPasswordLength} • Screen Timeout: ${it.screenTimeoutSeconds}s • Encryption Required: ${it.requireEncryption} • Camera Off: ${it.disableCamera}"
                    } ?: "Enroll this device to synchronize corporate baseline policies from your Admin.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                if (assignedPolicy != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { onApplyAssignedPolicy(assignedPolicy) },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        border = BorderStroke(1.dp, EmeraldOk)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = EmeraldOk)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Verify & Apply Local Policy", color = TextPrimary)
                    }
                }
            }
        }

        // Pending Admin Remote Commands for this device
        if (pendingCommands.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Admin Action Requests (${pendingCommands.size})",
                    subtitle = "Signed commands queued by your enterprise administrator"
                )
            }
            items(pendingCommands, key = { it.id }) { cmd ->
                TitanCard(accentBorder = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(cmd.commandType, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text(
                                text = cmd.payloadSummary.ifBlank { "Issued by ${cmd.issuedByEmail}" },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onExecuteCommand(cmd) },
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Execute Admin Command")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Execute")
                        }
                    }
                }
            }
        }

        // Member Device Tools
        item {
            SectionHeader(
                title = "Endpoint Agent Tools",
                subtitle = "Self-service hardware health, app compliance & device security"
            )
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MemberToolRow(
                    icon = Icons.Filled.Memory,
                    title = "Device Health & Telemetry",
                    subtitle = "RAM ${hardware?.ramUsedMb ?: 0}/${hardware?.ramTotalMb ?: 0} MB • Battery ${hardware?.batteryPercent ?: 0}% • ${hardware?.networkType ?: "-"}",
                    onClick = { onNavigateRoute("device_intel") }
                )
                MemberToolRow(
                    icon = Icons.Filled.Apps,
                    title = "Authorized Apps & Audit",
                    subtitle = "$installedAppsCount installed apps audited against company allowlist",
                    onClick = { onNavigateRoute("apps") }
                )
                MemberToolRow(
                    icon = Icons.Filled.Security,
                    title = "Security Scanner & Quarantine",
                    subtitle = "Integrity checks & SAF file SHA-256 verification",
                    onClick = { onNavigateRoute("security") }
                )
                MemberToolRow(
                    icon = Icons.Filled.Policy,
                    title = "Device Admin & Policy Status",
                    subtitle = "Activate Android DevicePolicyManager protection",
                    onClick = { onNavigateRoute("policies") }
                )
                MemberToolRow(
                    icon = Icons.Filled.Settings,
                    title = "Permissions & System Settings",
                    subtitle = "Runtime permissions, Wi-Fi/VPN shortcuts & telemetry schedule",
                    onClick = { onNavigateRoute("settings") }
                )
            }
        }
    }
}

@Composable
private fun MemberToolRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        color = DarkNavySurface,
        border = BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = ElevatedNavy,
                border = BorderStroke(1.dp, CobaltSecondary.copy(alpha = 0.35f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = CobaltSecondary,
                    modifier = Modifier
                        .padding(10.dp)
                        .size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = TextSecondary
            )
        }
    }
}
