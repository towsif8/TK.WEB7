package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.TelemetrySnapshotEntity
import com.example.model.DeviceHardwareSnapshot
import com.example.ui.components.BadgeTone
import com.example.ui.components.MetricTile
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.components.UsageProgressBar
import com.example.ui.theme.AmberWarn
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldOk
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DeviceIntelligenceScreen(
    hardware: DeviceHardwareSnapshot?,
    telemetryHistory: List<TelemetrySnapshotEntity>,
    onRefresh: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Native Device Intelligence",
                subtitle = "Live Android Build, Memory, Storage, Battery & Network telemetry",
                trailing = {
                    Button(
                        onClick = onRefresh,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("device_intel_refresh_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh Telemetry")
                    }
                }
            )
        }

        if (hardware == null) {
            item {
                TitanCard {
                    Text("Capturing native system hardware metrics...", color = TextSecondary)
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Battery (${hardware.batteryStatus})",
                        value = "${hardware.batteryPercent}%",
                        icon = Icons.Filled.BatteryChargingFull,
                        accentColor = if (hardware.batteryPercent < 20) CrimsonAlert else EmeraldOk,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "CPU (${hardware.cpuCores} Cores)",
                        value = hardware.cpuModel.take(12),
                        icon = Icons.Filled.Memory,
                        accentColor = CobaltSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Network Link",
                        value = hardware.networkType,
                        icon = Icons.Filled.Router,
                        accentColor = if (hardware.isNetworkValidated) CyberCyan else AmberWarn,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Temp / Health",
                        value = "${hardware.batteryTempC}°C",
                        icon = Icons.Filled.Storage,
                        accentColor = if (hardware.batteryTempC > 43f) CrimsonAlert else EmeraldOk,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                TitanCard {
                    Text("Memory & Storage Telemetry", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    val ramFrac = if (hardware.ramTotalMb > 0) hardware.ramUsedMb.toFloat() / hardware.ramTotalMb.toFloat() else 0f
                    UsageProgressBar(
                        label = "System RAM ${if (hardware.isLowMemory) "(LOW MEMORY)" else ""}",
                        usedText = "${hardware.ramUsedMb} / ${hardware.ramTotalMb} MB",
                        fraction = ramFrac,
                        color = if (ramFrac > 0.85f) CrimsonAlert else CobaltSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    val diskFrac = if (hardware.storageTotalMb > 0) hardware.storageUsedMb.toFloat() / hardware.storageTotalMb.toFloat() else 0f
                    UsageProgressBar(
                        label = "Internal Data Partition",
                        usedText = "${hardware.storageUsedMb} / ${hardware.storageTotalMb} MB",
                        fraction = diskFrac,
                        color = if (diskFrac > 0.88f) AmberWarn else CyberCyan
                    )
                }
            }

            item {
                TitanCard {
                    Text("Platform & Identity Fingerprint", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(10.dp))
                    KeyValueRow("Device ID", hardware.deviceId)
                    KeyValueRow("Manufacturer / Model", "${hardware.manufacturer} ${hardware.model}")
                    KeyValueRow("Android OS / SDK", "Android ${hardware.androidVersion} (API ${hardware.sdkInt})")
                    KeyValueRow("Security Patch", hardware.securityPatch)
                    KeyValueRow("CPU Architecture", hardware.cpuAbis)
                    KeyValueRow("Board / Hardware", "${hardware.board} / ${hardware.hardware}")
                    KeyValueRow("Power Source / Health", "${hardware.chargingSource} • ${hardware.batteryHealth}")
                    KeyValueRow("DNS / VPN", "${hardware.dnsServers} • VPN=${hardware.isVpnActive}")
                }
            }

            item {
                TitanCard {
                    Text("Device Health & Integrity Signals", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(modifier = Modifier.height(10.dp))
                    IntegrityRow("Storage Encryption", hardware.isDeviceEncrypted, goodWhenTrue = true)
                    IntegrityRow("Secure Screen Lock", hardware.isScreenLockConfigured, goodWhenTrue = true)
                    IntegrityRow("Root / su Indicators", hardware.isRootSuspected, goodWhenTrue = false)
                    IntegrityRow("USB Debugging (ADB)", hardware.isAdbEnabled, goodWhenTrue = false)
                    IntegrityRow("Test-Keys Build", hardware.isTestKeysBuild, goodWhenTrue = false)
                }
            }
        }

        item {
            SectionHeader(
                title = "Offline Room Telemetry Cache (${telemetryHistory.size})",
                subtitle = "Local historical health snapshots persisted via Room"
            )
        }

        items(telemetryHistory.take(8), key = { it.id }) { item ->
            val timeStr = rememberFormattedTime(item.capturedAtEpochMs)
            TitanCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(timeStr, style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        Text(
                            "Bat ${item.batteryPercent}% • RAM ${item.ramUsedMb}/${item.ramTotalMb}MB • ${item.networkType}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    StatusBadge(
                        text = if (item.isDeviceEncrypted && !item.isRootSuspected) "HEALTHY" else "ALERT",
                        tone = if (item.isDeviceEncrypted && !item.isRootSuspected) BadgeTone.EMERALD else BadgeTone.CRIMSON
                    )
                }
            }
        }
    }
}

@Composable
private fun KeyValueRow(key: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(key, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(modifier = Modifier.padding(horizontal = 8.dp))
        Text(value, style = MaterialTheme.typography.labelMedium, color = TextPrimary)
    }
}

@Composable
private fun IntegrityRow(label: String, flag: Boolean, goodWhenTrue: Boolean) {
    val isHealthy = (flag == goodWhenTrue)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        StatusBadge(
            text = if (flag) "YES" else "NO",
            tone = if (isHealthy) BadgeTone.EMERALD else BadgeTone.CRIMSON
        )
    }
}

private fun rememberFormattedTime(epochMs: Long): String {
    return SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US).format(Date(epochMs))
}
