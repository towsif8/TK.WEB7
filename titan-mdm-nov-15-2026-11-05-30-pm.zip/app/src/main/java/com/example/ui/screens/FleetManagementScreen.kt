package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.ComplianceState
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentStatus
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.ManagedDevice
import com.example.model.RemoteCommand
import com.example.model.RemoteCommandType
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CobaltSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FleetManagementScreen(
    devicesState: CloudUiState<List<ManagedDevice>>,
    policiesState: CloudUiState<List<DevicePolicyRecord>>,
    commandsState: CloudUiState<List<RemoteCommand>>,
    enterprise: EnterpriseCapabilitiesStatus,
    onEnrollCurrentDevice: () -> Unit,
    onPushHeartbeat: (ManagedDevice) -> Unit,
    onUpdateStatus: (ManagedDevice, EnrollmentStatus) -> Unit,
    onAssignPolicy: (ManagedDevice, DevicePolicyRecord) -> Unit,
    onQueueCommand: (ManagedDevice, RemoteCommandType, String) -> Unit,
    onExecuteCommand: (RemoteCommand) -> Unit,
    onOpenDeviceIntel: () -> Unit,
) {
    var commandTargetDevice by remember { mutableStateOf<ManagedDevice?>(null) }
    var policyTargetDevice by remember { mutableStateOf<ManagedDevice?>(null) }

    val devices = (devicesState as? CloudUiState.Success)?.data.orEmpty()
    val policies = (policiesState as? CloudUiState.Success)?.data.orEmpty()
    val commands = (commandsState as? CloudUiState.Success)?.data.orEmpty()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            TitanCard(accentBorder = true) {
                SectionHeader(
                    title = "Device Enrollment & Fleet",
                    subtitle = "Active provisioning tier: ${enterprise.enrollmentMode.label}"
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Register this device with an encrypted SHA-256 enrollment token, track real-time hardware compliance, and dispatch signed remote commands.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onEnrollCurrentDevice,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("fleet_enroll_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Icon(Icons.Filled.AddCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Enroll Device")
                    }
                    OutlinedButton(
                        onClick = onOpenDeviceIntel,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("open_device_intel_button"),
                        border = BorderStroke(1.dp, CobaltSecondary)
                    ) {
                        Icon(Icons.Filled.Memory, contentDescription = null, tint = CobaltSecondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Hardware Health", color = TextPrimary)
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Managed Devices (${devices.size})",
                subtitle = "Authenticated inventory with compliance & policy sync"
            )
        }

        when (devicesState) {
            is CloudUiState.Loading -> item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = CrimsonPrimary)
                }
            }
            is CloudUiState.Error -> item {
                TitanCard {
                    Text(devicesState.message, color = CrimsonAlert, style = MaterialTheme.typography.bodyMedium)
                }
            }
            is CloudUiState.Success -> {
                if (devices.isEmpty()) {
                    item {
                        TitanCard {
                            Text("No Enrolled Devices Yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Tap 'Enroll Device' above to register this Android device into your Titan MDM fleet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                } else {
                    items(devices, key = { it.id }) { device ->
                        DeviceFleetCard(
                            device = device,
                            onPushHeartbeat = { onPushHeartbeat(device) },
                            onSuspendToggle = {
                                val next = if (device.enrollmentStatus == EnrollmentStatus.SUSPENDED.name) {
                                    EnrollmentStatus.ENROLLED
                                } else {
                                    EnrollmentStatus.SUSPENDED
                                }
                                onUpdateStatus(device, next)
                            },
                            onRevoke = { onUpdateStatus(device, EnrollmentStatus.REVOKED) },
                            onAssignPolicy = { policyTargetDevice = device },
                            onQueueCommand = { commandTargetDevice = device }
                        )
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Remote Command Queue (${commands.size})",
                subtitle = "Signed, replay-protected & TTL-bounded command history"
            )
        }

        if (commands.isEmpty()) {
            item {
                TitanCard {
                    Text("No remote commands queued.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        } else {
            items(commands.take(15), key = { it.id }) { cmd ->
                TitanCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(cmd.commandType, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text(
                                text = "Device: ${cmd.targetDeviceId} • Issued by ${cmd.issuedByEmail}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            if (cmd.ackMessage.isNotBlank()) {
                                Text(
                                    text = "ACK: ${cmd.ackMessage}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CobaltSecondary
                                )
                            }
                            Text(
                                text = "Nonce: ${cmd.nonce.take(10)} • Digest: ${cmd.signatureDigest.take(14)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        val badgeTone = when (cmd.status) {
                            "EXECUTED" -> BadgeTone.EMERALD
                            "FAILED", "EXPIRED", "CANCELLED" -> BadgeTone.CRIMSON
                            else -> BadgeTone.AMBER
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            StatusBadge(text = cmd.status, tone = badgeTone)
                            if (cmd.status == "QUEUED" || cmd.status == "DELIVERED") {
                                Spacer(modifier = Modifier.height(6.dp))
                                TextButton(onClick = { onExecuteCommand(cmd) }) {
                                    Text("Run Now", color = CrimsonPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    commandTargetDevice?.let { target ->
        QueueCommandDialog(
            device = target,
            onDismiss = { commandTargetDevice = null },
            onConfirm = { type, summary ->
                onQueueCommand(target, type, summary)
                commandTargetDevice = null
            }
        )
    }

    policyTargetDevice?.let { target ->
        AssignPolicyDialog(
            device = target,
            policies = policies,
            onDismiss = { policyTargetDevice = null },
            onSelect = { policy ->
                onAssignPolicy(target, policy)
                policyTargetDevice = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DeviceFleetCard(
    device: ManagedDevice,
    onPushHeartbeat: () -> Unit,
    onSuspendToggle: () -> Unit,
    onRevoke: () -> Unit,
    onAssignPolicy: () -> Unit,
    onQueueCommand: () -> Unit,
) {
    val statusTone = when (device.enrollmentStatus) {
        EnrollmentStatus.ENROLLED.name -> BadgeTone.EMERALD
        EnrollmentStatus.SUSPENDED.name -> BadgeTone.AMBER
        EnrollmentStatus.REVOKED.name -> BadgeTone.CRIMSON
        else -> BadgeTone.NEUTRAL
    }
    val complianceTone = when (device.complianceState) {
        ComplianceState.COMPLIANT.name -> BadgeTone.EMERALD
        ComplianceState.AT_RISK.name -> BadgeTone.AMBER
        else -> BadgeTone.CRIMSON
    }

    TitanCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(device.deviceName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Text(
                    "${device.manufacturer} ${device.model} • Android ${device.androidVersion} (SDK ${device.sdkInt})",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusBadge(text = device.enrollmentStatus, tone = statusTone)
                StatusBadge(text = device.complianceState, tone = complianceTone)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Mode: ${device.enrollmentMode} • Patch: ${device.securityPatch} • Encrypted: ${device.isDeviceEncrypted} • Root: ${device.isRootSuspected}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Battery: ${device.batteryLevel}% • RAM: ${device.ramUsedMb}/${device.ramTotalMb} MB • Disk: ${device.storageUsedMb}/${device.storageTotalMb} MB • Net: ${device.networkType}",
            style = MaterialTheme.typography.labelSmall,
            color = CobaltSecondary
        )
        Spacer(modifier = Modifier.height(12.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onPushHeartbeat,
                modifier = Modifier.height(48.dp)
            ) {
                Icon(Icons.Filled.Sync, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sync Telemetry")
            }
            OutlinedButton(
                onClick = onAssignPolicy,
                modifier = Modifier.height(48.dp)
            ) {
                Icon(Icons.Filled.Policy, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Policy v${device.policySyncVersion}")
            }
            Button(
                onClick = onQueueCommand,
                modifier = Modifier.height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CobaltSecondary)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Command")
            }
            OutlinedButton(
                onClick = onSuspendToggle,
                modifier = Modifier.height(48.dp)
            ) {
                Icon(
                    imageVector = if (device.enrollmentStatus == EnrollmentStatus.SUSPENDED.name) {
                        Icons.Filled.CheckCircle
                    } else {
                        Icons.Filled.Block
                    },
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (device.enrollmentStatus == EnrollmentStatus.SUSPENDED.name) "Restore" else "Suspend")
            }
            if (device.enrollmentStatus != EnrollmentStatus.REVOKED.name) {
                TextButton(
                    onClick = onRevoke,
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("Revoke", color = CrimsonAlert)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QueueCommandDialog(
    device: ManagedDevice,
    onDismiss: () -> Unit,
    onConfirm: (RemoteCommandType, String) -> Unit,
) {
    var selectedType by remember { mutableStateOf(RemoteCommandType.SYNC_POLICY) }
    var summary by remember { mutableStateOf("Admin remote directive for ${device.deviceName}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dispatch Signed Command") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Target: ${device.deviceName}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RemoteCommandType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    label = { Text("Directive Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedType, summary) },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
            ) {
                Text("Sign & Queue")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun AssignPolicyDialog(
    device: ManagedDevice,
    policies: List<DevicePolicyRecord>,
    onDismiss: () -> Unit,
    onSelect: (DevicePolicyRecord) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign Enterprise Policy") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (policies.isEmpty()) {
                    Text("No saved policies found. Create one in the Policies tab first.")
                } else {
                    policies.forEach { pol ->
                        TitanCard(onClick = { onSelect(pol) }) {
                            Text(pol.name, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                            Text("v${pol.version} • Min Pwd: ${pol.minPasswordLength} • Timeout: ${pol.screenTimeoutSeconds}s", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
