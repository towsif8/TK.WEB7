package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.AccountStatus
import com.example.model.AdminAccount
import com.example.model.AdminSession
import com.example.model.ManagedUser
import com.example.model.MdmRole
import com.example.ui.components.BadgeTone
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.components.TitanCard
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CloudUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UserAdminManagementScreen(
    activeRole: MdmRole,
    adminsState: CloudUiState<List<AdminAccount>>,
    usersState: CloudUiState<List<ManagedUser>>,
    sessionsState: CloudUiState<List<AdminSession>>,
    onUpsertAdmin: (String, String, String, MdmRole, AccountStatus, String) -> Unit,
    onCreateManagedUser: (String, String, String, MdmRole) -> Unit,
    onUpdateUserAccess: (ManagedUser, MdmRole, AccountStatus) -> Unit,
    onRevokeSession: (AdminSession) -> Unit,
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddAdminDialog by remember { mutableStateOf(false) }
    var showAddUserDialog by remember { mutableStateOf(false) }

    val admins = (adminsState as? CloudUiState.Success)?.data.orEmpty()
    val users = (usersState as? CloudUiState.Success)?.data.orEmpty()
    val sessions = (sessionsState as? CloudUiState.Success)?.data.orEmpty()
    val canManageRoles = activeRole == MdmRole.SUPER_ADMIN || activeRole == MdmRole.ADMIN

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkNavySurface,
            contentColor = CrimsonPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Admins (${admins.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Users (${users.size})") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Sessions (${sessions.size})") }
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    item {
                        SectionHeader(
                            title = "Admin RBAC Governance",
                            subtitle = "Your Role: ${activeRole.label} • Super Admin / Admin / Moderator / Member",
                            trailing = {
                                if (activeRole == MdmRole.SUPER_ADMIN) {
                                    Button(
                                        onClick = { showAddAdminDialog = true },
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("add_admin_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                                    ) {
                                        Text("Assign Admin")
                                    }
                                }
                            }
                        )
                    }
                    items(admins, key = { it.id }) { admin ->
                        val statusTone = when (admin.status) {
                            AccountStatus.ACTIVE.name -> BadgeTone.EMERALD
                            AccountStatus.SUSPENDED.name -> BadgeTone.AMBER
                            else -> BadgeTone.CRIMSON
                        }
                        TitanCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(admin.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                    Text(admin.email, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text("Dept: ${admin.department} • UID: ${admin.uid.take(12)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StatusBadge(text = admin.role, tone = BadgeTone.CRIMSON)
                                    StatusBadge(text = admin.status, tone = statusTone)
                                }
                            }
                            if (activeRole == MdmRole.SUPER_ADMIN) {
                                Spacer(modifier = Modifier.height(10.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    val nextStatus = if (admin.status == AccountStatus.SUSPENDED.name) AccountStatus.ACTIVE else AccountStatus.SUSPENDED
                                    OutlinedButton(
                                        onClick = {
                                            onUpsertAdmin(
                                                admin.uid,
                                                admin.email,
                                                admin.displayName,
                                                MdmRole.fromString(admin.role),
                                                nextStatus,
                                                admin.department
                                            )
                                        },
                                        modifier = Modifier.height(48.dp)
                                    ) {
                                        Text(if (nextStatus == AccountStatus.ACTIVE) "Restore" else "Suspend")
                                    }
                                    if (admin.status != AccountStatus.REVOKED.name) {
                                        TextButton(
                                            onClick = {
                                                onUpsertAdmin(
                                                    admin.uid,
                                                    admin.email,
                                                    admin.displayName,
                                                    MdmRole.fromString(admin.role),
                                                    AccountStatus.REVOKED,
                                                    admin.department
                                                )
                                            },
                                            modifier = Modifier.height(48.dp)
                                        ) {
                                            Text("Revoke", color = CrimsonAlert)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        SectionHeader(
                            title = "Managed User Inventory",
                            subtitle = "Enroll users, configure feature access, and enforce account status",
                            trailing = {
                                if (canManageRoles) {
                                    Button(
                                        onClick = { showAddUserDialog = true },
                                        modifier = Modifier
                                            .height(48.dp)
                                            .testTag("add_user_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                                    ) {
                                        Text("Add User")
                                    }
                                }
                            }
                        )
                    }
                    items(users, key = { it.id }) { user ->
                        TitanCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(user.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                                    Text(user.email, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text(
                                        "Dept: ${user.department} • Features: ${user.allowedFeatures.joinToString(", ")}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    StatusBadge(text = user.role, tone = BadgeTone.COBALT)
                                    StatusBadge(
                                        text = user.status,
                                        tone = when (user.status) {
                                            AccountStatus.ACTIVE.name -> BadgeTone.EMERALD
                                            AccountStatus.SUSPENDED.name -> BadgeTone.AMBER
                                            else -> BadgeTone.CRIMSON
                                        }
                                    )
                                }
                            }
                            if (canManageRoles) {
                                Spacer(modifier = Modifier.height(10.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    val nextStatus = if (user.status == AccountStatus.SUSPENDED.name) AccountStatus.ACTIVE else AccountStatus.SUSPENDED
                                    OutlinedButton(
                                        onClick = { onUpdateUserAccess(user, MdmRole.fromString(user.role), nextStatus) },
                                        modifier = Modifier.height(48.dp)
                                    ) {
                                        Text(if (nextStatus == AccountStatus.ACTIVE) "Restore" else "Suspend")
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            val nextRole = when (MdmRole.fromString(user.role)) {
                                                MdmRole.MEMBER -> MdmRole.MODERATOR
                                                MdmRole.MODERATOR -> MdmRole.ADMIN
                                                else -> MdmRole.MEMBER
                                            }
                                            onUpdateUserAccess(user, nextRole, AccountStatus.fromString(user.status))
                                        },
                                        modifier = Modifier.height(48.dp)
                                    ) {
                                        Text("Cycle Role")
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        SectionHeader(
                            title = "Admin & Operator Sessions",
                            subtitle = "Monitor active logins and revoke compromised sessions"
                        )
                    }
                    items(sessions, key = { it.id }) { session ->
                        TitanCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(session.adminEmail, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                    Text("${session.deviceModel} • Role: ${session.role}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                }
                                StatusBadge(
                                    text = session.status,
                                    tone = if (session.status == "ACTIVE") BadgeTone.EMERALD else BadgeTone.CRIMSON
                                )
                            }
                            if (session.status == "ACTIVE") {
                                Spacer(modifier = Modifier.height(8.dp))
                                TextButton(onClick = { onRevokeSession(session) }) {
                                    Text("Revoke Session", color = CrimsonAlert)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAdminDialog) {
        AddAdminDialog(
            onDismiss = { showAddAdminDialog = false },
            onConfirm = { uid, email, name, role, dept ->
                onUpsertAdmin(uid, email, name, role, AccountStatus.ACTIVE, dept)
                showAddAdminDialog = false
            }
        )
    }

    if (showAddUserDialog) {
        AddUserDialog(
            onDismiss = { showAddUserDialog = false },
            onConfirm = { email, name, dept, role ->
                onCreateManagedUser(email, name, dept, role)
                showAddUserDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddAdminDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, MdmRole, String) -> Unit,
) {
    var uid by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var dept by remember { mutableStateOf("Security Ops") }
    var role by remember { mutableStateOf(MdmRole.ADMIN) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Assign Admin Role") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = uid, onValueChange = { uid = it }, label = { Text("Firebase UID") })
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Corporate Email") })
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display Name") })
                OutlinedTextField(value = dept, onValueChange = { dept = it }, label = { Text("Department") })
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MdmRole.entries.forEach { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.label) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (uid.isNotBlank() && email.isNotBlank()) onConfirm(uid, email, name.ifBlank { email }, role, dept) },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
            ) {
                Text("Save RBAC")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddUserDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, MdmRole) -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var dept by remember { mutableStateOf("Engineering") }
    var role by remember { mutableStateOf(MdmRole.MEMBER) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Provision Managed User") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("User Email") })
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") })
                OutlinedTextField(value = dept, onValueChange = { dept = it }, label = { Text("Department") })
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(MdmRole.MEMBER, MdmRole.MODERATOR, MdmRole.ADMIN).forEach { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.label) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (email.isNotBlank()) onConfirm(email, name.ifBlank { email }, dept, role) },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
            ) {
                Text("Create User")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
