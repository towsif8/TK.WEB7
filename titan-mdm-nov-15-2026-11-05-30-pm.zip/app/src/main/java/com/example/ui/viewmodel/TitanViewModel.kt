package com.example.ui.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FileIntegrityCheckResult
import com.example.data.local.LocalCacheRepository
import com.example.data.local.LocalScanHistoryEntity
import com.example.data.local.PreferencesStore
import com.example.data.local.QuarantinedFileEntity
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.local.TitanLocalSettings
import com.example.data.local.WorkspaceMode
import com.example.data.remote.unwrapFirestoreMessage
import com.example.data.repository.TitanMdmRepository
import com.example.enterprise.DpmActionResult
import com.example.enterprise.EnterpriseDpmController
import com.example.model.AccountStatus
import com.example.model.ActivityLog
import com.example.model.AdminAccount
import com.example.model.AdminSession
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentStatus
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.InstalledAppInfo
import com.example.model.LocalSecurityAuditResult
import com.example.model.ManagedDevice
import com.example.model.ManagedUser
import com.example.model.MdmRole
import com.example.model.PermissionAuditItem
import com.example.model.RemoteCommand
import com.example.model.RemoteCommandType
import com.example.model.SecurityReport
import com.example.platform.AppInventoryEngine
import com.example.platform.NativeDeviceIntelligence
import com.example.platform.NativeSettingItem
import com.example.platform.NativeSettingsNavigator
import com.example.platform.PermissionAuditEngine
import com.example.platform.SecurityScannerEngine
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface CloudUiState<out T> {
    data object Loading : CloudUiState<Nothing>
    data class Success<T>(val data: T) : CloudUiState<T>
    data class Error(val message: String) : CloudUiState<Nothing>
}

enum class AppFilterMode(val label: String) {
    ALL("All"),
    USER("User Apps"),
    SYSTEM("System"),
    HIGH_RISK("High Risk"),
    ALLOWLISTED("Allowlisted"),
    RESTRICTED("Restricted")
}

class TitanViewModel(
    private val currentUserId: String,
    private val currentUserEmail: String,
    private val currentUserName: String,
    private val repository: TitanMdmRepository,
    private val localCache: LocalCacheRepository,
    private val preferencesStore: PreferencesStore,
    private val deviceIntel: NativeDeviceIntelligence,
    private val appInventory: AppInventoryEngine,
    private val securityScanner: SecurityScannerEngine,
    private val dpmController: EnterpriseDpmController,
    private val settingsNavigator: NativeSettingsNavigator,
    private val permissionAuditEngine: PermissionAuditEngine,
    private val onScheduleWorker: (Boolean, Int) -> Unit,
) : ViewModel() {

    private fun <T> Flow<List<T>>.toCloudState(tagName: String): StateFlow<CloudUiState<List<T>>> =
        this.map<List<T>, CloudUiState<List<T>>> { CloudUiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Stream error on $tagName", root)
                emit(CloudUiState.Error(unwrapFirestoreMessage(root, "Failed to load $tagName")))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = CloudUiState.Loading
            )

    val adminsState: StateFlow<CloudUiState<List<AdminAccount>>> =
        repository.observeAdmins(currentUserId, currentUserEmail).toCloudState("admins")

    val usersState: StateFlow<CloudUiState<List<ManagedUser>>> =
        repository.observeUsers(currentUserId, currentUserEmail).toCloudState("users")

    val devicesState: StateFlow<CloudUiState<List<ManagedDevice>>> =
        repository.observeDevices(currentUserId, currentUserEmail).toCloudState("devices")

    val policiesState: StateFlow<CloudUiState<List<DevicePolicyRecord>>> =
        repository.observePolicies(currentUserId, currentUserEmail).toCloudState("policies")

    val commandsState: StateFlow<CloudUiState<List<RemoteCommand>>> =
        repository.observeRemoteCommands(currentUserId, currentUserEmail).toCloudState("commands")

    val securityReportsState: StateFlow<CloudUiState<List<SecurityReport>>> =
        repository.observeSecurityReports(currentUserId, currentUserEmail).toCloudState("security_reports")

    val activityLogsState: StateFlow<CloudUiState<List<ActivityLog>>> =
        repository.observeActivityLogs(currentUserId, currentUserEmail).toCloudState("activity_logs")

    val sessionsState: StateFlow<CloudUiState<List<AdminSession>>> =
        repository.observeAdminSessions(currentUserId, currentUserEmail).toCloudState("sessions")

    val localTelemetryHistory: StateFlow<List<TelemetrySnapshotEntity>> =
        localCache.recentTelemetry.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val localScanHistory: StateFlow<List<LocalScanHistoryEntity>> =
        localCache.scanHistory.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val quarantinedFiles: StateFlow<List<QuarantinedFileEntity>> =
        localCache.quarantinedFiles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val localSettings: StateFlow<TitanLocalSettings> =
        preferencesStore.settingsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), TitanLocalSettings())

    val activeRole: StateFlow<MdmRole> = combine(adminsState, usersState) { admins, users ->
        val adminList = (admins as? CloudUiState.Success)?.data.orEmpty()
        val myAdmin = adminList.firstOrNull { it.uid == currentUserId && it.status == AccountStatus.ACTIVE.name }
        if (myAdmin != null) {
            MdmRole.fromString(myAdmin.role)
        } else if (currentUserEmail.equals(TitanMdmRepository.BOOTSTRAPPED_SUPER_ADMIN_EMAIL, ignoreCase = true)) {
            MdmRole.SUPER_ADMIN
        } else {
            val userList = (users as? CloudUiState.Success)?.data.orEmpty()
            val myUser = userList.firstOrNull { it.uid == currentUserId }
            MdmRole.fromString(myUser?.role ?: MdmRole.MEMBER.name)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), MdmRole.MEMBER)

    val effectiveWorkspaceMode: StateFlow<WorkspaceMode> = combine(activeRole, localSettings) { role, settings ->
        if (role == MdmRole.MEMBER) {
            WorkspaceMode.MEMBER_AGENT
        } else {
            settings.preferredWorkspaceMode
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        if (currentUserEmail.equals(TitanMdmRepository.BOOTSTRAPPED_SUPER_ADMIN_EMAIL, ignoreCase = true)) {
            WorkspaceMode.ADMIN_CONSOLE
        } else {
            WorkspaceMode.MEMBER_AGENT
        }
    )

    private val _hardwareSnapshot = MutableStateFlow<DeviceHardwareSnapshot?>(null)
    val hardwareSnapshot: StateFlow<DeviceHardwareSnapshot?> = _hardwareSnapshot.asStateFlow()

    private val _enterpriseStatus = MutableStateFlow(dpmController.inspectCapabilities())
    val enterpriseStatus: StateFlow<EnterpriseCapabilitiesStatus> = _enterpriseStatus.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isScanningApps = MutableStateFlow(false)
    val isScanningApps: StateFlow<Boolean> = _isScanningApps.asStateFlow()

    private val _securityAuditResult = MutableStateFlow<LocalSecurityAuditResult?>(null)
    val securityAuditResult: StateFlow<LocalSecurityAuditResult?> = _securityAuditResult.asStateFlow()

    private val _fileIntegrityResult = MutableStateFlow<FileIntegrityCheckResult?>(null)
    val fileIntegrityResult: StateFlow<FileIntegrityCheckResult?> = _fileIntegrityResult.asStateFlow()

    private val _permissionAudit = MutableStateFlow(permissionAuditEngine.auditPermissions())
    val permissionAudit: StateFlow<List<PermissionAuditItem>> = _permissionAudit.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _appSearchQuery = MutableStateFlow("")
    val appSearchQuery: StateFlow<String> = _appSearchQuery.asStateFlow()

    private val _appFilterMode = MutableStateFlow(AppFilterMode.ALL)
    val appFilterMode: StateFlow<AppFilterMode> = _appFilterMode.asStateFlow()

    val nativeSettingsItems: List<NativeSettingItem> = settingsNavigator.supportedSettings

    init {
        refreshAllNativeTelemetry()
        bootstrapAccount()
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun setAppSearchQuery(query: String) {
        _appSearchQuery.value = query
    }

    fun setAppFilterMode(mode: AppFilterMode) {
        _appFilterMode.value = mode
    }

    fun refreshPermissionsAndEnterprise() {
        _enterpriseStatus.value = dpmController.inspectCapabilities()
        _permissionAudit.value = permissionAuditEngine.auditPermissions()
    }

    private fun bootstrapAccount() {
        viewModelScope.launch {
            val snap = deviceIntel.captureSnapshot()
            _hardwareSnapshot.value = snap
            localCache.recordTelemetry(snap)
            val result = repository.bootstrapSessionAndAccount(
                uid = currentUserId,
                email = currentUserEmail,
                displayName = currentUserName,
                deviceModel = "${snap.manufacturer} ${snap.model}"
            )
            result.onFailure { err ->
                _statusBanner.value = unwrapFirestoreMessage(err, "Cloud session sync deferred")
            }
        }
    }

    fun refreshAllNativeTelemetry() {
        viewModelScope.launch {
            _isScanningApps.value = true
            val snap = deviceIntel.captureSnapshot()
            _hardwareSnapshot.value = snap
            val enterprise = dpmController.inspectCapabilities()
            _enterpriseStatus.value = enterprise
            _permissionAudit.value = permissionAuditEngine.auditPermissions()
            localCache.recordTelemetry(snap)

            val apps = appInventory.scanInstalledApps()
            _installedApps.value = apps
            _securityAuditResult.value = securityScanner.runComprehensiveAudit(snap, apps, enterprise)
            _isScanningApps.value = false
        }
    }

    fun enrollThisDevice() {
        viewModelScope.launch {
            val snap = deviceIntel.captureSnapshot()
            _hardwareSnapshot.value = snap
            val ent = dpmController.inspectCapabilities()
            _enterpriseStatus.value = ent
            repository.enrollCurrentDevice(
                snapshot = snap,
                enterprise = ent,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess { deviceId ->
                preferencesStore.setEnrolledDeviceId(deviceId)
                _statusBanner.value = "Device enrolled & telemetry synchronized ($deviceId)."
            }.onFailure { err ->
                _statusBanner.value = unwrapFirestoreMessage(err, "Device enrollment failed")
            }
        }
    }

    fun pushHeartbeatForDevice(device: ManagedDevice) {
        viewModelScope.launch {
            val snap = deviceIntel.captureSnapshot()
            _hardwareSnapshot.value = snap
            val ent = dpmController.inspectCapabilities()
            _enterpriseStatus.value = ent
            repository.pushDeviceTelemetryHeartbeat(device.id, snap, ent)
                .onSuccess { _statusBanner.value = "Live hardware telemetry pushed for ${device.deviceName}." }
                .onFailure { _statusBanner.value = unwrapFirestoreMessage(it, "Heartbeat push failed") }
        }
    }

    fun updateDeviceStatus(device: ManagedDevice, status: EnrollmentStatus) {
        viewModelScope.launch {
            repository.updateDeviceEnrollmentStatus(
                device = device,
                newStatus = status,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "${device.deviceName} status updated to ${status.label}."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "Failed updating device status")
            }
        }
    }

    fun assignPolicyToDevice(device: ManagedDevice, policy: DevicePolicyRecord) {
        viewModelScope.launch {
            val dpmRes = dpmController.applyPolicyRecord(policy)
            repository.assignPolicyToDevice(
                device = device,
                policy = policy,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _enterpriseStatus.value = dpmController.inspectCapabilities()
                _statusBanner.value = "Policy '${policy.name}' synced. ${dpmRes.message}"
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "Policy sync failed")
            }
        }
    }

    fun savePolicy(policy: DevicePolicyRecord) {
        viewModelScope.launch {
            repository.savePolicyRecord(
                policy = policy,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "Policy '${policy.name}' saved to cloud."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "Failed to save policy")
            }
        }
    }

    fun toggleAppAllowlistOrBlocklist(packageName: String, allow: Boolean, policy: DevicePolicyRecord?) {
        val targetPolicy = policy ?: return
        val newAllow = targetPolicy.appAllowlist.toMutableSet()
        val newBlock = targetPolicy.appBlocklist.toMutableSet()
        if (allow) {
            newBlock.remove(packageName)
            if (!newAllow.add(packageName)) newAllow.remove(packageName)
        } else {
            newAllow.remove(packageName)
            if (!newBlock.add(packageName)) newBlock.remove(packageName)
        }
        savePolicy(
            targetPolicy.copy(
                appAllowlist = newAllow.toList(),
                appBlocklist = newBlock.toList()
            )
        )
    }

    fun queueRemoteCommand(device: ManagedDevice, commandType: RemoteCommandType, summary: String) {
        viewModelScope.launch {
            repository.queueRemoteCommand(
                targetDevice = device,
                commandType = commandType,
                payloadSummary = summary,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "Signed command ${commandType.label} queued for ${device.deviceName}."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "Failed to queue command")
            }
        }
    }

    fun executeAndAcknowledgeCommand(command: RemoteCommand) {
        viewModelScope.launch {
            val nowMs = System.currentTimeMillis()
            if (nowMs > command.expiresAtEpochMs) {
                repository.acknowledgeRemoteCommand(
                    command = command,
                    newStatus = "EXPIRED",
                    ackMessage = "Command rejected: TTL expired.",
                    actorEmail = currentUserEmail,
                    actorRole = activeRole.value.name
                )
                _statusBanner.value = "Command ${command.commandType} expired and was rejected."
                return@launch
            }

            val cmdType = RemoteCommandType.entries.firstOrNull { it.name == command.commandType }
                ?: RemoteCommandType.REFRESH_TELEMETRY
            var resultMsg = "Command executed"
            var finalStatus = "EXECUTED"

            when (cmdType) {
                RemoteCommandType.REFRESH_TELEMETRY -> {
                    val snap = deviceIntel.captureSnapshot()
                    _hardwareSnapshot.value = snap
                    localCache.recordTelemetry(snap)
                    resultMsg = "Telemetry refreshed (Battery ${snap.batteryPercent}%, RAM ${snap.ramUsedMb}/${snap.ramTotalMb} MB)"
                }
                RemoteCommandType.AUDIT_SECURITY -> {
                    runAndPublishSecurityAudit()
                    resultMsg = "Security audit executed and uploaded."
                }
                RemoteCommandType.LOCK_NOW -> {
                    val res = dpmController.lockDeviceNow()
                    if (!res.success) finalStatus = "FAILED"
                    resultMsg = res.message
                }
                RemoteCommandType.SYNC_POLICY -> {
                    val policies = (policiesState.value as? CloudUiState.Success)?.data.orEmpty()
                    val firstPol = policies.firstOrNull()
                    if (firstPol != null) {
                        val res = dpmController.applyPolicyRecord(firstPol)
                        resultMsg = res.message
                    } else {
                        resultMsg = "No cloud policy assigned; baseline checked."
                    }
                }
                RemoteCommandType.CLEAR_RESTRICTIONS -> {
                    val res = dpmController.clearAllDeviceAdminRestrictions()
                    if (!res.success) finalStatus = "FAILED"
                    resultMsg = res.message
                }
                RemoteCommandType.ENFORCE_ALLOWLIST -> {
                    resultMsg = "App allowlist compliance audited against installed packages."
                }
                RemoteCommandType.REVOKE_ENROLLMENT -> {
                    val devices = (devicesState.value as? CloudUiState.Success)?.data.orEmpty()
                    val target = devices.firstOrNull { it.id == command.targetDeviceId }
                    if (target != null) {
                        repository.updateDeviceEnrollmentStatus(
                            target,
                            EnrollmentStatus.REVOKED,
                            currentUserEmail,
                            activeRole.value.name
                        )
                    }
                    resultMsg = "Device enrollment revoked per command."
                }
            }

            repository.acknowledgeRemoteCommand(
                command = command,
                newStatus = finalStatus,
                ackMessage = resultMsg,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _enterpriseStatus.value = dpmController.inspectCapabilities()
                _statusBanner.value = "${cmdType.label}: $resultMsg"
            }
        }
    }

    fun runAndPublishSecurityAudit() {
        viewModelScope.launch {
            _isScanningApps.value = true
            val snap = deviceIntel.captureSnapshot()
            _hardwareSnapshot.value = snap
            val apps = appInventory.scanInstalledApps()
            _installedApps.value = apps
            val ent = dpmController.inspectCapabilities()
            _enterpriseStatus.value = ent

            val audit = securityScanner.runComprehensiveAudit(snap, apps, ent)
            _securityAuditResult.value = audit
            localCache.recordSecurityScan(audit)

            val devId = localSettings.value.enrolledDeviceId.ifBlank { snap.deviceId }
            repository.publishSecurityReport(
                deviceId = devId,
                audit = audit,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "Security audit complete: ${audit.confirmedFindingsCount} confirmed, ${audit.potentialRisksCount} potential risks."
            }.onFailure {
                _statusBanner.value = "Local scan saved. Cloud upload deferred: ${unwrapFirestoreMessage(it, "")}"
            }
            _isScanningApps.value = false
        }
    }

    fun inspectFileIntegrity(uri: Uri) {
        viewModelScope.launch {
            localCache.inspectUserSelectedFile(uri)
                .onSuccess { res ->
                    _fileIntegrityResult.value = res
                    _statusBanner.value = "SHA-256 verified for ${res.displayName}."
                }
                .onFailure { err ->
                    _statusBanner.value = "File inspection failed: ${err.message}"
                }
        }
    }

    fun quarantineSelectedFile(uri: Uri, reason: String) {
        viewModelScope.launch {
            localCache.quarantineUserSelectedFile(uri, reason)
                .onSuccess { entity ->
                    _statusBanner.value = "Isolated '${entity.originalDisplayName}' into Titan Quarantine Vault."
                }
                .onFailure { err ->
                    _statusBanner.value = "Quarantine failed: ${err.message}"
                }
        }
    }

    fun purgeQuarantinedFile(entity: QuarantinedFileEntity) {
        viewModelScope.launch {
            localCache.purgeQuarantinedFile(entity)
                .onSuccess { _statusBanner.value = "Purged '${entity.originalDisplayName}' from quarantine." }
        }
    }

    fun upsertAdminAccount(
        targetUid: String,
        email: String,
        displayName: String,
        role: MdmRole,
        status: AccountStatus,
        department: String,
    ) {
        viewModelScope.launch {
            repository.upsertAdminAccount(
                targetUid = targetUid,
                email = email,
                displayName = displayName,
                role = role,
                status = status,
                department = department,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "Admin RBAC updated for $email (${role.label})."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "Admin RBAC update denied")
            }
        }
    }

    fun createManagedUser(email: String, displayName: String, department: String, role: MdmRole) {
        viewModelScope.launch {
            repository.createManagedUser(
                email = email,
                displayName = displayName,
                department = department,
                role = role,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "Provisioned enterprise user $displayName."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "User creation failed")
            }
        }
    }

    fun updateUserAccess(user: ManagedUser, role: MdmRole, status: AccountStatus) {
        viewModelScope.launch {
            repository.updateManagedUserStatusAndRole(
                user = user,
                newRole = role,
                newStatus = status,
                assignedPolicyId = user.assignedPolicyId,
                allowedFeatures = user.allowedFeatures,
                actorEmail = currentUserEmail,
                actorRole = activeRole.value.name
            ).onSuccess {
                _statusBanner.value = "${user.displayName} updated (${role.label} / ${status.label})."
            }.onFailure {
                _statusBanner.value = unwrapFirestoreMessage(it, "User update denied")
            }
        }
    }

    fun revokeAdminSession(session: AdminSession) {
        viewModelScope.launch {
            repository.revokeSession(session, currentUserEmail, activeRole.value.name)
                .onSuccess { _statusBanner.value = "Revoked session on ${session.deviceModel}." }
                .onFailure { _statusBanner.value = unwrapFirestoreMessage(it, "Failed revoking session") }
        }
    }

    fun buildDeviceAdminIntent() = dpmController.buildActivateDeviceAdminIntent()

    fun lockScreenLocally(): DpmActionResult {
        val res = dpmController.lockDeviceNow()
        _statusBanner.value = res.message
        return res
    }

    fun applyPolicyLocally(policy: DevicePolicyRecord): DpmActionResult {
        val res = dpmController.applyPolicyRecord(policy)
        _enterpriseStatus.value = dpmController.inspectCapabilities()
        _statusBanner.value = res.message
        return res
    }

    fun togglePackageSuspension(packageName: String, suspend: Boolean) {
        val res = dpmController.setPackageSuspendedByOwner(packageName, suspend)
        _statusBanner.value = res.message
    }

    fun launchInstalledApp(packageName: String) {
        if (!appInventory.launchApp(packageName)) {
            _statusBanner.value = "This package has no launchable activity."
        }
    }

    fun openAppDetails(packageName: String) {
        if (!appInventory.openAppSystemDetails(packageName)) {
            _statusBanner.value = "Unable to open system details for $packageName."
        }
    }

    fun openNativeSetting(item: NativeSettingItem) {
        if (!settingsNavigator.openSetting(item)) {
            _statusBanner.value = "Unable to open ${item.title} settings on this device."
        }
    }

    fun updateAutoSync(enabled: Boolean, intervalMinutes: Int) {
        viewModelScope.launch {
            preferencesStore.setAutoTelemetrySync(enabled)
            preferencesStore.setSyncIntervalMinutes(intervalMinutes)
            onScheduleWorker(enabled, intervalMinutes)
            _statusBanner.value = if (enabled) {
                "Background telemetry sync scheduled every $intervalMinutes min."
            } else {
                "Background telemetry sync paused."
            }
        }
    }

    fun updateThreatAlerts(enabled: Boolean) {
        viewModelScope.launch { preferencesStore.setThreatAlertsEnabled(enabled) }
    }

    fun updateStrictAudit(enabled: Boolean) {
        viewModelScope.launch { preferencesStore.setStrictAuditMode(enabled) }
    }

    fun setWorkspaceMode(mode: WorkspaceMode) {
        viewModelScope.launch {
            if (activeRole.value == MdmRole.MEMBER && mode == WorkspaceMode.ADMIN_CONSOLE) {
                _statusBanner.value = "Admin Console requires Moderator, Admin, or Super Admin role."
                return@launch
            }
            preferencesStore.setPreferredWorkspaceMode(mode)
            _statusBanner.value = "Switched workspace to ${mode.label}."
        }
    }

    companion object {
        private const val TAG = "TitanVM"
    }
}
