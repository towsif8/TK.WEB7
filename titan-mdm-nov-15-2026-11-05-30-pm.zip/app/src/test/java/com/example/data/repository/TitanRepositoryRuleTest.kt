package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.model.AccountStatus
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentMode
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.FindingCertainty
import com.example.model.FindingSeverity
import com.example.model.LocalSecurityAuditResult
import com.example.model.ManagedDevice
import com.example.model.MdmRole
import com.example.model.RemoteCommandType
import com.example.model.SecurityScanFinding
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class TitanRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private fun sampleHardware(deviceId: String): DeviceHardwareSnapshot = DeviceHardwareSnapshot(
        deviceId = deviceId,
        deviceName = "Titan Pixel Fleet",
        manufacturer = "Google",
        brand = "google",
        model = "Pixel 9 Pro",
        androidVersion = "16",
        sdkInt = 36,
        securityPatch = "2026-10-05",
        hardware = "tensor",
        board = "tokay",
        cpuAbis = "arm64-v8a",
        cpuCores = 8,
        cpuModel = "Tensor G4",
        ramUsedMb = 4096L,
        ramTotalMb = 12288L,
        isLowMemory = false,
        storageUsedMb = 32768L,
        storageTotalMb = 131072L,
        batteryPercent = 88,
        batteryStatus = "Charging",
        batteryHealth = "Good",
        batteryTempC = 31.2f,
        chargingSource = "USB",
        networkType = "Wi-Fi",
        isNetworkValidated = true,
        isMetered = false,
        isVpnActive = true,
        dnsServers = "8.8.8.8",
        isDeviceEncrypted = true,
        isRootSuspected = false,
        isAdbEnabled = false,
        isTestKeysBuild = false,
        isScreenLockConfigured = true,
        capturedAtEpochMs = System.currentTimeMillis()
    )

    private fun sampleEnterprise(): EnterpriseCapabilitiesStatus = EnterpriseCapabilitiesStatus(
        isDeviceAdminActive = true,
        isDeviceOwner = false,
        isProfileOwner = false,
        enrollmentMode = EnrollmentMode.DEVICE_ADMIN,
        storageEncryptionStatus = "Active (Encrypted)",
        isCameraDisabledByPolicy = false,
        isPasswordSufficient = true,
        minPasswordLength = 8,
        maxFailedPasswordsForWipe = 0,
        maxTimeToLockSeconds = 120L,
        keyguardDisabledFeatures = 0,
        supportsUsbRestriction = false,
        supportsAppSuspension = false
    )

    @Test
    fun enrollCurrentDevice_authenticatedOwner_createsDeviceAndReturnsId() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = TitanMdmRepository(firestore)
        val rawDeviceId = "dev_${UUID.randomUUID().toString().take(8)}"

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.enrollCurrentDevice(
                snapshot = sampleHardware(rawDeviceId),
                enterprise = sampleEnterprise(),
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            )
        }

        assertTrue("Expected device enrollment success, got ${result.exceptionOrNull()}", result.isSuccess)
        val docId = result.getOrThrow()
        assertTrue(docId.startsWith(rawDeviceId))
        assertTrue(docId.endsWith(uid.take(6)))
    }

    @Test
    fun observeDevices_authenticatedOwner_emitsRealtimeUpdates() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = TitanMdmRepository(firestore)
        val rawDeviceId = "dev_${UUID.randomUUID().toString().take(8)}"
        val deviceDocId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.enrollCurrentDevice(
                snapshot = sampleHardware(rawDeviceId),
                enterprise = sampleEnterprise(),
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }

        val devices = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeDevices(uid, ALICE_EMAIL).first { list -> list.any { it.id == deviceDocId } }
        }
        assertTrue(devices.any { it.id == deviceDocId && it.ownerUid == uid })
    }

    @Test
    fun queueAndAcknowledgeRemoteCommand_ownerDevice_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = TitanMdmRepository(firestore)
        val rawDeviceId = "dev_${UUID.randomUUID().toString().take(8)}"
        val deviceDocId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.enrollCurrentDevice(
                snapshot = sampleHardware(rawDeviceId),
                enterprise = sampleEnterprise(),
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }
        val targetDevice = ManagedDevice(
            id = deviceDocId,
            ownerUid = uid,
            deviceName = "Titan Pixel Fleet"
        )

        val cmdId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.queueRemoteCommand(
                targetDevice = targetDevice,
                commandType = RemoteCommandType.REFRESH_TELEMETRY,
                payloadSummary = "Unit test telemetry ping",
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }

        val commands = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeRemoteCommands(uid, ALICE_EMAIL).first { list -> list.any { it.id == cmdId } }
        }
        val queuedCmd = commands.first { it.id == cmdId }
        assertEquals("QUEUED", queuedCmd.status)

        val ackResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.acknowledgeRemoteCommand(
                command = queuedCmd,
                newStatus = "EXECUTED",
                ackMessage = "Telemetry acknowledged",
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            )
        }
        assertTrue("Expected ack success, got ${ackResult.exceptionOrNull()}", ackResult.isSuccess)
    }

    @Test
    fun savePolicyRecord_authenticatedOwner_createsAndUpdatesPolicy() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = TitanMdmRepository(firestore)
        val policyId = "pol_${UUID.randomUUID().toString().take(10)}"

        val createdId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.savePolicyRecord(
                policy = DevicePolicyRecord(
                    id = policyId,
                    ownerUid = uid,
                    name = "Zero Trust Profile",
                    description = "Unit test policy",
                    isDefaultPolicy = false,
                    minPasswordLength = 8L,
                    screenTimeoutSeconds = 90L
                ),
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }
        assertEquals(policyId, createdId)

        val policies = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observePolicies(uid, ALICE_EMAIL).first { list -> list.any { it.id == policyId } }
        }
        assertEquals(1L, policies.first { it.id == policyId }.version)
    }

    @Test
    fun publishSecurityReport_authenticatedOwner_createsReport() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repo = TitanMdmRepository(firestore)
        val deviceId = "dev_${UUID.randomUUID().toString().take(8)}"
        val audit = LocalSecurityAuditResult(
            riskScore = 10,
            confirmedFindingsCount = 0,
            potentialRisksCount = 1,
            installedAppsScanned = 24,
            deviceIntegrityPassed = true,
            networkSecurityGrade = "A",
            findings = listOf(
                SecurityScanFinding(
                    id = "net_no_vpn",
                    title = "Wi-Fi without VPN",
                    description = "Standard Wi-Fi network detected",
                    category = "Network Security",
                    certainty = FindingCertainty.POTENTIAL_RISK,
                    severity = FindingSeverity.LOW,
                    remediation = "Connect VPN"
                )
            ),
            summary = "0 confirmed findings and 1 potential risk across 24 apps.",
            scannedAtEpochMs = System.currentTimeMillis()
        )

        val reportId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repo.publishSecurityReport(
                deviceId = deviceId,
                audit = audit,
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }

        val reports = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeSecurityReports(uid, ALICE_EMAIL).first { list -> list.any { it.id == reportId } }
        }
        assertTrue(reports.any { it.id == reportId && it.ownerUid == uid })
    }

    @Test
    fun observeDevices_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = TitanMdmRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeDevices("unauth_uid", null).first()
            }
            fail("Expected unauthenticated observeDevices to fail with PERMISSION_DENIED")
        } catch (t: Throwable) {
            caught = t
        }

        val fsEx = caught?.unwrapFirestoreException()
        assertNotNull("Expected nested FirebaseFirestoreException, got $caught", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun queueRemoteCommand_crossUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = TitanMdmRepository(firestore)
        val aliceDeviceId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.enrollCurrentDevice(
                snapshot = sampleHardware("dev_${UUID.randomUUID().toString().take(8)}"),
                enterprise = sampleEnterprise(),
                actorEmail = ALICE_EMAIL,
                actorRole = MdmRole.MEMBER.name
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = TitanMdmRepository(firestore)
        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.queueRemoteCommand(
                targetDevice = ManagedDevice(id = aliceDeviceId, ownerUid = aliceUid, deviceName = "Alice Phone"),
                commandType = RemoteCommandType.LOCK_NOW,
                payloadSummary = "Unauthorized cross-user lock",
                actorEmail = BOB_EMAIL,
                actorRole = MdmRole.MEMBER.name
            )
        }

        assertTrue("Expected failure for cross-user command", result.isFailure)
        val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException, got ${result.exceptionOrNull()}", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    @Test
    fun upsertAdminAccount_nonSuperAdmin_failsWithPermissionDenied() = runBlocking {
        val bobUid = signInTestUser(BOB_EMAIL)
        val bobRepo = TitanMdmRepository(firestore)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.upsertAdminAccount(
                targetUid = bobUid,
                email = BOB_EMAIL,
                displayName = "Bob Escalation",
                role = MdmRole.SUPER_ADMIN,
                status = AccountStatus.ACTIVE,
                department = "Security",
                actorEmail = BOB_EMAIL,
                actorRole = MdmRole.MEMBER.name
            )
        }

        assertTrue("Expected non-super-admin write to /admins to fail", result.isFailure)
        val fsEx = result.exceptionOrNull()?.unwrapFirestoreException()
        assertNotNull("Expected FirebaseFirestoreException, got ${result.exceptionOrNull()}", fsEx)
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx?.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_mdm_test@example.com"
        const val BOB_EMAIL = "bob_mdm_test@example.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
