package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LocalCacheRepository
import com.example.data.local.TitanDatabase
import com.example.enterprise.EnterpriseDpmController
import com.example.model.DeviceHardwareSnapshot
import com.example.model.DevicePolicyRecord
import com.example.model.EnrollmentMode
import com.example.model.EnterpriseCapabilitiesStatus
import com.example.model.FindingCertainty
import com.example.model.InstalledAppInfo
import com.example.model.ManagedDevice
import com.example.model.MdmRole
import com.example.platform.NativeDeviceIntelligence
import com.example.platform.SecurityScannerEngine
import com.example.ui.screens.AppInventoryScreen
import com.example.ui.screens.CommandDashboardScreen
import com.example.ui.screens.DevicePoliciesScreen
import com.example.ui.screens.MemberAgentDashboardScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppFilterMode
import com.example.ui.viewmodel.CloudUiState
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TitanPlatformAndUiTest {

    @get:Rule
    val composeRule = createComposeRule()

    private fun context(): Context = ApplicationProvider.getApplicationContext()

    @Test
    fun nativeDeviceIntelligence_capturesRealHardwareSnapshotAndDeterministicId() = runBlocking {
        val intel = NativeDeviceIntelligence(context())
        val firstId = intel.computeDeterministicDeviceId()
        val secondId = intel.computeDeterministicDeviceId()
        assertEquals(firstId, secondId)
        assertTrue(firstId.startsWith("dev_"))

        val snapshot = intel.captureSnapshot()
        assertTrue(snapshot.sdkInt >= 24)
        assertTrue(snapshot.cpuCores >= 1)
        assertTrue(snapshot.model.isNotBlank())
    }

    @Test
    fun securityScanner_separatesConfirmedFindingsFromPotentialRisks() {
        val scanner = SecurityScannerEngine(context())
        val hardware = DeviceHardwareSnapshot(
            deviceId = "dev_test_01",
            deviceName = "Test Device",
            manufacturer = "Google",
            brand = "google",
            model = "Pixel",
            androidVersion = "16",
            sdkInt = 36,
            securityPatch = "2026-10-05",
            hardware = "tensor",
            board = "tokay",
            cpuAbis = "arm64-v8a",
            cpuCores = 8,
            cpuModel = "ARMv8",
            ramUsedMb = 2048L,
            ramTotalMb = 8192L,
            isLowMemory = false,
            storageUsedMb = 10000L,
            storageTotalMb = 64000L,
            batteryPercent = 90,
            batteryStatus = "Full",
            batteryHealth = "Good",
            batteryTempC = 28f,
            chargingSource = "AC Adapter",
            networkType = "Wi-Fi",
            isNetworkValidated = true,
            isMetered = false,
            isVpnActive = false,
            dnsServers = "8.8.8.8",
            isDeviceEncrypted = false,
            isRootSuspected = false,
            isAdbEnabled = true,
            isTestKeysBuild = false,
            isScreenLockConfigured = false,
            capturedAtEpochMs = System.currentTimeMillis()
        )
        val enterprise = EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = false,
            isDeviceOwner = false,
            isProfileOwner = false,
            enrollmentMode = EnrollmentMode.STANDARD_BYOD,
            storageEncryptionStatus = "Inactive",
            isCameraDisabledByPolicy = false,
            isPasswordSufficient = false,
            minPasswordLength = 0,
            maxFailedPasswordsForWipe = 0,
            maxTimeToLockSeconds = 0L,
            keyguardDisabledFeatures = 0,
            supportsUsbRestriction = false,
            supportsAppSuspension = false
        )
        val apps = listOf(
            InstalledAppInfo(
                packageName = "com.untrusted.debugapp",
                appName = "Debug App",
                versionName = "1.0",
                versionCode = 1L,
                isSystemApp = false,
                targetSdkVersion = 35,
                minSdkVersion = 24,
                installerPackage = "Unknown / Sideloaded",
                requestedPermissions = listOf("android.permission.CAMERA", "android.permission.RECORD_AUDIO"),
                grantedDangerousPermissions = listOf("CAMERA", "RECORD_AUDIO"),
                isDebuggable = true,
                usesCleartextTraffic = true,
                signingCertSha256 = "AB:CD",
                firstInstallTimeMs = 1L,
                lastUpdateTimeMs = 1L,
                riskScore = 70,
                riskLabel = "HIGH"
            )
        )

        val result = scanner.runComprehensiveAudit(hardware, apps, enterprise)
        assertTrue(result.confirmedFindingsCount >= 3)
        assertTrue(result.potentialRisksCount >= 3)
        assertFalse(result.deviceIntegrityPassed)
        assertTrue(result.findings.any { it.certainty == FindingCertainty.CONFIRMED_FINDING })
        assertTrue(result.findings.any { it.certainty == FindingCertainty.POTENTIAL_RISK })
    }

    @Test
    fun enterpriseDpmController_honestlyGatesDeviceOwnerCapabilities() {
        val dpm = EnterpriseDpmController(context())
        val status = dpm.inspectCapabilities()
        assertFalse(status.isDeviceOwner)
        assertFalse(status.supportsAppSuspension)

        val suspendAttempt = dpm.setPackageSuspendedByOwner("com.example.target", true)
        assertFalse(suspendAttempt.success)
        assertTrue(suspendAttempt.requiresDeviceOwner)
    }

    @Test
    fun roomLocalCache_quarantinesAndPurgesFileCorrectly() = runBlocking {
        val ctx = context()
        val db = Room.inMemoryDatabaseBuilder(ctx, TitanDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val cache = LocalCacheRepository(ctx, db)
            val tempFile = File(ctx.cacheDir, "suspicious_payload.apk").apply {
                writeText("PK_TEST_ARCHIVE_BYTES")
            }
            val uri = Uri.fromFile(tempFile)

            val check = cache.inspectUserSelectedFile(uri).getOrThrow()
            assertTrue(check.isSuspiciousExtension)
            assertTrue(check.sha256Hash.length == 64)

            val quarantined = cache.quarantineUserSelectedFile(uri, "Test isolation").getOrThrow()
            assertTrue(File(quarantined.vaultPath).exists())
            val listAfterAdd = cache.quarantinedFiles.first()
            assertEquals(1, listAfterAdd.size)

            cache.purgeQuarantinedFile(quarantined).getOrThrow()
            assertFalse(File(quarantined.vaultPath).exists())
            assertEquals(0, cache.quarantinedFiles.first().size)
        } finally {
            db.close()
        }
    }

    @Test
    fun commandDashboardScreen_rendersModulesAndActions() {
        val enterprise = EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = false,
            isDeviceOwner = false,
            isProfileOwner = false,
            enrollmentMode = EnrollmentMode.STANDARD_BYOD,
            storageEncryptionStatus = "Active (Encrypted)",
            isCameraDisabledByPolicy = false,
            isPasswordSufficient = true,
            minPasswordLength = 6,
            maxFailedPasswordsForWipe = 0,
            maxTimeToLockSeconds = 120L,
            keyguardDisabledFeatures = 0,
            supportsUsbRestriction = false,
            supportsAppSuspension = false
        )

        composeRule.setContent {
            MyApplicationTheme {
                CommandDashboardScreen(
                    operatorEmail = "sahadat.khan3445@gmail.com",
                    role = MdmRole.SUPER_ADMIN,
                    hardware = null,
                    enterprise = enterprise,
                    auditResult = null,
                    devicesState = CloudUiState.Success(
                        listOf(ManagedDevice(id = "d1", deviceName = "Pixel 9 Fleet", complianceState = "COMPLIANT"))
                    ),
                    policiesState = CloudUiState.Success(emptyList()),
                    commandsState = CloudUiState.Success(emptyList()),
                    sessionsState = CloudUiState.Success(emptyList()),
                    installedAppsCount = 42,
                    onRefreshTelemetry = {},
                    onEnrollDevice = {},
                    onRunAudit = {},
                    onExecuteCommand = {},
                    onNavigateRoute = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("COMMAND CENTER").assertIsDisplayed()
        composeRule.onNodeWithTag("enroll_this_device_button").assertIsDisplayed()
        composeRule.onNodeWithTag("dashboard_lazy_list").performScrollToNode(hasTestTag("module_fleet"))
        composeRule.onNodeWithTag("module_fleet").assertIsDisplayed()
    }

    @Test
    fun appInventoryAndPoliciesScreens_renderAndFilterCorrectly() {
        val apps = listOf(
            InstalledAppInfo(
                packageName = "com.titan.authenticator",
                appName = "Titan Authenticator",
                versionName = "2.1",
                versionCode = 21L,
                isSystemApp = false,
                targetSdkVersion = 35,
                minSdkVersion = 26,
                installerPackage = "Google Play Store",
                requestedPermissions = emptyList(),
                grantedDangerousPermissions = emptyList(),
                isDebuggable = false,
                usesCleartextTraffic = false,
                signingCertSha256 = "12:34",
                firstInstallTimeMs = 1L,
                lastUpdateTimeMs = 1L,
                riskScore = 5,
                riskLabel = "LOW"
            ),
            InstalledAppInfo(
                packageName = "com.other.browser",
                appName = "Legacy Browser",
                versionName = "1.0",
                versionCode = 1L,
                isSystemApp = false,
                targetSdkVersion = 30,
                minSdkVersion = 24,
                installerPackage = "Unknown / Sideloaded",
                requestedPermissions = emptyList(),
                grantedDangerousPermissions = listOf("CAMERA"),
                isDebuggable = false,
                usesCleartextTraffic = true,
                signingCertSha256 = "56:78",
                firstInstallTimeMs = 1L,
                lastUpdateTimeMs = 1L,
                riskScore = 35,
                riskLabel = "MEDIUM"
            )
        )
        var searchQuery = ""
        val enterprise = EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = true,
            isDeviceOwner = false,
            isProfileOwner = false,
            enrollmentMode = EnrollmentMode.DEVICE_ADMIN,
            storageEncryptionStatus = "Active",
            isCameraDisabledByPolicy = false,
            isPasswordSufficient = true,
            minPasswordLength = 6,
            maxFailedPasswordsForWipe = 0,
            maxTimeToLockSeconds = 120L,
            keyguardDisabledFeatures = 0,
            supportsUsbRestriction = false,
            supportsAppSuspension = false
        )

        composeRule.setContent {
            MyApplicationTheme {
                AppInventoryScreen(
                    apps = apps,
                    isScanning = false,
                    searchQuery = "Authenticator",
                    filterMode = AppFilterMode.ALL,
                    activePolicy = DevicePolicyRecord(id = "p1", name = "Baseline"),
                    enterprise = enterprise,
                    onSearchChange = { searchQuery = it },
                    onFilterChange = {},
                    onLaunchApp = {},
                    onOpenAppDetails = {},
                    onToggleAllowlist = { _, _ -> },
                    onToggleSuspendByOwner = { _, _ -> }
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Titan Authenticator").assertIsDisplayed()
        composeRule.onNodeWithTag("app_search_input").performTextInput("x")
        assertNotNull(searchQuery)
    }

    @Test
    fun devicePoliciesScreen_displaysEnterpriseControllerButtons() {
        val enterprise = EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = false,
            isDeviceOwner = false,
            isProfileOwner = false,
            enrollmentMode = EnrollmentMode.STANDARD_BYOD,
            storageEncryptionStatus = "Active",
            isCameraDisabledByPolicy = false,
            isPasswordSufficient = false,
            minPasswordLength = 0,
            maxFailedPasswordsForWipe = 0,
            maxTimeToLockSeconds = 0L,
            keyguardDisabledFeatures = 0,
            supportsUsbRestriction = false,
            supportsAppSuspension = false
        )

        composeRule.setContent {
            MyApplicationTheme {
                DevicePoliciesScreen(
                    enterprise = enterprise,
                    policiesState = CloudUiState.Success(
                        listOf(DevicePolicyRecord(id = "pol_1", name = "Strict Corp Policy", description = "Corp Baseline"))
                    ),
                    buildDeviceAdminIntent = { Intent() },
                    onRefreshEnterpriseStatus = {},
                    onLockScreenNow = {},
                    onApplyPolicyLocally = {},
                    onSavePolicy = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("activate_device_admin_button").assertIsDisplayed()
        composeRule.onNodeWithTag("dpm_lock_now_button").assertIsDisplayed()
        composeRule.onNodeWithTag("create_policy_button").assertIsDisplayed()
        composeRule.onNodeWithTag("policies_lazy_list").performScrollToNode(hasText("Strict Corp Policy"))
        composeRule.onNodeWithText("Strict Corp Policy").assertIsDisplayed()
    }

    @Test
    fun memberAgentDashboardScreen_rendersAgentControlsAndPolicy() {
        val enterprise = EnterpriseCapabilitiesStatus(
            isDeviceAdminActive = true,
            isDeviceOwner = false,
            isProfileOwner = false,
            enrollmentMode = EnrollmentMode.DEVICE_ADMIN,
            storageEncryptionStatus = "Active",
            isCameraDisabledByPolicy = false,
            isPasswordSufficient = true,
            minPasswordLength = 6,
            maxFailedPasswordsForWipe = 0,
            maxTimeToLockSeconds = 120L,
            keyguardDisabledFeatures = 0,
            supportsUsbRestriction = false,
            supportsAppSuspension = false
        )

        composeRule.setContent {
            MyApplicationTheme {
                MemberAgentDashboardScreen(
                    memberEmail = "employee@titanmdm.com",
                    role = MdmRole.MEMBER,
                    hardware = null,
                    enterprise = enterprise,
                    auditResult = null,
                    myDevice = ManagedDevice(id = "dev_1", deviceName = "Employee Pixel", enrollmentStatus = "ENROLLED", complianceState = "COMPLIANT"),
                    assignedPolicy = DevicePolicyRecord(id = "pol_1", name = "Member Baseline Policy"),
                    pendingCommands = emptyList(),
                    installedAppsCount = 18,
                    onEnrollOrSyncDevice = {},
                    onRunSecurityAudit = {},
                    onApplyAssignedPolicy = {},
                    onExecuteCommand = {},
                    onNavigateRoute = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("MEMBER AGENT").assertIsDisplayed()
        composeRule.onNodeWithTag("member_enroll_sync_button").assertIsDisplayed()
        composeRule.onNodeWithTag("member_security_scan_button").assertIsDisplayed()
        composeRule.onNodeWithText("Member Baseline Policy").assertIsDisplayed()
    }
}
